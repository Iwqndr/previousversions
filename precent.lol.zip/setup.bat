@echo off
setlocal enabledelayedexpansion

echo.
echo ==========================================
echo       PRECENT.LOL SETUP SCRIPT
echo ==========================================
echo.

findstr /C:"DISCORD_CLIENT_ID" ".env" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Adding Discord placeholder keys to .env...
    echo. >> ".env"
    echo DISCORD_CLIENT_ID= >> ".env"
    echo DISCORD_CLIENT_SECRET= >> ".env"
    echo APP_URL=http://localhost:3000 >> ".env"
)

if not exist "node_modules\" (
    echo [INFO] Missing node_modules. Installing...
    call npm install
)

echo [INFO] Clearing port 3000...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :3000 ^| findstr LISTENING') do (
    taskkill /f /pid %%a >nul 2>&1
)

echo.
echo [SUCCESS] Environment files are ready.
echo Starting the development server...
echo.

call npm run dev
pause