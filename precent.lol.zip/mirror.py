import asyncio
import ctypes
import ctypes.wintypes
import threading
import websockets
from pathlib import Path

# --- CONFIG ---
WORKER_URL = "wss://livesharets.yumdelirious1.workers.dev"

BASE_DIR = Path(".").resolve()
IGNORE_LIST = [".git", "node_modules", "mirror.py", ".roo", "__pycache__", ".vscode"]

_is_syncing: set[str] = set()

# Windows API constants
FILE_LIST_DIRECTORY           = 0x0001
FILE_SHARE_READ               = 0x00000001
FILE_SHARE_WRITE              = 0x00000002
FILE_SHARE_DELETE             = 0x00000004
OPEN_EXISTING                 = 3
FILE_FLAG_BACKUP_SEMANTICS    = 0x02000000
FILE_NOTIFY_CHANGE_LAST_WRITE = 0x00000010
FILE_NOTIFY_CHANGE_FILE_NAME  = 0x00000001
FILE_NOTIFY_CHANGE_DIR_NAME   = 0x00000002

# Windows FILE_ACTION values
ACTION_ADDED       = 1
ACTION_REMOVED     = 2
ACTION_MODIFIED    = 3
ACTION_RENAMED_OLD = 4
ACTION_RENAMED_NEW = 5

# Message prefixes
MSG_CONTENT = "CONTENT"
MSG_DELETE  = "DELETE"


class DedupQueue:
    def __init__(self):
        self._queue: asyncio.Queue = asyncio.Queue()
        self._pending: set[str] = set()

    def put_nowait(self, item: str):
        if item not in self._pending:
            self._pending.add(item)
            self._queue.put_nowait(item)

    async def get(self) -> str:
        while True:
            item = await self._queue.get()
            if item in self._pending:
                self._pending.discard(item)
                return item


def watch_directory(queue: DedupQueue, loop: asyncio.AbstractEventLoop):
    kernel32 = ctypes.windll.kernel32

    handle = kernel32.CreateFileW(
        str(BASE_DIR),
        FILE_LIST_DIRECTORY,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        None,
        OPEN_EXISTING,
        FILE_FLAG_BACKUP_SEMANTICS,
        None,
    )

    if handle == ctypes.wintypes.HANDLE(-1).value:
        print("❌ Failed to open directory handle")
        return

    buf = ctypes.create_string_buffer(64 * 1024)
    prev_renamed: str | None = None  # track the old name in a rename pair

    while True:
        bytes_returned = ctypes.wintypes.DWORD(0)
        result = kernel32.ReadDirectoryChangesW(
            handle,
            buf,
            len(buf),
            True,  # recursive
            FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_DIR_NAME,
            ctypes.byref(bytes_returned),
            None,
            None,
        )

        if not result:
            break

        offset = 0
        while True:
            next_offset = ctypes.wintypes.DWORD.from_buffer_copy(buf, offset).value
            action      = ctypes.wintypes.DWORD.from_buffer_copy(buf, offset + 4).value
            name_len    = ctypes.wintypes.DWORD.from_buffer_copy(buf, offset + 8).value
            name_raw    = buf.raw[offset + 12: offset + 12 + name_len]
            rel_str     = name_raw.decode("utf-16-le")

            if not any(p in rel_str for p in IGNORE_LIST):
                if action in (ACTION_ADDED, ACTION_MODIFIED, ACTION_RENAMED_NEW):
                    # Send file content (skip if we wrote it ourselves)
                    if rel_str not in _is_syncing:
                        loop.call_soon_threadsafe(queue.put_nowait, f"{MSG_CONTENT}:{rel_str}")

                    # If this is a rename, delete the old name on the other side
                    if action == ACTION_RENAMED_NEW and prev_renamed:
                        loop.call_soon_threadsafe(queue.put_nowait, f"{MSG_DELETE}:{prev_renamed}")
                        prev_renamed = None

                elif action == ACTION_REMOVED:
                    if rel_str not in _is_syncing:
                        loop.call_soon_threadsafe(queue.put_nowait, f"{MSG_DELETE}:{rel_str}")

                elif action == ACTION_RENAMED_OLD:
                    prev_renamed = rel_str  # hold until we get the NEW name event

            if next_offset == 0:
                break
            offset += next_offset

    kernel32.CloseHandle(handle)


async def run(room: str):
    url = f"{WORKER_URL}?room={room}"
    queue = DedupQueue()
    loop = asyncio.get_event_loop()

    t = threading.Thread(target=watch_directory, args=(queue, loop), daemon=True)
    t.start()
    print(f"👀 Watching {BASE_DIR}")

    try:
        async with websockets.connect(url) as ws:
            print(f"✅ Connected to room '{room}'")

            async def receive():
                async for message in ws:
                    try:
                        msg_type, rest = message.split(":", 1)

                        if msg_type == MSG_DELETE:
                            target = BASE_DIR / rest
                            _is_syncing.add(rest)
                            try:
                                if target.exists():
                                    target.unlink()
                                    print(f"🗑  Deleted: {rest}")
                            finally:
                                async def _clear(p):
                                    await asyncio.sleep(0.3)
                                    _is_syncing.discard(p)
                                asyncio.ensure_future(_clear(rest))

                        elif msg_type == MSG_CONTENT:
                            rel_path_str, content = rest.split("|DATA|", 1)
                            target = BASE_DIR / rel_path_str
                            _is_syncing.add(rel_path_str)
                            try:
                                target.parent.mkdir(parents=True, exist_ok=True)
                                target.write_text(content, encoding="utf-8")
                                print(f"⚡ Synced:  {rel_path_str}")
                            finally:
                                async def _clear(p):
                                    await asyncio.sleep(0.3)
                                    _is_syncing.discard(p)
                                asyncio.ensure_future(_clear(rel_path_str))

                    except Exception as e:
                        print(f"❌ Receive error: {e}")

            async def send():
                while True:
                    item = await queue.get()
                    try:
                        msg_type, rel_path_str = item.split(":", 1)

                        if msg_type == MSG_DELETE:
                            await ws.send(f"{MSG_DELETE}:{rel_path_str}")
                            print(f"🗑  Sent delete: {rel_path_str}")

                        elif msg_type == MSG_CONTENT:
                            abs_path = BASE_DIR / rel_path_str
                            if abs_path.exists() and abs_path.is_file():
                                try:
                                    content = abs_path.read_text(encoding="utf-8")
                                    await ws.send(f"{MSG_CONTENT}:{rel_path_str}|DATA|{content}")
                                    print(f"🚀 Sent:    {rel_path_str}")
                                except Exception:
                                    pass  # skip binary files silently

                    except Exception as e:
                        print(f"❌ Send error: {e}")

            await asyncio.gather(receive(), send())

    except Exception as e:
        print(f"❌ Connection error: {e}")


def main():
    import sys
    if len(sys.argv) < 2:
        print("Usage: python mirror.py <room-name>")
        print("  Both people run the same command with the same room name.")
        print("  Example: python mirror.py my-project")
        return

    asyncio.run(run(sys.argv[1]))


if __name__ == "__main__":
    main()