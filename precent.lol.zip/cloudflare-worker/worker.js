// Cloudflare Worker - Central Config Engine + Neon Database Proxy
// Wrangler: npx wrangler deploy

import { neon } from '@neondatabase/serverless';

// Admin emails
const ADMIN_EMAILS = ['defwar155@gmail.com', 'yumdelirious1@gmail.com', 'iwqndr@gmail.com'];

function isAdmin(email) {
  return email && ADMIN_EMAILS.includes(email);
}

export default {
  async fetch(request, env, ctx) {
    // CORS headers - allow local dev IPs + production
    const origin = request.headers.get('Origin') || '';
    const isLocal = origin.startsWith('http://localhost') || 
                    origin.startsWith('http://10.0.') || 
                    origin.startsWith('http://192.168.') || 
                    origin.startsWith('http://172.') ||
                    origin.startsWith('https://precent.lol');
    const corsHeaders = {
      'Access-Control-Allow-Origin': isLocal ? origin : '',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400',
    };

    if (request.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

    const url = new URL(request.url);
    const path = url.pathname;

    // ===== NEON DATABASE HELPER =====
    // Neon HTTP API: use ?pooler=true for serverless driver compatibility
    const httpUrl = env.NEON_URL.includes('?') ? env.NEON_URL + '&pooler=true' : env.NEON_URL + '?pooler=true';
    const db = neon(httpUrl);

    async function verifyAuth() {
      const authHeader = request.headers.get('Authorization');
      if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
      const token = authHeader.split(' ')[1];
      try {
        const response = await fetch(`${env.SUPABASE_URL}/auth/v1/user`, {
          headers: { 'Authorization': `Bearer ${token}`, 'apikey': env.SUPABASE_ANON_KEY },
        });
        if (!response.ok) return null;
        return await response.json();
      } catch { return null; }
    }

    try {
      // ===== PUBLIC CONFIG =====
      if (path === '/api/config' && request.method === 'GET') {
        return new Response(JSON.stringify({
          supabaseUrl: env.SUPABASE_URL,
          supabaseAnonKey: env.SUPABASE_ANON_KEY,
          discordClientId: env.DISCORD_CLIENT_ID,
          discordRedirectUri: env.DISCORD_REDIRECT_URI,
          stripePublishableKey: env.STRIPE_PUBLISHABLE_KEY,
        }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // ===== DISCORD OAUTH PROXY =====
      if (path === '/api/discord' && request.method === 'POST') {
        const body = await request.json();
        const response = await fetch('https://discord.com/api/oauth2/token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            client_id: env.DISCORD_CLIENT_ID,
            client_secret: env.DISCORD_CLIENT_SECRET,
            grant_type: 'authorization_code',
            code: body.code,
            redirect_uri: env.DISCORD_REDIRECT_URI,
          }),
        });
        const data = await response.json();
        return new Response(JSON.stringify(data), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // ===== STRIPE PROXY =====
      if (path === '/api/stripe' && request.method === 'POST') {
        const body = await request.json();
        const response = await fetch(`https://api.stripe.com/v1/${body.endpoint}`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${env.STRIPE_SECRET_KEY}`,
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: new URLSearchParams(body.data),
        });
        const data = await response.json();
        return new Response(JSON.stringify(data), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // ===== PROFILE ENDPOINTS =====

      // GET /api/profile/:username
      if (path.startsWith('/api/profile/') && request.method === 'GET') {
        const username = path.split('/api/profile/')[1];
        if (!username) return new Response(JSON.stringify({ error: 'Username required' }), { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const result = await db('SELECT * FROM users WHERE username = $1 LIMIT 1', [username]);
        return new Response(JSON.stringify(result[0] || null), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // GET /api/profile/by-uid/:uid
      if (path.startsWith('/api/profile/by-uid/') && request.method === 'GET') {
        const uid = path.split('/api/profile/by-uid/')[1];
        const result = await db('SELECT * FROM users WHERE uid = $1 LIMIT 1', [uid]);
        return new Response(JSON.stringify(result[0] || null), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/profile/create - Create new profile
      if (path === '/api/profile/create' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const { uid, username, displayname, avatarurl, email } = body;
        const admin = isAdmin(email);
        const badges = admin ? ['Staff', 'Early Access', 'OG'] : ['Early Access', 'OG'];
        const role = admin ? 'admin' : 'user';
        const loginToken = Math.random().toString(36).substring(2, 8) + Math.random().toString(36).substring(2, 8);

        await db(
          `INSERT INTO users (uid, username, displayname, avatarurl, bio, location, links, appearance, analytics, badges, likes, role, createdat, logintoken) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) ON CONFLICT (uid) DO UPDATE SET username = EXCLUDED.username, displayname = EXCLUDED.displayname, avatarurl = EXCLUDED.avatarurl, role = EXCLUDED.role`,
          [uid, username.toLowerCase(), displayname, avatarurl, 'Welcome to my profile!', '', '[]',
           '{"backgroundType":"gradient","backgroundColor":"#050505","accentColor":"#ff8800","fontFamily":"inter","glassmorphism":true,"buttonStyle":"rounded","cardStyle":"glass","theme":"dark","avatarShape":"circle","layout":"center","cursorTrail":"none","pageTransition":"fade","crtEffect":false,"glitchEffect":false,"bloomIntensity":50,"borderWeight":1,"fontWeight":"normal","textTransform":"none"}',
           '{"views":0,"clicks":0,"history":[]}', badges, 0, role, Date.now(), loginToken]
        );
        await db('INSERT INTO usernames (username, uid) VALUES ($1, $2) ON CONFLICT DO NOTHING', [username.toLowerCase(), uid]);
        return new Response(JSON.stringify({ success: true }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/profile/update - Update profile
      if (path === '/api/profile/update' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const { uid, ...updates } = body;
        if (uid !== user.id && user.role !== 'admin') return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json', ...corsHeaders } });

        const setClauses = [];
        const values = [];
        let idx = 1;
        for (const [key, value] of Object.entries(updates)) {
          setClauses.push(`${key} = $${idx}`);
          values.push(value);
          idx++;
        }
        values.push(uid);
        const sql = `UPDATE users SET ${setClauses.join(', ')} WHERE uid = $${idx} RETURNING *`;
        const result = await db(sql, values);
        return new Response(JSON.stringify(result[0] || null), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/token/reset - Reset login token
      if (path === '/api/token/reset' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const targetUid = body.uid || user.id;
        
        // Check if admin or own token
        if (targetUid !== user.id) {
          const adminProfile = await db('SELECT role FROM users WHERE uid = $1', [user.id]);
          if (!isAdmin(user.email) && adminProfile[0]?.role !== 'admin') {
            return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
          }
        }
        
        // Generate new 12-char random token
        const newToken = Math.random().toString(36).substring(2, 8) + Math.random().toString(36).substring(2, 8);
        await db('UPDATE users SET logintoken = $1 WHERE uid = $2', [newToken, targetUid]);
        
        return new Response(JSON.stringify({ token: newToken }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // GET /api/token/get - Get user's token
      if (path === '/api/token/get' && request.method === 'GET') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const uid = url.searchParams.get('uid') || user.id;
        
        // Check if admin or own token
        if (uid !== user.id) {
          const adminProfile = await db('SELECT role FROM users WHERE uid = $1', [user.id]);
          if (!isAdmin(user.email) && adminProfile[0]?.role !== 'admin') {
            return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
          }
        }
        
        const result = await db('SELECT logintoken FROM users WHERE uid = $1', [uid]);
        return new Response(JSON.stringify({ token: result[0]?.logintoken || null }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/token/login - Login with token
      if (path === '/api/token/login' && request.method === 'POST') {
        const body = await request.json();
        const { token } = body;
        
        if (!token) return new Response(JSON.stringify({ error: 'Token required' }), { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        
        const result = await db('SELECT * FROM users WHERE logintoken = $1 LIMIT 1', [token]);
        if (!result || result.length === 0) {
          return new Response(JSON.stringify({ error: 'Invalid token' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        }
        
        const userProfile = result[0];
        // Don't regenerate token if logged in with token (token stays same)
        return new Response(JSON.stringify({ 
          success: true, 
          user: userProfile,
          token: userProfile.logintoken 
        }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // GET /api/users - Get all users (admin only)
      if (path === '/api/users' && request.method === 'GET') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const userProfile = await db('SELECT role FROM users WHERE uid = $1', [user.id]);
        if (!isAdmin(user.email) && userProfile[0]?.role !== 'admin') return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json', ...corsHeaders } });

        const { searchParams } = url;
        const limit = parseInt(searchParams.get('limit') || '20');
        const offset = parseInt(searchParams.get('offset') || '0');
        const search = searchParams.get('search') || '';

        let sql = 'SELECT * FROM users ORDER BY createdat DESC LIMIT $1 OFFSET $2';
        let params = [limit, offset];
        if (search) {
          const s = `%${search.toLowerCase()}%`;
          sql = `SELECT * FROM users WHERE LOWER(username) LIKE $1 OR LOWER(displayname) LIKE $2 ORDER BY createdat DESC LIMIT $3 OFFSET $4`;
          params = [s, s, limit, offset];
        }
        const result = await db(sql, params);
        return new Response(JSON.stringify(result || []), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // GET /api/users/count - Get total user count
      if (path === '/api/users/count' && request.method === 'GET') {
        const result = await db('SELECT COUNT(*) FROM users');
        return new Response(JSON.stringify({ count: result[0]?.count || 0 }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/users/ban - Ban user
      if (path === '/api/users/ban' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const adminProfile = await db('SELECT role FROM users WHERE uid = $1', [user.id]);
        if (!isAdmin(user.email) && adminProfile[0]?.role !== 'admin') return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const randomString = Math.random().toString(36).substring(2, 12);
        const result = await db(`UPDATE users SET is_suspended = true, role = 'banned', username = $1 WHERE uid = $2 RETURNING *`, [`Temp-${randomString}`, body.uid]);
        await db('INSERT INTO moderation_logs (moderator, action, reason, target, tstamp) VALUES ($1, $2, $3, $4, $5)', [user.email || 'system', 'ban', `User banned: ${body.oldUsername} -> Temp-${randomString}`, body.uid, Date.now()]);
        return new Response(JSON.stringify(result[0]), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/users/suspend - Suspend/unsuspend user
      if (path === '/api/users/suspend' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const adminProfile = await db('SELECT role FROM users WHERE uid = $1', [user.id]);
        if (!isAdmin(user.email) && adminProfile[0]?.role !== 'admin') return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const result = await db('UPDATE users SET is_suspended = $1 WHERE uid = $2 RETURNING *', [body.is_suspended, body.uid]);
        await db('INSERT INTO moderation_logs (moderator, action, reason, target, tstamp) VALUES ($1, $2, $3, $4, $5)', [user.email || 'system', body.is_suspended ? 'suspend' : 'unsuspend', `User ${body.is_suspended ? 'suspended' : 'unsuspended'}`, body.uid, Date.now()]);
        return new Response(JSON.stringify(result[0]), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/users/premium - Give/edit/remove premium
      if (path === '/api/users/premium' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const adminProfile = await db('SELECT role FROM users WHERE uid = $1', [user.id]);
        if (!isAdmin(user.email) && adminProfile[0]?.role !== 'admin') return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const current = await db('SELECT badges, is_pro, plan, metadata FROM users WHERE uid = $1', [body.uid]);
        const currentUser = current[0];
        
        // Get existing metadata or initialize
        const existingMetadata = currentUser?.metadata || {};
        
        let newBadges = currentUser?.badges || [];
        let newPlan = 'free';
        let newIsPro = false;
        let newMetadata = { ...existingMetadata };
        
        if (body.action === 'edit') {
          // Edit existing premium - adjust time
          const currentExpiresAt = newMetadata.premiumExpiresAt;
          const durationType = body.duration_type || 'months';
          const durationValue = parseInt(body.duration_value) || 0;
          
          // Validate limits
          let maxLimit, minLimit;
          switch (durationType) {
            case 'days': maxLimit = 32; minLimit = 1; break;
            case 'weeks': maxLimit = 26; minLimit = 1; break;
            case 'months': maxLimit = 36; minLimit = 1; break;
            default: maxLimit = 36; minLimit = 1;
          }
          
          const clampedValue = Math.min(maxLimit, Math.max(minLimit, durationValue));
          const millisecondsToAdd = clampedValue * (durationType === 'days' ? 24 * 60 * 60 * 1000 : durationType === 'weeks' ? 7 * 24 * 60 * 60 * 1000 : 30 * 24 * 60 * 60 * 1000);
          
          const newExpiresAt = currentExpiresAt ? currentExpiresAt + millisecondsToAdd : Date.now() + millisecondsToAdd;
          newMetadata.premiumExpiresAt = newExpiresAt;
          newIsPro = true;
          newPlan = 'premium';
          newBadges = [...new Set([...newBadges, 'Premium'])];
          
          await db('UPDATE users SET is_pro = $1, badges = $2, plan = $3, metadata = $4 WHERE uid = $5 RETURNING *', 
            [newIsPro, JSON.stringify(newBadges), newPlan, JSON.stringify(newMetadata), body.uid]);
          
          await db('INSERT INTO moderation_logs (moderator, action, reason, target, tstamp) VALUES ($1, $2, $3, $4, $5)', 
            [user.email || 'system', 'edit_premium', `Edited premium for ${body.username}: +${clampedValue} ${durationType}`, body.uid, Date.now()]);
          
          return new Response(JSON.stringify({ success: true, expires_at: newExpiresAt }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        } else if (body.action === 'remove_time') {
          // Reduce premium time
          const currentExpiresAt = newMetadata.premiumExpiresAt;
          if (!currentExpiresAt) {
            return new Response(JSON.stringify({ error: 'User does not have time-limited premium' }), { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
          }
          
          const durationType = body.duration_type || 'months';
          const durationValue = parseInt(body.duration_value) || 0;
          const millisecondsToRemove = durationValue * (durationType === 'days' ? 24 * 60 * 60 * 1000 : durationType === 'weeks' ? 7 * 24 * 60 * 60 * 1000 : 30 * 24 * 60 * 60 * 1000);
          
          const newExpiresAt = Math.max(Date.now(), currentExpiresAt - millisecondsToRemove);
          newMetadata.premiumExpiresAt = newExpiresAt;
          
          // If expires soon or expired, remove premium
          if (newExpiresAt <= Date.now() + 86400000) { // Less than 1 day
            newBadges = newBadges.filter(b => b !== 'Premium' && b !== 'Lifetime');
            newPlan = 'free';
            newIsPro = false;
            delete newMetadata.premiumExpiresAt;
          }
          
          await db('UPDATE users SET is_pro = $1, badges = $2, plan = $3, metadata = $4 WHERE uid = $5 RETURNING *', 
            [newIsPro, JSON.stringify(newBadges), newPlan, JSON.stringify(newMetadata), body.uid]);
          
          return new Response(JSON.stringify({ success: true, expires_at: newExpiresAt }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        } else if (body.premium_type === 'lifetime') {
          // Lifetime premium - never expires
          newBadges = [...new Set([...newBadges, 'Premium', 'Lifetime'])];
          newPlan = 'lifetime';
          newIsPro = true;
          newMetadata.premiumExpiresAt = null;
          newMetadata.premiumGrantedAt = Date.now();
        } else if (body.is_pro) {
          // Time-limited premium
          const durationType = body.duration_type || 'months';
          const durationValue = parseInt(body.duration_value) || 1;
          
          // Validate limits
          let maxLimit;
          switch (durationType) {
            case 'days': maxLimit = 32; break;
            case 'weeks': maxLimit = 26; break;
            case 'months': maxLimit = 36; break;
            default: maxLimit = 36;
          }
          
          const clampedValue = Math.min(maxLimit, Math.max(1, durationValue));
          const expiresAt = Date.now() + (clampedValue * (durationType === 'days' ? 24 * 60 * 60 * 1000 : durationType === 'weeks' ? 7 * 24 * 60 * 60 * 1000 : 30 * 24 * 60 * 60 * 1000));
          newBadges = [...new Set([...newBadges, 'Premium'])];
          newPlan = 'premium';
          newIsPro = true;
          newMetadata.premiumExpiresAt = expiresAt;
          newMetadata.premiumGrantedAt = Date.now();
          newMetadata.premiumDurationType = durationType;
          newMetadata.premiumDurationValue = clampedValue;
        } else {
          // Remove premium
          newBadges = newBadges.filter(b => b !== 'Premium' && b !== 'Lifetime');
          newPlan = 'free';
          newIsPro = false;
          delete newMetadata.premiumExpiresAt;
        }
        
        const result = await db('UPDATE users SET is_pro = $1, badges = $2, plan = $3, metadata = $4 WHERE uid = $5 RETURNING *', 
          [newIsPro, JSON.stringify(newBadges), newPlan, JSON.stringify(newMetadata), body.uid]);
        
        await db('INSERT INTO moderation_logs (moderator, action, reason, target, tstamp) VALUES ($1, $2, $3, $4, $5)', 
          [user.email || 'system', body.premium_type === 'lifetime' ? 'grant_lifetime' : body.is_pro ? 'grant_premium' : 'revoke_premium', 
           `${body.username} ${body.premium_type === 'lifetime' ? 'granted Lifetime' : body.is_pro ? `granted ${body.duration_value || body.months} ${body.duration_type || 'month(s)'}` : 'revoked Premium'}`, body.uid, Date.now()]);
        
        return new Response(JSON.stringify(result[0]), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/users/badge - Give/remove badge
      if (path === '/api/users/badge' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const adminProfile = await db('SELECT role FROM users WHERE uid = $1', [user.id]);
        if (!isAdmin(user.email) && adminProfile[0]?.role !== 'admin') return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const current = await db('SELECT badges, username FROM users WHERE uid = $1', [body.uid]);
        const currentUser = current[0];
        const newBadges = currentUser?.badges?.includes(body.badge) ? currentUser.badges.filter(b => b !== body.badge) : [...(currentUser?.badges || []), body.badge];
        const result = await db('UPDATE users SET badges = $1 WHERE uid = $2 RETURNING *', [newBadges, body.uid]);
        await db('INSERT INTO moderation_logs (moderator, action, reason, target, tstamp) VALUES ($1, $2, $3, $4, $5)', [user.email || 'system', 'badge_update', `Updated badges for ${currentUser?.username}: ${body.badge}`, body.uid, Date.now()]);
        return new Response(JSON.stringify(result[0]), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/users/blacklist - Add to blacklist
      if (path === '/api/users/blacklist' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const adminProfile = await db('SELECT role FROM users WHERE uid = $1', [user.id]);
        if (!isAdmin(user.email) && adminProfile[0]?.role !== 'admin') return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const result = await db('INSERT INTO blacklist (type, value, reason, createdat) VALUES ($1, $2, $3, $4) RETURNING *', [body.type, body.value, body.reason, Date.now()]);
        return new Response(JSON.stringify(result[0]), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // GET /api/blacklist
      if (path === '/api/blacklist' && request.method === 'GET') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const result = await db('SELECT * FROM blacklist ORDER BY createdat DESC');
        return new Response(JSON.stringify(result || []), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/blacklist/delete
      if (path === '/api/blacklist/delete' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        await db('DELETE FROM blacklist WHERE id = $1', [body.id]);
        return new Response(JSON.stringify({ success: true }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // GET /api/reports
      if (path === '/api/reports' && request.method === 'GET') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const result = await db('SELECT * FROM reports ORDER BY createdat DESC');
        return new Response(JSON.stringify(result || []), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // GET /api/reports/user/:uid
      if (path.startsWith('/api/reports/user/') && request.method === 'GET') {
        const uid = path.split('/api/reports/user/')[1];
        const result = await db('SELECT * FROM reports WHERE reporter_uid = $1 ORDER BY createdat DESC', [uid]);
        return new Response(JSON.stringify(result || []), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/reports/create - Create report
      if (path === '/api/reports/create' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const result = await db('INSERT INTO reports (reporter_uid, reported_uid, reason, status, createdat) VALUES ($1, $2, $3, $4, $5) RETURNING *', [user.id, body.reported_uid, body.reason, 'pending', Date.now()]);
        return new Response(JSON.stringify(result[0]), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/reports/resolve - Resolve/dismiss report
      if (path === '/api/reports/resolve' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const result = await db('UPDATE reports SET status = $1 WHERE id = $2 RETURNING *', [body.status, body.reportId]);
        return new Response(JSON.stringify(result[0]), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // GET /api/moderation-logs
      if (path === '/api/moderation-logs' && request.method === 'GET') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const result = await db('SELECT * FROM moderation_logs ORDER BY tstamp DESC LIMIT 100');
        return new Response(JSON.stringify(result || []), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // GET /api/credits
      if (path === '/api/credits' && request.method === 'GET') {
        const result = await db('SELECT * FROM credits WHERE active = true ORDER BY sortorder ASC');
        return new Response(JSON.stringify(result || []), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/credits/create
      if (path === '/api/credits/create' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const result = await db('INSERT INTO credits (name, role, roletype, quote, avatar, link, highlighted, sortorder, active, createdat) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *', [body.name, body.role, body.roletype || 'team', body.quote, body.avatar, body.link, body.highlighted || false, body.sortorder || 0, body.active ?? true, Date.now()]);
        return new Response(JSON.stringify(result[0]), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/credits/update
      if (path === '/api/credits/update' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const { id, ...updates } = body;
        const setClauses = [];
        const values = [];
        let idx = 1;
        for (const [key, value] of Object.entries(updates)) {
          setClauses.push(`${key} = $${idx}`);
          values.push(value);
          idx++;
        }
        values.push(id);
        const sql = `UPDATE credits SET ${setClauses.join(', ')} WHERE id = $${idx} RETURNING *`;
        const result = await db(sql, values);
        return new Response(JSON.stringify(result[0]), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/credits/delete
      if (path === '/api/credits/delete' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        await db('DELETE FROM credits WHERE id = $1', [body.id]);
        return new Response(JSON.stringify({ success: true }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // GET /api/leaderboard
      if (path === '/api/leaderboard' && request.method === 'GET') {
        const result = await db('SELECT uid, username, displayname, avatarurl, analytics, badges, likes FROM users ORDER BY analytics->>\'views\' DESC LIMIT 10');
        return new Response(JSON.stringify(result || []), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/increment-views
      if (path === '/api/increment-views' && request.method === 'POST') {
        const body = await request.json();
        const current = await db('SELECT analytics FROM users WHERE uid = $1', [body.uid]);
        const analytics = current[0]?.analytics || { views: 0, clicks: 0, history: [] };
        analytics.views = (analytics.views || 0) + 1;
        await db('UPDATE users SET analytics = $1 WHERE uid = $2', [JSON.stringify(analytics), body.uid]);
        return new Response(JSON.stringify({ success: true }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // ===== SITE SETTINGS & ADMIN FEATURES =====

      // GET /api/settings - Get site settings
      if (path === '/api/settings' && request.method === 'GET') {
        const result = await db("SELECT * FROM site_settings WHERE id = 'global' LIMIT 1");
        return new Response(JSON.stringify(result[0] || { maintenance_mode: false, maintenance_message: "We'll be right back!", global_message: '', global_message_active: false }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/settings/update - Update site settings (admin only)
      if (path === '/api/settings/update' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const adminProfile = await db('SELECT role FROM users WHERE uid = $1', [user.id]);
        if (!isAdmin(user.email) && adminProfile[0]?.role !== 'admin') return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const { maintenance_mode, maintenance_message, global_message, global_message_active } = body;
        const setClauses = [];
        const values = [];
        let idx = 1;
        if (maintenance_mode !== undefined) { setClauses.push(`maintenance_mode = $${idx}`); values.push(maintenance_mode); idx++; }
        if (maintenance_message !== undefined) { setClauses.push(`maintenance_message = $${idx}`); values.push(maintenance_message); idx++; }
        if (global_message !== undefined) { setClauses.push(`global_message = $${idx}`); values.push(global_message); idx++; }
        if (global_message_active !== undefined) { setClauses.push(`global_message_active = $${idx}`); values.push(global_message_active); idx++; }
        setClauses.push(`updatedat = $${idx}`); values.push(Date.now()); idx++;
        values.push('global');
        const sql = `UPDATE site_settings SET ${setClauses.join(', ')} WHERE id = $${idx} RETURNING *`;
        const result = await db(sql, values);
        await db('INSERT INTO change_history (admin_email, action, details, createdat) VALUES ($1, $2, $3, $4)', [user.email, 'update_settings', `Updated site settings: ${JSON.stringify(body)}`, Date.now()]);
        return new Response(JSON.stringify(result[0]), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /api/users/shadowban - Shadow ban/unban user
      if (path === '/api/users/shadowban' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const adminProfile = await db('SELECT role FROM users WHERE uid = $1', [user.id]);
        if (!isAdmin(user.email) && adminProfile[0]?.role !== 'admin') return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const body = await request.json();
        const result = await db('UPDATE users SET isshadowbanned = $1 WHERE uid = $2 RETURNING *', [body.is_shadow_banned, body.uid]);
        await db('INSERT INTO change_history (admin_email, action, target_uid, target_username, old_value, new_value, details, createdat) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)', 
          [user.email, 'shadowban', body.uid, body.username, body.is_shadow_banned ? 'false' : 'true', body.is_shadow_banned ? 'true' : 'false', `User ${body.is_shadow_banned ? 'shadow banned' : 'shadow unbanned'}`, Date.now()]);
        await db('INSERT INTO moderation_logs (moderator, action, reason, target, tstamp) VALUES ($1, $2, $3, $4, $5)', [user.email || 'system', body.is_shadow_banned ? 'shadowban' : 'unshadowban', `User ${body.is_shadow_banned ? 'shadow banned' : 'shadow unbanned'}`, body.uid, Date.now()]);
        return new Response(JSON.stringify(result[0]), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // GET /api/change-history - Get change history
      if (path === '/api/change-history' && request.method === 'GET') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const adminProfile = await db('SELECT role FROM users WHERE uid = $1', [user.id]);
        if (!isAdmin(user.email) && adminProfile[0]?.role !== 'admin') return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const { searchParams } = url;
        const limit = parseInt(searchParams.get('limit') || '50');
        const targetUid = searchParams.get('target_uid');
        let sql = 'SELECT * FROM change_history ORDER BY createdat DESC LIMIT $1';
        let params = [limit];
        if (targetUid) {
          sql = 'SELECT * FROM change_history WHERE target_uid = $1 ORDER BY createdat DESC LIMIT $2';
          params = [targetUid, limit];
        }
        const result = await db(sql, params);
        return new Response(JSON.stringify(result || []), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // ===== MOBILE MODERATION PANEL =====

      // GET /mod/panel - Mobile moderation panel (key-based auth)
      if (path === '/mod/panel' && request.method === 'GET') {
        return new Response(`
          <!DOCTYPE html>
          <html>
          <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Precent Moderation</title>
            <style>
              body { background: #0a0a0a; color: #fff; font-family: system-ui; padding: 20px; margin: 0; }
              .container { max-width: 400px; margin: 0 auto; }
              input { width: 100%; padding: 12px; margin: 8px 0; background: #1a1a1a; border: 1px solid #333; color: #fff; border-radius: 8px; box-sizing: border-box; }
              button { width: 100%; padding: 12px; background: #ff8800; color: #000; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; }
              button:hover { background: #ff9922; }
              .hidden { display: none; }
              .card { background: #1a1a1a; border: 1px solid #333; border-radius: 12px; padding: 16px; margin: 12px 0; }
              .stat { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #333; }
              .stat:last-child { border-bottom: none; }
            </style>
          </head>
          <body>
            <div class="container">
              <h2 style="text-align:center; color: #ff8800;">Precent Moderation</h2>
              
              <div id="loginForm">
                <div style="display:flex;gap:8px;width:100%;align-items:stretch;">
                  <input type="text" id="modKey" placeholder="Enter moderation key" style="flex:1;min-width:0;padding:12px;margin:0;font-size:14px;">
                  <button onclick="login()" style="flex-shrink:0;padding:12px 20px;">Login</button>
                  <button id="genKeyBtn" onclick="generateKey()" style="flex-shrink:0;background:#333;width:auto;padding:12px 16px;" title="Generate new key">&#128273;</button>
                </div>
                <p id="keyStatus" style="font-size:12px;color:#888;margin-top:8px;text-align:center;"></p>
                <div id="keyDisplay" style="display:none;margin-top:12px;padding:12px;background:#1a1a1a;border:1px solid #333;border-radius:8px;word-break:break-all;">
                  <p style="font-size:12px;color:#888;margin:0 0 8px;">Your key:</p>
                  <p id="keyValue" style="font-size:16px;color:#ff8800;font-family:monospace;margin:0;word-break:break-all;"></p>
                </div>
              </div>
              
              <div id="dashboard" class="hidden">
                <div class="card">
                  <h3 style="margin:0 0 12px;">Quick Stats</h3>
                  <div class="stat"><span>Total Users</span><span id="totalUsers">-</span></div>
                  <div class="stat"><span>Suspended</span><span id="suspended">-</span></div>
                  <div class="stat"><span>Shadow Banned</span><span id="shadowBanned">-</span></div>
                  <div class="stat"><span>Pending Reports</span><span id="reports">-</span></div>
                </div>
                <div class="card">
                  <h3 style="margin:0 0 12px;">Quick Actions</h3>
                  <button onclick="toggleMaintenance()" style="margin-bottom:8px;">Toggle Maintenance Mode</button>
                  <button onclick="logout()" style="background:#333;">Logout</button>
                </div>
              </div>
            </div>
            <script>
              let MOD_KEY = '';
              const WORKER_URL = '${url.origin}';
              
              async function generateKey() {
                const btn = document.getElementById('genKeyBtn');
                const status = document.getElementById('keyStatus');
                const keyDisplay = document.getElementById('keyDisplay');
                const keyValue = document.getElementById('keyValue');
                btn.disabled = true;
                btn.style.opacity = '0.5';
                status.textContent = 'Generating key...';
                status.style.color = '#888';
                keyDisplay.style.display = 'none';

                try {
                  const res = await fetch(WORKER_URL + '/mod/key/generate-standalone', {
                    method: 'POST',
                    headers: {'Content-Type':'application/json'}
                  });
                  const data = await res.json();

                  if (res.ok) {
                    status.textContent = 'Key generated! Check Discord or below:';
                    status.style.color = '#4ade80';
                    // Show the key on the page as a fallback
                    if (data.key) {
                      keyValue.textContent = data.key;
                      keyDisplay.style.display = 'block';
                    }
                  } else {
                    status.textContent = 'Error: ' + (data.error || 'Failed to generate key');
                    status.style.color = '#f87171';
                  }
                } catch (err) {
                  status.textContent = 'Network error: ' + err.message;
                  status.style.color = '#f87171';
                }

                btn.disabled = false;
                btn.style.opacity = '1';
              }
              
              async function login() {
                const key = document.getElementById('modKey').value;
                if (!key) return alert('Enter key');
                const res = await fetch(WORKER_URL + '/mod/auth', {
                  method: 'POST',
                  headers: {'Content-Type':'application/json'},
                  body: JSON.stringify({key})
                });
                const data = await res.json();
                if (data.success) {
                  // Use the session token for subsequent requests
                  MOD_KEY = data.session_token || key;
                  document.getElementById('loginForm').classList.add('hidden');
                  document.getElementById('dashboard').classList.remove('hidden');
                  loadStats();
                } else {
                  alert('Invalid key');
                }
              }
              
              async function loadStats() {
                const res = await fetch(WORKER_URL + '/mod/stats', {
                  headers: {'Authorization': 'Bearer ' + MOD_KEY}
                });
                const data = await res.json();
                document.getElementById('totalUsers').textContent = data.totalUsers || 0;
                document.getElementById('suspended').textContent = data.suspended || 0;
                document.getElementById('shadowBanned').textContent = data.shadowBanned || 0;
                document.getElementById('reports').textContent = data.reports || 0;
              }
              
              async function toggleMaintenance() {
                const res = await fetch(WORKER_URL + '/mod/maintenance', {
                  method: 'POST',
                  headers: {'Content-Type':'application/json','Authorization':'Bearer '+MOD_KEY}
                });
                const data = await res.json();
                alert('Maintenance mode: ' + (data.maintenance_mode ? 'ON' : 'OFF'));
              }
              
              function logout() {
                MOD_KEY = '';
                document.getElementById('loginForm').classList.remove('hidden');
                document.getElementById('dashboard').classList.add('hidden');
              }
            </script>
          </body>
          </html>
        `, { headers: { 'Content-Type': 'text/html', ...corsHeaders } });
      }

      // POST /mod/auth - Authenticate moderation key (one-time use, returns session token)
      if (path === '/mod/auth' && request.method === 'POST') {
        const body = await request.json();
        const { key } = body;

        if (!key || !key.startsWith('pre-mod.')) {
          return new Response(JSON.stringify({ error: 'Invalid key format' }), { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        }

        // Hash the key and check against stored hash
        const keyToHash = key.replace('pre-mod.', '');
        const encoder = new TextEncoder();
        const keyBuffer = encoder.encode(keyToHash);
        const hashBuffer = await crypto.subtle.digest('SHA-256', keyBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashedKey = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

        const settings = await db("SELECT mod_key_hash, mod_key_generated_at, mod_key_discord_message_id FROM site_settings WHERE id = 'global' LIMIT 1");
        const storedHash = settings[0]?.mod_key_hash;
        const discordMsgId = settings[0]?.mod_key_discord_message_id;

        if (!storedHash || hashedKey !== storedHash) {
          // Send webhook notification about failed attempt
          try {
            const webhookRes = await fetch('https://discord.com/api/webhooks/1490436328138084443/FWvtMvO3T7vQnyzy51JvpB1ir9nyXpZ30smY4KrxU2-99l9pT3IkAqw-_nFqgJ4y_HID', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                content: '🚨 **Failed Mod Login Attempt**\nIP: `' + (request.headers.get('CF-Connecting-IP') || 'Unknown') + '`\nKey Used: `' + key.substring(0, 12) + '...`'
              })
            });
            console.log('Failed attempt webhook status:', webhookRes.status);
          } catch (webhookErr) {
            console.error('Failed to send failed-attempt webhook:', webhookErr);
          }
          return new Response(JSON.stringify({ error: 'Invalid key' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        }

        // Key is valid - Create a session token (valid for 1 hour)
        const sessionToken = Math.random().toString(36).substring(2, 18) + Math.random().toString(36).substring(2, 18);
        const expiresAt = Date.now() + (60 * 60 * 1000); // 1 hour
        await db('INSERT INTO mod_sessions (session_token, expiresat) VALUES ($1, $2)', [sessionToken, expiresAt]);

        // Delete the key from database so it can't be reused
        await db("UPDATE site_settings SET mod_key_hash = NULL, mod_key_generated_at = NULL, mod_key_discord_message_id = NULL, updatedat = $1 WHERE id = 'global'", [Date.now()]);

        // Delete the Discord message containing the key
        if (discordMsgId) {
          try {
            await fetch('https://discord.com/api/webhooks/1490436328138084443/FWvtMvO3T7vQnyzy51JvpB1ir9nyXpZ30smY4KrxU2-99l9pT3IkAqw-_nFqgJ4y_HID/messages/' + discordMsgId, {
              method: 'DELETE'
            });
          } catch {}
        }

        // Send confirmation webhook
        try {
          await fetch('https://discord.com/api/webhooks/1490436328138084443/FWvtMvO3T7vQnyzy51JvpB1ir9nyXpZ30smY4KrxU2-99l9pT3IkAqw-_nFqgJ4y_HID', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              content: '✅ **Mod Key Used & Cleaned Up**\nIP: `' + (request.headers.get('CF-Connecting-IP') || 'Unknown') + '`\nKey has been used, Discord message deleted, and key removed from database.\nSession created (expires in 1 hour).'
            })
          });
        } catch {}

        return new Response(JSON.stringify({ success: true, session_token: sessionToken }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // Helper to verify mod key OR session token
      async function verifyModKey(request) {
        const authHeader = request.headers.get('Authorization');
        if (!authHeader || !authHeader.startsWith('Bearer ')) return false;
        const token = authHeader.split(' ')[1];
        
        // First check if it's a session token
        const sessions = await db('SELECT * FROM mod_sessions WHERE session_token = $1 AND expiresat > $2 LIMIT 1', [token, Date.now()]);
        if (sessions.length > 0) return true;
        
        // Fall back to key hash check (for legacy compatibility)
        if (!token || !token.startsWith('pre-mod.')) return false;
        const keyToHash = token.replace('pre-mod.', '');
        const encoder = new TextEncoder();
        const keyBuffer = encoder.encode(keyToHash);
        const hashBuffer = await crypto.subtle.digest('SHA-256', keyBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashedKey = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        const settings = await db("SELECT mod_key_hash FROM site_settings WHERE id = 'global' LIMIT 1");
        return settings[0]?.mod_key_hash === hashedKey;
      }

      // GET /mod/stats - Get moderation stats
      if (path === '/mod/stats' && request.method === 'GET') {
        if (!await verifyModKey(request)) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const totalUsers = await db('SELECT COUNT(*) FROM users');
        const suspended = await db("SELECT COUNT(*) FROM users WHERE issuspended = true");
        const shadowBanned = await db("SELECT COUNT(*) FROM users WHERE isshadowbanned = true");
        const reports = await db("SELECT COUNT(*) FROM reports WHERE status = 'pending'");
        return new Response(JSON.stringify({
          totalUsers: parseInt(totalUsers[0]?.count || 0),
          suspended: parseInt(suspended[0]?.count || 0),
          shadowBanned: parseInt(shadowBanned[0]?.count || 0),
          reports: parseInt(reports[0]?.count || 0)
        }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /mod/maintenance - Toggle maintenance mode
      if (path === '/mod/maintenance' && request.method === 'POST') {
        if (!await verifyModKey(request)) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const current = await db("SELECT maintenance_mode FROM site_settings WHERE id = 'global' LIMIT 1");
        const newMode = !current[0]?.maintenance_mode;
        await db("UPDATE site_settings SET maintenance_mode = $1, updatedat = $2 WHERE id = 'global'", [newMode, Date.now()]);
        return new Response(JSON.stringify({ maintenance_mode: newMode }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /mod/key/generate - Generate new moderation key (admin only)
      if (path === '/mod/key/generate' && request.method === 'POST') {
        const user = await verifyAuth();
        if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        const adminProfile = await db('SELECT role FROM users WHERE uid = $1', [user.id]);
        if (!isAdmin(user.email) && adminProfile[0]?.role !== 'admin') return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json', ...corsHeaders } });

        // Generate 16-char random key
        const rawKey = Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10);
        const fullKey = 'pre-mod.' + rawKey;

        // Hash the key
        const encoder = new TextEncoder();
        const keyBuffer = encoder.encode(rawKey);
        const hashBuffer = await crypto.subtle.digest('SHA-256', keyBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashedKey = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

        // Store hash in database
        await db("UPDATE site_settings SET mod_key_hash = $1, mod_key_generated_at = $2, updatedat = $3 WHERE id = 'global'", [hashedKey, Date.now(), Date.now()]);

        // Send webhook notification and capture message ID
        let messageId = null;
        try {
          const webhookRes = await fetch('https://discord.com/api/webhooks/1490436328138084443/FWvtMvO3T7vQnyzy51JvpB1ir9nyXpZ30smY4KrxU2-99l9pT3IkAqw-_nFqgJ4y_HID', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              content: '🔑 **New Mod Key Generated**\nKey: `' + fullKey + '`\nBy: `' + user.email + '`\n\n⚠️ This message will be auto-deleted after use.'
            })
          });
          const webhookData = await webhookRes.json();
          messageId = webhookData.id;
          console.log('Discord message ID:', messageId);
        } catch (webhookErr) {
          console.error('Failed to send webhook:', webhookErr);
        }

        // Store the Discord message ID so we can delete it later
        if (messageId) {
          await db("UPDATE site_settings SET mod_key_discord_message_id = $1 WHERE id = 'global'", [messageId]);
        }

        await db('INSERT INTO change_history (admin_email, action, details, createdat) VALUES ($1, $2, $3, $4)', [user.email, 'generate_mod_key', 'Generated new moderation key', Date.now()]);

        return new Response(JSON.stringify({ key: fullKey, message: 'Key generated and sent to webhook' }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // POST /mod/key/generate-standalone - Generate key from mod panel (no Supabase auth required)
      if (path === '/mod/key/generate-standalone' && request.method === 'POST') {
        const clientIP = request.headers.get('CF-Connecting-IP') || request.headers.get('X-Forwarded-For') || 'Unknown';
        
        // Rate limiting: check if a key was generated in the last 60 seconds
        const settings = await db("SELECT mod_key_generated_at FROM site_settings WHERE id = 'global' LIMIT 1");
        const lastGenerated = settings[0]?.mod_key_generated_at;
        if (lastGenerated && (Date.now() - lastGenerated) < 60000) {
          const remaining = Math.ceil((60000 - (Date.now() - lastGenerated)) / 1000);
          return new Response(JSON.stringify({ error: 'Please wait ' + remaining + ' seconds before generating another key' }), { status: 429, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
        }

        // Generate 16-char random key
        const rawKey = Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10);
        const fullKey = 'pre-mod.' + rawKey;

        // Hash the key
        const encoder = new TextEncoder();
        const keyBuffer = encoder.encode(rawKey);
        const hashBuffer = await crypto.subtle.digest('SHA-256', keyBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashedKey = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

        // Store hash in database
        await db("UPDATE site_settings SET mod_key_hash = $1, mod_key_generated_at = $2, updatedat = $3 WHERE id = 'global'", [hashedKey, Date.now(), Date.now()]);

        // Send webhook notification and capture message ID
        // Use ?wait=true so Discord returns the message object with ID
        let messageId = null;
        let discordSuccess = false;
        try {
          const webhookUrl = 'https://discord.com/api/webhooks/1490436328138084443/FWvtMvO3T7vQnyzy51JvpB1ir9nyXpZ30smY4KrxU2-99l9pT3IkAqw-_nFqgJ4y_HID?wait=true';
          const webhookBody = JSON.stringify({
            content: '🔑 **New Mod Key Generated**\nKey: `' + fullKey + '`\nIP: `' + clientIP + '`\n\n⚠️ This message will be auto-deleted after use.'
          });
          const webhookRes = await fetch(webhookUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: webhookBody
          });
          
          if (webhookRes.ok) {
            const webhookData = await webhookRes.json();
            messageId = webhookData.id;
            discordSuccess = true;
          }
        } catch (webhookErr) {
          // Webhook failed, but key is still valid
          console.error('Webhook error:', webhookErr);
        }

        // Store the Discord message ID so we can delete it later
        if (messageId) {
          await db("UPDATE site_settings SET mod_key_discord_message_id = $1 WHERE id = 'global'", [messageId]);
        }

        return new Response(JSON.stringify({ 
          success: true, 
          key: fullKey,
          message: discordSuccess ? 'Key sent to Discord and displayed below' : 'Key displayed below (Discord webhook unavailable)',
          discord_success: discordSuccess
        }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // GET /api/debug - Check Neon connection and schema
      if (path === '/api/debug' && request.method === 'GET') {
        const cols = await db(`SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'users' ORDER BY ordinal_position`);
        return new Response(JSON.stringify({ columns: cols, url: httpUrl }), { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      return new Response('Not Found', { status: 404, headers: corsHeaders });
    } catch (error) {
      return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
    }
  },
};
