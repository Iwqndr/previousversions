# Cloudflare Worker Setup Guide

## 1. Deploy the Worker

```bash
cd cloudflare-worker
npm install
npx wrangler login
npx wrangler deploy
```

## 2. Set Secrets

```bash
npx wrangler secret put SUPABASE_URL
npx wrangler secret put SUPABASE_ANON_KEY
npx wrangler secret put DISCORD_CLIENT_ID
npx wrangler secret put DISCORD_CLIENT_SECRET
npx wrangler secret put DISCORD_REDIRECT_URI
npx wrangler secret put STRIPE_PUBLISHABLE_KEY
npx wrangler secret put STRIPE_SECRET_KEY
```

## 3. Variables to DELETE from workspace

After deploying the worker, you can safely delete these from your `.env` files:

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_DISCORD_CLIENT_ID`
- `VITE_DISCORD_REDIRECT_URI`
- `VITE_STRIPE_PUBLISHABLE_KEY`

The app now fetches config from the Worker on startup.

## 4. Worker Endpoints

- `GET /api/config` - Returns public config (Supabase URL, Anon Key, Discord Client ID, etc.)
- `POST /api/discord` - Discord OAuth token proxy (uses hidden client secret)
- `POST /api/stripe` - Stripe API proxy (uses hidden secret key)

## 5. CORS

Only `http://localhost:5173` and `https://precent.lol` are allowed.
