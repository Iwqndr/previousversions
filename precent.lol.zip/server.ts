import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import Stripe from 'stripe';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));

let stripeClient: Stripe | null = null;
function getStripe() {
  if (!stripeClient) {
    const key = process.env.STRIPE_SECRET_KEY;
    if (!key) {
      throw new Error('STRIPE_SECRET_KEY environment variable is required');
    }
    stripeClient = new Stripe(key, {
      apiVersion: '2025-02-24-preview',
    });
  }
  return stripeClient;
}

let supabaseClient: any = null;
function getSupabase() {
  if (!supabaseClient) {
    const url = process.env.VITE_SUPABASE_URL;
    const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !key) {
      throw new Error('VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY environment variables are required');
    }
    supabaseClient = createClient(url, key);
  }
  return supabaseClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Stripe Webhook needs raw body
  app.post('/api/webhook/stripe', express.raw({ type: 'application/json' }), async (req, res) => {
    const sig = req.headers['stripe-signature'];
    let event;

    if (!sig || Array.isArray(sig)) {
      return res.status(400).send('Invalid stripe-signature header');
    }

    try {
      const stripe = getStripe();
      event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
    } catch (err: any) {
      console.error(`Webhook Error: ${err.message}`);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object as Stripe.Checkout.Session;
      const userId = session.metadata?.userId;
      const plan = session.metadata?.plan;

      if (userId && plan) {
        console.log(`Payment successful for user ${userId}, plan ${plan}`);
        const supabase = getSupabase();
        const { error } = await supabase
          .from('users')
          .update({ 
            isPro: true, 
            plan: plan as 'premium' | 'lifetime',
            badges: plan === 'lifetime' ? ['Lifetime', 'Premium'] : ['Premium']
          })
          .eq('uid', userId);
        
        if (error) console.error('Error updating user profile:', error);
      }
    }

    res.json({ received: true });
  });

  app.use(express.json());

  // Create Stripe Checkout Session
  app.post('/api/create-checkout-session', async (req, res) => {
    const { userId, plan, email } = req.body;

    if (!userId || !plan) {
      return res.status(400).json({ error: 'Missing userId or plan' });
    }

    const planDetails: Record<string, any> = {
      premium: {
        name: 'Premium Plan',
        amount: 199, // $1.99
        interval: 'month',
      },
      lifetime: {
        name: 'Lifetime Plan',
        amount: 999, // $9.99
        interval: null,
      },
    };

    const details = planDetails[plan];
    if (!details) {
      return res.status(400).json({ error: 'Invalid plan' });
    }

    try {
      const stripe = getStripe();
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: 'usd',
              product_data: {
                name: details.name,
                description: details.interval ? 'Monthly subscription' : 'One-time payment',
              },
              unit_amount: details.amount,
              recurring: details.interval ? { interval: details.interval as any } : undefined,
            },
            quantity: 1,
          },
        ],
        mode: details.interval ? 'subscription' : 'payment',
        success_url: `${process.env.APP_URL}/dashboard?payment=success`,
        cancel_url: `${process.env.APP_URL}/dashboard?payment=cancelled`,
        customer_email: email,
        metadata: {
          userId,
          plan,
        },
      });

      res.json({ url: session.url });
    } catch (error: any) {
      console.error('Stripe session error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Proxy route for Discord feedback
  app.post('/api/feedback', async (req, res) => {
    const { message, category, username, email } = req.body;
    const webhookUrl = "https://discord.com/api/webhooks/1489799811270971472/B1XXtcYyfmcUdrwdta3Ubg0-Xpy-qLpAkBc_y85lX8-IqJB235f5H3Gu6wdVQqv_40ZH";

    try {
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          embeds: [{
            title: `New Feedback: ${category}`,
            description: message,
            fields: [
              { name: 'Username', value: username, inline: true },
              { name: 'Email', value: email, inline: true }
            ],
            color: category === 'bug' ? 16711680 : category === 'feature' ? 65535 : 65280
          }]
        })
      });

      if (!response.ok) throw new Error('Failed to send to Discord');
      res.json({ success: true });
    } catch (error) {
      console.error('Feedback proxy error:', error);
      res.status(500).json({ error: 'Failed to send feedback' });
    }
  });

  // Discord OAuth2 routes
  app.get('/api/auth/discord', (req, res) => {
    const redirectUri = `${process.env.APP_URL}/api/auth/discord/callback`;
    const discordAuthUrl = `https://discord.com/api/oauth2/authorize?client_id=${process.env.DISCORD_CLIENT_ID}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=identify%20email`;
    res.redirect(discordAuthUrl);
  });

  app.get('/api/auth/discord/callback', async (req, res) => {
    const { code } = req.query;
    const redirectUri = `${process.env.APP_URL}/api/auth/discord/callback`;

    try {
      const tokenResponse = await fetch('https://discord.com/api/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: process.env.DISCORD_CLIENT_ID!,
          client_secret: process.env.DISCORD_CLIENT_SECRET!,
          grant_type: 'authorization_code',
          code: code as string,
          redirect_uri: redirectUri,
        }),
      });

      const tokenData = await tokenResponse.json();
      
      const userResponse = await fetch('https://discord.com/api/users/@me', {
        headers: { Authorization: `Bearer ${tokenData.access_token}` },
      });
      
      const userData = await userResponse.json();
      
      // Redirect back to the app with user data
      res.redirect(`${process.env.APP_URL}/dashboard/discord?username=${encodeURIComponent(userData.username)}&avatar=${encodeURIComponent(userData.avatar)}`);
    } catch (error) {
      console.error('Discord OAuth error:', error);
      res.status(500).send('Authentication failed');
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: {
          host: process.env.APP_URL ? new URL(process.env.APP_URL).hostname : 'localhost',
          port: process.env.APP_URL ? parseInt(new URL(process.env.APP_URL).port) : 3000,
        },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
