import { useState, useEffect } from 'react';
import { LandingHeader } from './components/layout/LandingHeader';
import { Hero } from './components/landing/Hero';
import { Features } from './components/landing/Features';
import { Pricing } from './components/landing/Pricing';
import { HelpCenter } from './components/landing/HelpCenter';
import { ContactUs } from './components/landing/ContactUs';
import { Sidebar } from './components/layout/Sidebar';
import { Overview } from './components/dashboard/Overview';
import { ProfileSettings } from './components/dashboard/ProfileSettings';
import { AppearanceSettings } from './components/dashboard/AppearanceSettings';
import { LinksSettings } from './components/dashboard/LinksSettings';
import { MediaSettings } from './components/dashboard/MediaSettings';
import { MusicSettings } from './components/dashboard/MusicSettings';
import { DiscordSettings } from './components/dashboard/DiscordSettings';
import { Credits } from './components/dashboard/Credits';
import { Metadata } from './components/dashboard/Metadata';
import { Leaderboard } from './components/dashboard/Leaderboard';
import { Community } from './components/dashboard/Community';
import { Settings } from './components/dashboard/Settings';
import { Feedback } from './components/dashboard/Feedback';
import { FeedbackButton } from './components/ui/FeedbackButton';
import { LivePreview } from './components/dashboard/LivePreview';
import { AuthCard } from './components/auth/AuthCard';
import { TermsOfService, PrivacyPolicy } from './components/legal/LegalPages';
import { NeonButton } from './components/ui/NeonButton';
import { CustomCursor } from './components/ui/CustomCursor';
import { BackgroundSystem } from './components/ui/BackgroundSystem';
import { PublicProfile } from './components/PublicProfile';
import { AdminPanel } from './components/admin/AdminPanel';
import { ModerationPanel } from './components/admin/ModerationPanel';
import { ProUpgradeModal } from './components/ui/ProUpgradeModal';
import { PremiumWelcomeModal } from './components/ui/PremiumWelcomeModal';
import { MaintenanceBanner } from './components/ui/MaintenanceBanner';
import { GlobalMessageBanner } from './components/ui/GlobalMessageBanner';
import { ToastContainer } from './components/ui/ToastContainer';
import { ProfileShowcase } from './components/ui/badges/ProfileShowcase';
import { BioLink, AppearanceSettings as AppearanceType } from './types';
import { motion, AnimatePresence } from 'motion/react';
import { LogIn, UserPlus, Menu, X, ArrowLeft, Globe, Twitter, Instagram, Github, AlertTriangle } from 'lucide-react';
import { isAdmin } from './constants/admin';
import { cn } from './lib/utils';
import { useSupabase } from './components/SupabaseProvider';
import { profileService } from './services/profileService';

type View = 'landing' | 'auth' | 'dashboard' | 'tos' | 'privacy' | 'public_profile' | 'help' | 'contact' | 'profile-showcase';

const initialLinks: BioLink[] = [
  { id: '1', title: 'My Portfolio', url: 'https://alexdoe.com', active: true, clicks: 1242 },
  { id: '2', title: 'Twitter / X', url: 'https://twitter.com/alexdoe', active: true, clicks: 842 },
  { id: '3', title: 'Instagram', url: 'https://instagram.com/alexdoe', active: true, clicks: 432 },
];

const initialAppearance: AppearanceType = {
  backgroundType: 'gradient',
  backgroundColor: '#ff8800',
  accentColor: '#ff8800',
  fontFamily: 'inter',
  glassmorphism: true,
};

export default function App() {
  const { user, profile, loading, isOnline, isDemoMode } = useSupabase();
  const [view, setView] = useState<View>('landing');
  const [activeTab, setActiveTab] = useState('overview');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [publicUsername, setPublicUsername] = useState<string | null>(null);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);
  const [vPressCount, setVPressCount] = useState(0);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key?.toLowerCase() === 'v') {
        setVPressCount(prev => {
          const next = prev + 1;
          if (next === 3) {
            if (profile?.role === 'admin' || isAdmin(user?.email)) {
              setIsAdminPanelOpen(true);
            }
            return 0;
          }
          return next;
        });
      } else {
        setVPressCount(0);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [profile, user]);

  useEffect(() => {
    const path = window.location.pathname;
    
    // Handle login/signup routes
    if (path === '/login' || path === '/signup') {
      setView('auth');
      return;
    }
    
    // Handle public profiles
    if (path !== '/' && path !== '/login' && path !== '/signup') {
      const username = path.substring(1);
      setPublicUsername(username);
      setView('public_profile');
      return;
    }
    
    // Handle authenticated routes
    if (user) {
      setView('dashboard');
    } else {
      setView('landing');
    }
  }, [user]);

  const ConnectionWarning = () => {
    if (isOnline || isDemoMode) return null;
    return (
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[100] w-[calc(100%-2rem)] max-w-md">
        <div className="glass border-red-500/50 p-4 rounded-2xl flex items-center gap-4 shadow-2xl animate-bounce">
          <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center text-red-500">
            <AlertTriangle size={20} />
          </div>
          <div className="flex-1">
            <p className="text-sm font-bold text-red-500">Database Offline</p>
            <p className="text-xs text-white/40">Please check your Firebase configuration or internet connection.</p>
          </div>
        </div>
      </div>
    );
  };

  const [isProModalOpen, setIsProModalOpen] = useState(false);
  const [showPremiumWelcome, setShowPremiumWelcome] = useState(false);
  const [siteSettings, setSiteSettings] = useState<any>(null);

  useEffect(() => {
    const handleOpenProModal = () => setIsProModalOpen(true);
    window.addEventListener('open-pro-modal', handleOpenProModal);
    return () => window.removeEventListener('open-pro-modal', handleOpenProModal);
  }, []);

  // Fetch site settings on load
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const { api } = await import('./lib/api');
        const settings = await api.getSettings();
        setSiteSettings(settings);
      } catch (e) {
        console.error('Failed to fetch site settings:', e);
      }
    };
    fetchSettings();
    // Refresh every 30 seconds
    const interval = setInterval(fetchSettings, 30000);
    return () => clearInterval(interval);
  }, []);

  // Show premium welcome when user first logs in with premium
  useEffect(() => {
    if (profile && !loading) {
      const hasSeenWelcome = profile.metadata?.hasSeenPremiumWelcome;
      const isPremium = profile.isPro || profile.plan === 'premium' || profile.plan === 'lifetime';
      
      if (isPremium && !hasSeenWelcome) {
        setShowPremiumWelcome(true);
      }
    }
  }, [profile, loading]);

  const renderDashboardContent = () => {
    switch (activeTab) {
      case 'overview': return <Overview setActiveTab={setActiveTab} />;
      case 'profile': return <ProfileSettings />;
      case 'appearance': return <AppearanceSettings />;
      case 'links': return <LinksSettings />;
      case 'media': return null; // Media tab disabled
      case 'music': return <MusicSettings />;
      case 'discord': return <DiscordSettings />;
      case 'credits': return <Credits />;
      case 'metadata': return <Metadata />;
      case 'leaderboard': return <Leaderboard />;
      case 'community': return <Community />;
      case 'moderation': return <ModerationPanel />;
      case 'feedback': return <Feedback />;
      case 'settings': return <Settings />;
      default: return <Overview setActiveTab={setActiveTab} />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-dark-bg flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-neon-orange border-t-transparent rounded-full animate-spin neon-glow" />
      </div>
    );
  }

  const Footer = () => (
    <footer className="py-20 glass border-t border-white/10 relative z-10">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-neon-orange flex items-center justify-center neon-glow">
                <span className="text-black font-black text-lg">P</span>
              </div>
              <span className="text-xl font-black tracking-tighter">precent.lol</span>
            </div>
            <p className="text-sm text-white/40">The next-gen bio-link platform for creators, gamers, and developers.</p>
            <div className="flex gap-4">
              <a href="#" className="text-white/40 hover:text-neon-orange transition-colors"><Twitter size={18} /></a>
              <a href="#" className="text-white/40 hover:text-neon-orange transition-colors"><Instagram size={18} /></a>
              <a href="#" className="text-white/40 hover:text-neon-orange transition-colors"><Github size={18} /></a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Platform</h4>
            <ul className="space-y-2 text-sm text-white/40">
              <li><button onClick={() => setView('landing')} className="hover:text-white transition-colors">Home</button></li>
              <li><button onClick={() => setView('auth')} className="hover:text-white transition-colors">Sign Up</button></li>
              <li><button onClick={() => { setView('dashboard'); setActiveTab('leaderboard'); }} className="hover:text-white transition-colors">Leaderboard</button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">Legal</h4>
            <ul className="space-y-2 text-sm text-white/40">
              <li><button onClick={() => setView('tos')} className="hover:text-white transition-colors">Terms of Service</button></li>
              <li><button onClick={() => setView('privacy')} className="hover:text-white transition-colors">Privacy Policy</button></li>
              <li><button className="hover:text-white transition-colors">Cookie Policy</button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">Support</h4>
            <ul className="space-y-2 text-sm text-white/40">
              <li><button onClick={() => setView('help')} className="hover:text-white transition-colors">Help Center</button></li>
              <li><button onClick={() => { setView('dashboard'); setActiveTab('community'); }} className="hover:text-white transition-colors">Community</button></li>
              <li><button onClick={() => setView('contact')} className="hover:text-white transition-colors">Contact Us</button></li>
            </ul>
          </div>
        </div>
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-white/20">© 2026 precent.lol. All rights reserved. | Owner: joe | Co-owner: wonder</p>
          <div className="flex items-center gap-2 text-xs text-white/20">
            <Globe size={12} />
            <span>English (US)</span>
          </div>
        </div>
      </div>
    </footer>
  );

  if (view === 'landing') {
    return (
      <div className="min-h-screen bg-base text-white selection:bg-neon-orange/30 selection:text-neon-orange overflow-x-hidden relative">
        <CustomCursor />
        <BackgroundSystem />
        <ConnectionWarning />
        <LandingHeader 
          onSetView={setView} 
          onSetActiveTab={setActiveTab} 
        />

        <Hero 
          onGetStarted={() => setView('auth')} 
          onViewLeaderboard={() => { setView('dashboard'); setActiveTab('leaderboard'); }} 
        />
        <div id="features">
          <Features />
        </div>
        <Pricing />
        
        <Footer />
        <AdminPanel isOpen={isAdminPanelOpen} onClose={() => setIsAdminPanelOpen(false)} />
      </div>
    );
  }

  if (view === 'help') {
    return (
      <div className="min-h-screen bg-base text-white relative">
        <CustomCursor />
        <BackgroundSystem />
        <HelpCenter onBack={() => setView('landing')} />
      </div>
    );
  }

  if (view === 'contact') {
    return (
      <div className="min-h-screen bg-base text-white relative">
        <CustomCursor />
        <BackgroundSystem />
        <ContactUs onBack={() => setView('landing')} />
      </div>
    );
  }

  if (view === 'auth') {
    return (
      <div className="min-h-screen bg-base text-white relative">
        <CustomCursor />
        <BackgroundSystem />
        <button 
          onClick={() => setView('landing')}
          className="fixed top-8 left-8 z-50 flex items-center gap-2 text-white/40 hover:text-white transition-colors font-bold"
        >
          <ArrowLeft size={20} /> Back to Home
        </button>
        <AuthCard />
      </div>
    );
  }

  if (view === 'tos') return <TermsOfService onBack={() => setView('landing')} />;
  if (view === 'privacy') return <PrivacyPolicy onBack={() => setView('landing')} />;
  if (view === 'public_profile' && publicUsername) return <PublicProfile username={publicUsername} />;
  
  if (view === 'profile-showcase') {
    return <ProfileShowcase onBack={() => setView('landing')} />;
  }

  return (
    <div className="min-h-screen bg-base text-white flex overflow-hidden relative">
      <CustomCursor />
      <BackgroundSystem />
      <ConnectionWarning />
      
      {/* Maintenance Mode - blocks non-admin users */}
      {siteSettings?.maintenance_mode && !(profile?.role === 'admin' || isAdmin(user?.email)) && (
        <MaintenanceBanner message={siteSettings.maintenance_message || "We'll be right back!"} />
      )}
      
      <div className={cn(
        "fixed inset-0 z-40 lg:relative lg:z-0 transition-transform duration-300",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        <Sidebar activeTab={activeTab} setActiveTab={(tab) => {
          setActiveTab(tab);
          setIsSidebarOpen(false);
        }} />
      </div>
      
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-30 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      <main className="flex-1 h-screen overflow-y-auto custom-scrollbar relative">
        {/* Top Header Bar */}
        <header className="sticky top-0 z-30 bg-[#050505]/80 backdrop-blur-md border-b border-white/5 px-8 py-4 flex items-center justify-between">
          <div className="lg:hidden flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-neon-orange flex items-center justify-center">
              <span className="text-black font-black text-sm">P</span>
            </div>
            <span className="text-lg font-black tracking-tighter">precent.lol</span>
          </div>
          
          <div className="hidden lg:block">
            <h2 className="text-[10px] font-black text-white/20 tracking-[0.2em] uppercase">Dashboard</h2>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-neon-orange animate-pulse" />
              <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Dashboard</span>
            </div>
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden p-2 text-white/40 hover:text-white"
            >
              <Menu size={20} />
            </button>
          </div>
        </header>

        {/* Global Message Banner - only for logged-in users */}
        {user && siteSettings?.global_message_active && siteSettings?.global_message && (
          <GlobalMessageBanner 
            message={siteSettings.global_message} 
            onClose={() => {}} 
          />
        )}

        <div className="p-4 md:p-8">
          <div className="max-w-[1600px] mx-auto flex flex-col xl:flex-row gap-8">
            <div className="flex-1 min-w-0">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                >
                  {renderDashboardContent()}
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Live Preview Sidebar - Inspiration Style */}
            <div className="hidden xl:block w-[350px] shrink-0">
              <div className="sticky top-8">
                <div className="flex items-center gap-2 mb-6">
                  <div className="w-2 h-2 rounded-full bg-neon-orange animate-pulse" />
                  <h3 className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em]">Live Preview</h3>
                </div>
                <LivePreview
                  displayName={profile?.displayName || user?.displayName || 'User'}
                  username={profile?.username || user?.email?.split('@')[0] || 'username'}
                  bio={profile?.bio || 'Welcome to my profile!'}
                  links={profile?.links || []}
                  appearance={profile?.appearance || {
                    backgroundType: 'gradient',
                    backgroundColor: '#050505',
                    accentColor: '#ff8800',
                    fontFamily: 'inter',
                    glassmorphism: true,
                  }}
                  avatarUrl={profile?.avatarUrl || user?.photoURL || undefined}
                  music={profile?.music || []}
                  media={profile?.media || []}
                  location={profile?.location}
                  views={profile?.analytics?.views || 0}
                  likes={profile?.likes || 0}
                  preview={profile?.preview}
                  badges={profile?.badges || []}
                />
              </div>
            </div>
          </div>
        </div>
      </main>
      <AdminPanel isOpen={isAdminPanelOpen} onClose={() => setIsAdminPanelOpen(false)} />
      <ProUpgradeModal isOpen={isProModalOpen} onClose={() => setIsProModalOpen(false)} />
      <PremiumWelcomeModal 
        isOpen={showPremiumWelcome} 
        onClose={() => {
          setShowPremiumWelcome(false);
          // Mark as seen in metadata
          if (profile) {
            profileService.updateProfile(profile.uid, {
              metadata: {
                ...profile.metadata,
                hasSeenPremiumWelcome: true
              }
            });
          }
        }} 
        isLifetime={profile?.plan === 'lifetime'} 
      />
      <ToastContainer />
    </div>
  );
}
