export interface CommunityPost {
  id: string;
  uid: string;
  username: string;
  avatar: string;
  content: string;
  likes: number;
  comments: number;
  createdat: number;
  mediaUrl?: string;
  mediaType?: 'image' | 'video';
}

export interface ModerationLog {
  id: string;
  moderator: string;
  action: string;
  reason?: string;
  target?: string;
  timestamp: number;
}

export interface CreditEntry {
  id: string;
  name: string;
  role: string;
  roleType?: 'team' | 'special_thanks';
  quote?: string;
  avatar?: string;
  link?: string;
  highlighted?: boolean;
  order?: number;
  active?: boolean;
  createdat: number;
}

export interface UserProfile {
  uid: string;
  username: string;
  displayName: string;
  email?: string;
  bio: string;
  avatarUrl?: string;
  bannerUrl?: string;
  location?: string;
  links: BioLink[];
  appearance: AppearanceSettings;
  analytics: AnalyticsData;
  badges: string[];
  likes: number;
  music?: MusicTrack[];
  media?: MediaItem[];
  discord?: {
    username: string;
    status: string;
    active: boolean;
  };
  metadata?: {
    lastLogin: number;
    ip?: string;
    device?: string;
    permissions?: {
      can_suspend?: boolean;
      can_ban?: boolean;
      can_blacklist?: boolean;
      can_give_badges?: boolean;
      can_delete_posts?: boolean;
      can_view_reports?: boolean;
      can_manage_users?: boolean;
    };
    premiumExpiresAt?: number;
    premiumGrantedAt?: number;
    hasSeenPremiumWelcome?: boolean;
    usernameSuspendedUntil?: number;
    pfpSuspendedUntil?: number;
    lastUsernameChange?: number;
  };
  createdat: number;
  isPro?: boolean;
  plan?: 'free' | 'premium' | 'lifetime';
  isSuspended?: boolean;
  isShadowBanned?: boolean;
  role?: 'admin' | 'user' | 'moderator' | 'banned';
  logintoken?: string;
  preview?: {
    displayName?: string;
    bio?: string;
    location?: string;
    music?: Partial<MusicTrack>;
    link?: Partial<BioLink>;
    discord?: Partial<UserProfile['discord']>;
  };
}

export interface BlacklistEntry {
  id: string;
  type: 'email' | 'ip' | 'username';
  value: string;
  reason?: string;
  createdat: number;
}

export interface MediaItem {
  id: string;
  type: 'image' | 'video';
  url: string;
  name: string;
}

export interface MusicTrack {
  id: string;
  title: string;
  artist: string;
  url: string;
  active: boolean;
}

export interface BioLink {
  id: string;
  title: string;
  url: string;
  icon?: string;
  clicks: number;
  active: boolean;
}

export interface AppearanceSettings {
  backgroundType: 'solid' | 'gradient' | 'animated' | 'image' | 'video' | 'mesh' | 'matrix' | 'particles';
  backgroundColor: string;
  accentColor: string;
  fontFamily: string;
  glassmorphism: boolean;
  backgroundImage?: string;
  buttonStyle?: 'rounded' | 'sharp' | 'pill' | 'glass' | 'neon' | 'cyber' | 'minimal' | '3d';
  cardStyle?: 'flat' | 'elevated' | 'glass' | 'neon' | 'wireframe' | 'holographic' | 'brutalist' | 'frosted';
  theme?: 'dark' | 'light' | 'cyber' | 'minimal' | 'neon' | 'hacker' | 'vaporwave' | 'monochrome';
  avatarShape?: 'circle' | 'square' | 'rounded' | 'hexagon';
  layout?: 'center' | 'left' | 'right' | 'split';
  cursorTrail?: 'none' | 'glow' | 'particles' | 'matrix';
  pageTransition?: 'fade' | 'slide' | 'scale' | 'glitch';
  crtEffect?: boolean;
  glitchEffect?: boolean;
  bloomIntensity?: number;
  borderWeight?: number;
  fontWeight?: 'normal' | 'bold' | 'black';
  textTransform?: 'none' | 'uppercase' | 'lowercase';
}

export interface AnalyticsData {
  views: number;
  clicks: number;
  history: {
    date: string;
    views: number;
    clicks: number;
  }[];
}

export interface LeaderboardEntry {
  uid: string;
  username: string;
  displayName: string;
  avatarUrl?: string;
  views: number;
  likes: number;
  badges: string[];
  rank: number;
  isPro?: boolean;
}

export interface Feedback {
  id: string;
  uid: string;
  username: string;
  email: string;
  category: 'bug' | 'feature' | 'general';
  message: string;
  createdat: number;
}
