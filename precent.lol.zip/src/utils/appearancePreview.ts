// Lightweight appearance preview state
// This avoids React context re-renders by using a simple pub/sub pattern

import { AppearanceSettings } from '../types';

type Listener = (appearance: AppearanceSettings) => void;

let currentAppearance: AppearanceSettings | null = null;
const listeners = new Set<Listener>();

export function setPreviewAppearance(appearance: AppearanceSettings) {
  currentAppearance = appearance;
  // Notify all listeners synchronously
  listeners.forEach(listener => listener(appearance));
}

export function getPreviewAppearance(): AppearanceSettings | null {
  return currentAppearance;
}

export function subscribeToAppearance(listener: Listener): () => void {
  listeners.add(listener);
  // Return unsubscribe function
  return () => listeners.delete(listener);
}
