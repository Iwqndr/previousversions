export const sendReport = async (reason: string, details: string, userEmail?: string) => {
  const webhookUrl = 'https://discord.com/api/webhooks/1489814644469141544/om79O6uKORsf8dgFnYUag-zgvX0spoixgVEtKN3WWt6JGwLRPgQy-3-JRz5K7CgZuX5-';

  const embed = {
    title: "New Report Submitted",
    color: 0xff8800, // Neon orange
    fields: [
      { name: "User", value: userEmail || "Anonymous", inline: true },
      { name: "Report Reason", value: reason, inline: true },
      { name: "Additional Details", value: details, inline: false },
      { name: "Timestamp", value: new Date().toISOString(), inline: false }
    ],
    footer: { text: "precent.lol Report System" }
  };

  try {
    await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ embeds: [embed] })
    });
  } catch (error) {
    console.error('Failed to send report:', error);
  }
};
