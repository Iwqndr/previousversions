// Local storage persistence layer for offline dashboard testing
import { UserProfile, BioLink, AppearanceSettings, MusicTrack, MediaItem } from '../types';

const STORAGE_KEY = 'precent_dashboard_data';

// Default profile for offline testing
const DEFAULT_PROFILE: Partial<UserProfile> = {
  uid: 'demo-user-001',
  username: 'demo_user',
  displayName: 'Demo User',
  bio: 'Testing the dashboard offline 🚀',
  location: 'San Francisco, CA',
  avatarUrl: '',
  badges: ['developer', 'early_access', 'tester', 'verified'],
  links: [
    { id: '1', title: 'Portfolio', url: 'https://example.com', clicks: 234, active: true },
    { id: '2', title: 'Twitter', url: 'https://twitter.com', clicks: 189, active: true },
    { id: '3', title: 'GitHub', url: 'https://github.com', clicks: 456, active: true },
  ],
  appearance: {
    backgroundType: 'gradient',
    backgroundColor: '#050505',
    accentColor: '#ff8800',
    fontFamily: 'inter',
    glassmorphism: true,
    buttonStyle: 'rounded',
    cardStyle: 'glass',
    theme: 'dark',
    avatarShape: 'circle',
    layout: 'center',
  } as AppearanceSettings,
  music: [] as MusicTrack[],
  media: [] as MediaItem[],
  discord: {
    username: 'demo#1234',
    status: 'Online',
    active: false,
  },
  analytics: {
    views: 1247,
    clicks: 879,
    history: [],
  },
  likes: 142,
  isPro: false,
  plan: 'free',
  createdat: Date.now(),
};

export interface DashboardData {
  displayName: string;
  username: string;
  bio: string;
  location: string;
  avatarUrl: string;
  links: BioLink[];
  appearance: AppearanceSettings;
  music: MusicTrack[];
  media: MediaItem[];
  discord: {
    username: string;
    status: string;
    active: boolean;
  };
  badges: string[];
}

// Save dashboard data to localStorage
export function saveDashboardData(data: DashboardData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    console.log('✅ Dashboard data saved to localStorage');
  } catch (error) {
    console.error('❌ Failed to save dashboard data:', error);
  }
}

// Load dashboard data from localStorage
export function loadDashboardData(): DashboardData | null {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      console.log('ℹ️ No stored dashboard data found');
      return null;
    }
    const data = JSON.parse(stored) as DashboardData;
    console.log('✅ Dashboard data loaded from localStorage');
    return data;
  } catch (error) {
    console.error('❌ Failed to load dashboard data:', error);
    return null;
  }
}

// Get default profile data
export function getDefaultProfileData(): DashboardData {
  return {
    displayName: DEFAULT_PROFILE.displayName!,
    username: DEFAULT_PROFILE.username!,
    bio: DEFAULT_PROFILE.bio!,
    location: DEFAULT_PROFILE.location!,
    avatarUrl: DEFAULT_PROFILE.avatarUrl!,
    links: DEFAULT_PROFILE.links!,
    appearance: DEFAULT_PROFILE.appearance!,
    music: DEFAULT_PROFILE.music!,
    media: DEFAULT_PROFILE.media!,
    discord: DEFAULT_PROFILE.discord!,
    badges: DEFAULT_PROFILE.badges!,
  };
}

// Clear stored dashboard data
export function clearDashboardData(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
    console.log('✅ Dashboard data cleared from localStorage');
  } catch (error) {
    console.error('❌ Failed to clear dashboard data:', error);
  }
}

// Check if offline mode is enabled
export function isOfflineMode(): boolean {
  return localStorage.getItem('precent_offline_mode') === 'true';
}

// Enable/disable offline mode
export function setOfflineMode(enabled: boolean): void {
  localStorage.setItem('precent_offline_mode', enabled ? 'true' : 'false');
  console.log(`🔄 Offline mode ${enabled ? 'enabled' : 'disabled'}`);
}

// Initialize offline mode with default data
export function initOfflineMode(): DashboardData {
  const existing = loadDashboardData();
  if (existing) {
    return existing;
  }
  const defaults = getDefaultProfileData();
  saveDashboardData(defaults);
  return defaults;
}
