import { UserProfile, BioLink } from '../types';

const STORAGE_KEY = 'precent_local_profile';
const USERNAMES_KEY = 'precent_local_usernames';

export const localStorageService = {
  getProfile(): UserProfile | null {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : null;
  },

  saveProfile(profile: UserProfile): void {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
    
    // Also update username registry
    const usernames = this.getUsernames();
    usernames[profile.username.toLowerCase()] = profile.uid;
    localStorage.setItem(USERNAMES_KEY, JSON.stringify(usernames));
  },

  getUsernames(): Record<string, string> {
    const data = localStorage.getItem(USERNAMES_KEY);
    return data ? JSON.parse(data) : {};
  },

  isUsernameAvailable(username: string): boolean {
    const usernames = this.getUsernames();
    return !usernames[username.toLowerCase()];
  },

  clear(): void {
    localStorage.removeItem(STORAGE_KEY);
  }
};
