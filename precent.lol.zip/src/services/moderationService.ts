import { api } from '../lib/api';
import { BlacklistEntry, ModerationLog } from '../types';

export const moderationService = {
  async logAction(
    moderatorEmail: string,
    targetUser: string,
    action: string,
    reason: string,
    _metadata?: Record<string, any>
  ): Promise<void> {
    const webhookUrl = "https://discord.com/api/webhooks/1490134196876869682/-G3cEA2zWEt9kUd6lOizAuoNyb78niF_iL6bnnpJElpfAOsxPSq4WQsms2qriP87Ko4o";

    await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: `**Moderation Action**\n**Moderator:** ${moderatorEmail}\n**Target:** ${targetUser}\n**Action:** ${action}\n**Reason:** ${reason}`
      })
    }).catch(() => {});
  },

  async getLogs(limit?: number): Promise<ModerationLog[]> {
    try {
      const data = await api.getModerationLogs();
      return (data || []).slice(0, limit) as ModerationLog[];
    } catch { return []; }
  },

  async isBlacklisted(type: 'email' | 'ip' | 'username', value: string): Promise<boolean> {
    try {
      const entries = await api.getBlacklist();
      return entries.some((e: any) => e.type === type && e.value.toLowerCase() === value.toLowerCase());
    } catch { return false; }
  },

  async getBlacklistEntries(type?: 'email' | 'ip' | 'username'): Promise<BlacklistEntry[]> {
    try {
      const data = await api.getBlacklist();
      return type ? data.filter((e: any) => e.type === type) : data;
    } catch { return []; }
  },

  async removeFromBlacklist(id: string): Promise<void> {
    // Admin panel handles this directly
  },

  async getStats(): Promise<{
    totalUsers: number;
    suspendedUsers: number;
    bannedUsers: number;
    moderators: number;
    blacklistCount: number;
    recentActions: number;
  }> {
    try {
      const [users, blacklist, logs] = await Promise.all([
        api.getUsers(10000, 0),
        api.getBlacklist(),
        api.getModerationLogs(),
      ]);

      return {
        totalUsers: (users || []).length,
        suspendedUsers: (users || []).filter((u: any) => u.issuspended).length,
        bannedUsers: (users || []).filter((u: any) => u.role === 'banned').length,
        moderators: (users || []).filter((u: any) => u.role === 'moderator').length,
        blacklistCount: (blacklist || []).length,
        recentActions: (logs || []).filter((l: any) => l.tstamp > Date.now() - 24 * 60 * 60 * 1000).length,
      };
    } catch {
      return { totalUsers: 0, suspendedUsers: 0, bannedUsers: 0, moderators: 0, blacklistCount: 0, recentActions: 0 };
    }
  }
};
