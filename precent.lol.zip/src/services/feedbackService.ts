import { Feedback } from '../types';

export const feedbackService = {
  async submitFeedback(feedback: Omit<Feedback, 'id' | 'createdAt'>): Promise<void> {
    const webhookUrl = 'https://discord.com/api/webhooks/1489814644469141544/om79O6uKORsf8dgFnYUag-zgvX0spoixgVEtKN3WWt6JGwLRPgQy-3-JRz5K7CgZuX5-';

    const embed = {
      title: `New Feedback: ${feedback.category}`,
      color: 0xff8800, // Neon orange
      fields: [
        { name: "User", value: feedback.username || "Anonymous", inline: true },
        { name: "Email", value: feedback.email || "No email", inline: true },
        { name: "Message", value: feedback.message, inline: false },
        { name: "Timestamp", value: new Date().toISOString(), inline: false }
      ],
      footer: { text: "precent.lol Feedback System" }
    };

    try {
      await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ embeds: [embed] })
      });
    } catch (error) {
      console.error('Failed to send feedback:', error);
      throw error;
    }
  }
};
