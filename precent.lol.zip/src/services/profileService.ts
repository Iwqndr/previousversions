import { api } from '../lib/api';
import { getSupabase } from '../lib/supabase';
import { UserProfile } from '../types';
import { localStorageService } from './localStorageService';

export const isSupabaseConfigured = () => true;

export const profileService = {
  async createProfile(uid: string, data: { username: string; displayName: string; email: string; avatarUrl?: string }): Promise<void> {
    const isAdmin = data.email === 'defwar155@gmail.com';
    const username = data.username.toLowerCase();

    const localProfile: any = {
      uid, username, displayname: data.displayName,
      avatarurl: data.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${data.username}`,
      bio: 'Welcome to my profile!', location: '', links: [],
      appearance: { backgroundType: 'gradient', backgroundColor: '#050505', accentColor: '#ff8800', fontFamily: 'inter', glassmorphism: true, buttonStyle: 'rounded', cardStyle: 'glass', theme: 'dark', avatarShape: 'circle', layout: 'center', cursorTrail: 'none', pageTransition: 'fade', crtEffect: false, glitchEffect: false, bloomIntensity: 50, borderWeight: 1, fontWeight: 'normal', textTransform: 'none' },
      analytics: { views: 0, clicks: 0, history: [] }, badges: isAdmin ? ['Staff', 'Early Access', 'OG'] : ['Early Access', 'OG'],
      likes: 0, role: isAdmin ? 'admin' : 'user', issuspended: false, ispro: false, plan: 'free', createdat: Date.now(),
    };

    try {
      await api.createProfile({ uid, username, displayname: data.displayName, avatarurl: data.avatarUrl, email: data.email });
    } catch (error: any) {
      console.error('Error creating profile via Worker:', error);
      // Fallback to local storage
      localStorageService.saveProfile(localProfile);
    }
  },

  async getProfile(uid: string): Promise<UserProfile | null> {
    try {
      const data = await api.getProfileByUid(uid);
      return data ? this.normalizeProfile(data) : null;
    } catch {
      return localStorageService.getProfile();
    }
  },

  async updateProfile(uid: string, data: Partial<UserProfile>): Promise<void> {
    try {
      // Map frontend camelCase to Neon DB snake_case/camelCase columns
      const normalized: any = { uid };
      for (const [key, value] of Object.entries(data)) {
        switch (key) {
          case 'displayName': normalized.displayname = value; break;
          case 'display_name': normalized.displayname = value; break;
          case 'avatarUrl': normalized.avatarurl = value; break;
          case 'avatar_url': normalized.avatarurl = value; break;
          case 'bannerUrl': normalized.bannerurl = value; break;
          case 'banner_url': normalized.bannerurl = value; break;
          case 'isSuspended': normalized.issuspended = value; break;
          case 'is_suspended': normalized.issuspended = value; break;
          case 'isPro': normalized.ispro = value; break;
          case 'is_pro': normalized.ispro = value; break;
          default:
            // All other fields (bio, location, links, appearance, music, media, metadata, username, badges, etc.)
            // map directly as lowercase to match Neon schema
            normalized[key.toLowerCase()] = value;
        }
      }
      const result = await api.updateProfile(normalized);
      if (result) {
        const normalizedProfile = this.normalizeProfile(result);
        if (normalizedProfile) localStorageService.saveProfile(normalizedProfile);
      }
    } catch (error: any) {
      console.error('Error updating profile:', error);
      throw error;
    }
  },

  async incrementViews(uid: string, _viewerUid?: string): Promise<void> {
    try { await api.incrementViews(uid); } catch (e) { console.error('Error incrementing views:', e); }
  },

  async incrementLikes(uid: string, _likerUid?: string): Promise<void> {
    try {
      const profile = await api.getProfileByUid(uid);
      const likes = (profile?.likes || 0) + 1;
      await api.updateProfile({ uid, likes });
    } catch (e) { console.error('Error incrementing likes:', e); throw e; }
  },

  async getLeaderboard() {
    try {
      const data = await api.getLeaderboard();
      return (data || []).map((item: any, index: number) => ({
        ...this.normalizeProfile(item),
        views: item.analytics?.views || 0,
        likes: item.likes || 0,
        rank: index + 1,
      }));
    } catch {
      return [];
    }
  },

  async getAllUsers(): Promise<UserProfile[]> {
    try {
      const data = await api.getUsers(1000, 0);
      return (data || []).map((u: any) => this.normalizeProfile(u));
    } catch { return []; }
  },

  async updateUserStatus(_uid: string, _status: string): Promise<void> {
    // Handled via Worker API endpoints
  },

  async isUsernameAvailable(username: string): Promise<boolean> {
    try {
      const profile = await api.getProfileByUsername(username.toLowerCase());
      return !profile;
    } catch { return true; }
  },

  // Normalize Worker/Neon API response to match frontend types (camelCase)
  normalizeProfile(data: any): UserProfile | null {
    if (!data) return null;
    
    // Parse metadata if it's a string
    let metadata = data.metadata;
    if (typeof metadata === 'string') {
      try {
        metadata = JSON.parse(metadata);
      } catch {
        metadata = {};
      }
    }
    
    // Parse badges if it's a string
    let badges = data.badges;
    if (typeof badges === 'string') {
      try {
        badges = JSON.parse(badges);
      } catch {
        badges = [];
      }
    }
    
    return {
      uid: data.uid,
      username: data.username,
      displayName: data.displayname || data.display_name || data.displayName || '',
      email: data.email,
      bio: data.bio || 'Welcome to my profile!',
      avatarUrl: data.avatarurl || data.avatar_url || data.avatarUrl,
      bannerUrl: data.bannerurl || data.banner_url || data.bannerUrl,
      location: data.location || '',
      links: data.links || [],
      appearance: data.appearance || { backgroundType: 'gradient', backgroundColor: '#050505', accentColor: '#ff8800', fontFamily: 'inter', glassmorphism: true, buttonStyle: 'rounded', cardStyle: 'glass', theme: 'dark', avatarShape: 'circle', layout: 'center', cursorTrail: 'none', pageTransition: 'fade', crtEffect: false, glitchEffect: false, bloomIntensity: 50, borderWeight: 1, fontWeight: 'normal', textTransform: 'none' },
      analytics: data.analytics || { views: 0, clicks: 0, history: [] },
      badges: badges || [],
      likes: data.likes || 0,
      music: data.music || [],
      media: data.media || [],
      discord: data.discord,
      metadata: metadata,
      createdat: data.createdat || data.createdAt || Date.now(),
      isPro: data.ispro ?? data.is_pro ?? data.isPro ?? false,
      plan: data.plan || 'free',
      isSuspended: data.issuspended ?? data.is_suspended ?? data.isSuspended ?? false,
      isShadowBanned: data.isshadowbanned ?? data.is_shadow_banned ?? data.isShadowBanned ?? false,
      role: data.role || 'user',
      logintoken: data.logintoken || null,
    };
  },
};
