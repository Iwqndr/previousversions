import { supabase } from '../lib/supabase';
import { CommunityPost } from '../types';

export const communityService = {
  async fetchPosts(): Promise<CommunityPost[]> {
    const { data, error } = await supabase
      .from('posts')
      .select('*')
      .order('createdat', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async createPost(post: Omit<CommunityPost, 'id' | 'createdAt' | 'likes' | 'comments'>): Promise<void> {
    const { error } = await supabase
      .from('posts')
      .insert([{
        ...post,
        createdat: Date.now(),
        likes: 0,
        comments: 0,
      }]);
    if (error) throw error;
  },

  async uploadMedia(file: File): Promise<string> {
    const fileExt = file.name.split('.').pop();
    const fileName = `${Math.random()}.${fileExt}`;
    const filePath = `community/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('community-media')
      .upload(filePath, file);

    if (uploadError) throw uploadError;

    const { data } = supabase.storage
      .from('community-media')
      .getPublicUrl(filePath);

    return data.publicUrl;
  }
};
