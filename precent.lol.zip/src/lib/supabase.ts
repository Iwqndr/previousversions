import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { loadConfig } from './config';

let supabaseInstance: SupabaseClient | null = null;
let initPromise: Promise<SupabaseClient> | null = null;

export async function initSupabase() {
  if (supabaseInstance) return supabaseInstance;
  if (initPromise) return initPromise;

  initPromise = (async () => {
    const config = await loadConfig();
    supabaseInstance = createClient(config.supabaseUrl, config.supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
        flowType: 'pkce',
      },
    });

    supabaseInstance.auth.onAuthStateChange((_event, session) => {
      if (session?.access_token) {
        localStorage.setItem('sb-auth-token', session.access_token);
      } else {
        localStorage.removeItem('sb-auth-token');
      }
    });

    return supabaseInstance;
  })();

  return initPromise;
}

export function getSupabase() {
  if (!supabaseInstance) throw new Error('Supabase not initialized. Call initSupabase() first.');
  return supabaseInstance;
}

export { supabaseInstance as supabase };
