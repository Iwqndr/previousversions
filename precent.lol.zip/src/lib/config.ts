const WORKER_URL = 'https://scrtencrp.yumdelirious1.workers.dev';

let config: AppConfig | null = null;
let configPromise: Promise<AppConfig> | null = null;

export interface AppConfig {
  supabaseUrl: string;
  supabaseAnonKey: string;
  discordClientId: string;
  discordRedirectUri: string;
  stripePublishableKey: string;
}

export async function loadConfig(): Promise<AppConfig> {
  if (config) return config;
  if (configPromise) return configPromise;

  configPromise = (async () => {
    const response = await fetch(`${WORKER_URL}/api/config`);
    if (!response.ok) throw new Error(`Failed to load config: ${response.statusText}`);
    config = await response.json();
    return config;
  })();

  return configPromise;
}

export function getConfig(): AppConfig | null {
  return config;
}

export function getWorkerUrl(): string {
  return WORKER_URL;
}
