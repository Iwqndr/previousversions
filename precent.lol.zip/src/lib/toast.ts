// Simple toast notification system
type ToastType = 'success' | 'error' | 'warning' | 'info';

interface Toast {
  id: string;
  message: string;
  type: ToastType;
}

let toasts: Toast[] = [];
let toastListener: ((toasts: Toast[]) => void) | null = null;

export function subscribeToast(listener: (toasts: Toast[]) => void) {
  toastListener = listener;
  listener(toasts);
  return () => {
    toastListener = null;
  };
}

export function showToast(message: string, type: ToastType = 'info', duration = 4000) {
  const id = Math.random().toString(36).slice(2);
  const toast: Toast = { id, message, type };
  toasts = [...toasts, toast];
  if (toastListener) toastListener(toasts);

  setTimeout(() => {
    toasts = toasts.filter(t => t.id !== id);
    if (toastListener) toastListener(toasts);
  }, duration);
}

export function dismissToast(id: string) {
  toasts = toasts.filter(t => t.id !== id);
  if (toastListener) toastListener(toasts);
}

export function getToasts() {
  return toasts;
}
