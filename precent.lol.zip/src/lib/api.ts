import { getConfig, loadConfig } from './config';
import { getSupabase } from './supabase';

const WORKER_URL = 'https://scrtencrp.yumdelirious1.workers.dev';

async function getAuthHeader(): Promise<Record<string, string>> {
  try {
    const sb = getSupabase();
    const { data } = await sb.auth.getSession();
    if (data?.session?.access_token) {
      localStorage.setItem('sb-auth-token', data.session.access_token);
      return { Authorization: `Bearer ${data.session.access_token}` };
    }
  } catch {
    // Fallback to stored token
    const token = localStorage.getItem('sb-auth-token');
    if (token) return { Authorization: `Bearer ${token}` };
  }
  return {};
}

async function workerFetch(path: string, method: string = 'GET', body?: any) {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  const authHeaders = await getAuthHeader();
  Object.assign(headers, authHeaders);

  const response = await fetch(`${WORKER_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: response.statusText }));
    throw new Error(error.error || response.statusText);
  }

  return response.json();
}

export const api = {
  // Profile
  getProfileByUsername: (username: string) => workerFetch(`/api/profile/${username}`),
  getProfileByUid: (uid: string) => workerFetch(`/api/profile/by-uid/${uid}`),
  createProfile: (data: any) => workerFetch('/api/profile/create', 'POST', data),
  updateProfile: (data: any) => workerFetch('/api/profile/update', 'POST', data),

  // Users (admin)
  getUsers: (limit = 20, offset = 0, search = '') =>
    workerFetch(`/api/users?limit=${limit}&offset=${offset}&search=${encodeURIComponent(search)}`),
  getUsersCount: () => workerFetch('/api/users/count'),
  banUser: (uid: string, oldUsername: string) => workerFetch('/api/users/ban', 'POST', { uid, oldUsername }),
  suspendUser: (uid: string, is_suspended: boolean) => workerFetch('/api/users/suspend', 'POST', { uid, is_suspended }),
  setPremium: (uid: string, is_pro: boolean, username: string, options?: { premium_type?: 'lifetime' | 'monthly'; months?: number; duration_value?: number; duration_type?: 'days' | 'weeks' | 'months' }) =>
    workerFetch('/api/users/premium', 'POST', { uid, is_pro, username, premium_type: options?.premium_type || 'monthly', months: options?.months, duration_value: options?.duration_value, duration_type: options?.duration_type }),
  giveBadge: (uid: string, badge: string) => workerFetch('/api/users/badge', 'POST', { uid, badge }),
  blacklistUser: (type: string, value: string, reason: string) =>
    workerFetch('/api/users/blacklist', 'POST', { type, value, reason }),

  // Blacklist
  getBlacklist: () => workerFetch('/api/blacklist'),
  removeFromBlacklist: (id: string) => workerFetch('/api/blacklist/delete', 'POST', { id }),

  // Reports
  getReports: () => workerFetch('/api/reports'),
  getUserReports: (uid: string) => workerFetch(`/api/reports/user/${uid}`),
  createReport: (reported_uid: string, reason: string) =>
    workerFetch('/api/reports/create', 'POST', { reported_uid, reason }),
  resolveReport: (reportId: string, status: string) =>
    workerFetch('/api/reports/resolve', 'POST', { reportId, status }),

  // Moderation logs
  getModerationLogs: () => workerFetch('/api/moderation-logs'),

  // Credits
  getCredits: () => workerFetch('/api/credits'),
  createCredit: (data: any) => workerFetch('/api/credits/create', 'POST', data),
  updateCredit: (data: any) => workerFetch('/api/credits/update', 'POST', data),
  deleteCredit: (id: string) => workerFetch('/api/credits/delete', 'POST', { id }),

  // Leaderboard
  getLeaderboard: () => workerFetch('/api/leaderboard'),

  // Analytics
  incrementViews: (uid: string) => workerFetch('/api/increment-views', 'POST', { uid }),

  // Tokens
  getToken: (uid?: string) => workerFetch(`/api/token/get${uid ? `?uid=${uid}` : ''}`),
  resetToken: (uid?: string) => workerFetch('/api/token/reset', 'POST', { uid }),
  loginWithToken: (token: string) => workerFetch('/api/token/login', 'POST', { token }),

  // Site Settings
  getSettings: () => workerFetch('/api/settings'),
  updateSettings: (data: any) => workerFetch('/api/settings/update', 'POST', data),

  // Shadow Ban
  shadowbanUser: (uid: string, username: string, is_shadow_banned: boolean) =>
    workerFetch('/api/users/shadowban', 'POST', { uid, username, is_shadow_banned }),

  // Change History
  getChangeHistory: (targetUid?: string, limit: number = 50) =>
    workerFetch(`/api/change-history${targetUid ? `?target_uid=${targetUid}` : ''}&limit=${limit}`),

  // Moderation
  generateModKey: () => workerFetch('/mod/key/generate', 'POST', {}),
};
