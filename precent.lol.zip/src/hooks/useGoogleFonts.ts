import { useEffect } from 'react';

// Google Fonts loader hook
export function useGoogleFont(font: string) {
  useEffect(() => {
    if (!font || font === 'inter' || font === 'mono') return;

    const fontMap: Record<string, string> = {
      'outfit': 'Outfit:wght@400;700',
      'space': 'Space+Grotesk:wght@400;700',
      'roboto': 'Roboto:wght@400;700',
      'lato': 'Lato:wght@400;700',
      'playfair': 'Playfair+Display:wght@400;700',
      'rubik': 'Rubik:wght@400;700',
      'syne': 'Syne:wght@400;800',
      'bricolage': 'Bricolage+Grotesque:wght@400;700',
      'clash': 'Clash+Display:wght@400;700',
      'chillax': 'Chillax:wght@400;700',
    };

    const fontName = fontMap[font];
    if (!fontName) return;

    const link = document.createElement('link');
    link.href = `https://fonts.googleapis.com/css2?family=${fontName}&display=swap`;
    link.rel = 'stylesheet';
    link.id = `google-font-${font}`;

    // Only add if not already present
    if (!document.getElementById(link.id)) {
      document.head.appendChild(link);
    }

    return () => {
      // Don't remove on cleanup to avoid flicker during re-renders
    };
  }, [font]);
}

// Load multiple fonts at once
export function useGoogleFonts(fonts: string[]) {
  fonts.forEach(useGoogleFont);
}
