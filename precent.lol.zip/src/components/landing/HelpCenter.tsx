import { motion } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { Search, Book, MessageCircle, FileText, ChevronRight } from 'lucide-react';
import { NeonButton } from '../ui/NeonButton';

const categories = [
  {
    icon: <Book className="text-neon-orange" />,
    title: 'Getting Started',
    description: 'Learn how to set up your profile and customize your bio.',
    articles: 12
  },
  {
    icon: <FileText className="text-neon-orange" />,
    title: 'Account & Billing',
    description: 'Manage your subscription, payments, and account settings.',
    articles: 8
  },
  {
    icon: <MessageCircle className="text-neon-orange" />,
    title: 'Community & Social',
    description: 'Connect with others and manage your social links.',
    articles: 15
  }
];

const popularArticles = [
  'How to customize your profile',
  'Setting up your music player',
  'Upgrading to Premium',
  'Customizing your theme',
  'Understanding analytics'
];

export function HelpCenter({ onBack }: { onBack: () => void }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="max-w-6xl mx-auto py-24 px-6 relative"
    >
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-6xl font-black mb-6 tracking-tighter">
          How can we <span className="text-neon-orange">help?</span>
        </h1>
        <div className="max-w-2xl mx-auto relative">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
            <Search className="text-white/40" size={20} />
          </div>
          <input 
            type="text" 
            placeholder="Search for articles, guides, and FAQs..." 
            className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-white/40 focus:outline-none focus:border-neon-orange/50 transition-all font-medium"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        {categories.map((category, index) => (
          <GlassCard key={index} className="p-8 hover:border-neon-orange/30 transition-all cursor-pointer group border-white/10 bg-white/5">
            <div className="w-12 h-12 rounded-xl bg-neon-orange/10 flex items-center justify-center mb-6">
              {category.icon}
            </div>
            <h3 className="text-xl font-bold mb-2 group-hover:text-neon-orange transition-colors tracking-tight">{category.title}</h3>
            <p className="text-white/50 text-sm mb-4 font-medium">{category.description}</p>
            <div className="text-[10px] font-bold text-white/30 uppercase tracking-widest">
              {category.articles} Articles
            </div>
          </GlassCard>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div>
          <h3 className="text-2xl font-black mb-6 tracking-tight">Popular Articles</h3>
          <div className="space-y-3">
            {popularArticles.map((article, index) => (
              <button key={index} className="w-full flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-neon-orange/30 transition-all group text-left">
                <span className="font-bold text-white/80 group-hover:text-white tracking-tight">{article}</span>
                <ChevronRight size={16} className="text-white/30 group-hover:text-neon-orange" />
              </button>
            ))}
          </div>
        </div>
        
        <GlassCard className="p-8 bg-gradient-to-br from-neon-orange/10 to-transparent border-neon-orange/20 flex flex-col justify-center items-center text-center bg-white/5">
          <MessageCircle size={48} className="text-neon-orange mb-6" />
          <h3 className="text-2xl font-black mb-2 tracking-tight">Still need help?</h3>
          <p className="text-white/60 mb-8 font-medium">Our support team is always ready to help you with any issues.</p>
          <NeonButton onClick={onBack}>Contact Support</NeonButton>
        </GlassCard>
      </div>
    </motion.div>
  );
}
