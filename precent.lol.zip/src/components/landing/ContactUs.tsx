import React, { useState } from 'react';
import { motion } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { Mail, MessageSquare, Send, CheckCircle2, AlertCircle } from 'lucide-react';
import { NeonButton } from '../ui/NeonButton';

export function ContactUs({ onBack }: { onBack: () => void }) {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const response = await fetch('https://discord.com/api/webhooks/1489814644469141544/om79O6uKORsf8dgFnYUag-zgvX0spoixgVEtKN3WWt6JGwLRPgQy-3-JRz5K7CgZuX5-', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          embeds: [{
            title: 'New Contact Form Submission',
            description: `**Subject:** ${e.currentTarget.querySelector('select')?.value}\n\n**Message:**\n${e.currentTarget.querySelector('textarea')?.value}`,
            color: 0xff8800
          }]
        })
      });

      if (!response.ok) throw new Error('Failed to send message');
      
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onBack();
      }, 3000);
    } catch (err) {
      console.error(err);
      alert('Failed to send message. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="max-w-6xl mx-auto py-24 px-6 relative"
    >
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-6xl font-black mb-6 tracking-tighter">
          Get in <span className="text-neon-orange">Touch</span>
        </h1>
        <p className="text-lg md:text-xl text-white/60 max-w-2xl mx-auto font-medium">
          Have a question, feedback, or need support? We'd love to hear from you.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <GlassCard className="p-6 border-white/10 bg-white/5">
            <div className="w-10 h-10 rounded-xl bg-neon-orange/10 flex items-center justify-center mb-4">
              <Mail className="text-neon-orange" size={20} />
            </div>
            <h3 className="font-bold mb-1 tracking-tight">Email Us</h3>
            <p className="text-sm text-white/50 mb-4 font-medium">For general inquiries and support.</p>
            <a href="mailto:support@precent.lol" className="text-neon-orange font-bold text-sm hover:underline">support@precent.lol</a>
          </GlassCard>
          
          <GlassCard className="p-6 border-white/10 bg-white/5">
            <div className="w-10 h-10 rounded-xl bg-neon-orange/10 flex items-center justify-center mb-4">
              <MessageSquare className="text-neon-orange" size={20} />
            </div>
            <h3 className="font-bold mb-1 tracking-tight">Discord Community</h3>
            <p className="text-sm text-white/50 mb-4 font-medium">Join our Discord for real-time help.</p>
            <a href="https://discord.gg/tMcqK56rgQ" target="_blank" rel="noopener noreferrer" className="text-neon-orange font-bold text-sm hover:underline">Join Server</a>
          </GlassCard>
        </div>

        <div className="lg:col-span-2">
          <GlassCard className="p-8 border-white/10 bg-white/5">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-black text-white/30 uppercase tracking-widest">Name</label>
                  <input 
                    type="text" 
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-neon-orange/50 transition-all font-medium"
                    placeholder="John Doe"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-white/30 uppercase tracking-widest">Email</label>
                  <input 
                    type="email" 
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-neon-orange/50 transition-all font-medium"
                    placeholder="john@example.com"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-xs font-black text-white/30 uppercase tracking-widest">Subject</label>
                <select className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-neon-orange/50 transition-all appearance-none font-medium">
                  <option value="support">General Support</option>
                  <option value="billing">Billing Issue</option>
                  <option value="bug">Report a Bug</option>
                  <option value="partnership">Partnership Inquiry</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-white/30 uppercase tracking-widest">Message</label>
                <textarea 
                  required
                  className="w-full h-32 bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-neon-orange/50 transition-all resize-none font-medium"
                  placeholder="How can we help you?"
                />
              </div>

              <div className="flex items-center justify-between pt-4">
                {success ? (
                  <div className="flex items-center gap-2 text-neon-orange text-sm font-bold animate-in fade-in">
                    <CheckCircle2 size={18} /> Message sent successfully!
                  </div>
                ) : (
                  <div />
                )}
                <NeonButton type="submit" disabled={loading || success}>
                  {loading ? 'Sending...' : (
                    <span className="flex items-center gap-2">
                      <Send size={16} /> Send Message
                    </span>
                  )}
                </NeonButton>
              </div>
            </form>
          </GlassCard>
        </div>
      </div>
    </motion.div>
  );
}
