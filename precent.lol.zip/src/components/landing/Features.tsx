import { motion } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { Music, Layout, BarChart3, ShieldCheck, Zap, Globe, Crown } from 'lucide-react';

const features = [
  {
    icon: <Zap className="text-neon-orange" />,
    title: 'Instant Setup',
    description: 'Create your profile in seconds with our intuitive, real-time editor.',
    isPremium: false
  },
  {
    icon: <Music className="text-neon-orange" />,
    title: 'Music Player',
    description: 'Embed your favorite tracks from Spotify, SoundCloud, or Apple Music.',
    isPremium: false
  },
  {
    icon: <Layout className="text-neon-orange" />,
    title: 'Glassmorphism',
    description: 'Premium, futuristic design that makes your bio stand out from the crowd.',
    isPremium: false
  },
  {
    icon: <BarChart3 className="text-neon-orange" />,
    title: 'Deep Analytics',
    description: 'Track views, clicks, and engagement with beautiful animated charts.',
    isPremium: true
  },
  {
    icon: <ShieldCheck className="text-neon-orange" />,
    title: 'Verified Badge',
    description: 'Get a verified badge on your profile to show authenticity.',
    isPremium: true
  },
  {
    icon: <Globe className="text-neon-orange" />,
    title: 'Custom Themes',
    description: 'Unlock animated backgrounds and custom fonts for your profile.',
    isPremium: true
  }
];

export function Features() {
  return (
    <section className="py-24 relative overflow-hidden bg-[#0d0d0d]">
      {/* Background Grid */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 scanlines opacity-10" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,136,0,0.05),transparent_70%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:6rem_6rem]" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-6xl font-black mb-6 tracking-tighter bg-clip-text text-transparent bg-gradient-to-b from-white to-white/50">
            Next-Gen <span className="text-neon-orange">Features</span>
          </h2>
          <p className="text-lg md:text-xl text-white/40 max-w-2xl mx-auto font-medium">
            Everything you need to build a premium digital identity.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <GlassCard 
              key={index} 
              className="hover:border-neon-orange/50 hover:shadow-[0_0_40px_rgba(255,136,0,0.15)] relative border-white/10 bg-white/5 group transition-all duration-500"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
            >
              {feature.isPremium && (
                <div className="absolute top-6 right-6 flex items-center gap-1 bg-neon-orange/10 text-neon-orange px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border border-neon-orange/20">
                  <Crown size={12} /> Premium
                </div>
              )}
              <div className="w-16 h-16 rounded-2xl glass flex items-center justify-center mb-8 border-neon-orange/20 bg-white/5 group-hover:bg-neon-orange/10 transition-colors duration-500">
                {feature.icon}
              </div>
              <h3 className="text-2xl font-black mb-4 tracking-tight group-hover:text-neon-orange transition-colors">{feature.title}</h3>
              <p className="text-white/40 leading-relaxed font-medium text-sm">
                {feature.description}
              </p>
            </GlassCard>
          ))}
        </div>
      </div>
    </section>
  );
}
