import { motion } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { CheckCircle2, Zap } from 'lucide-react';
import { NeonButton } from '../ui/NeonButton';

export function Pricing() {
  return (
    <section id="pricing" className="py-24 relative overflow-hidden bg-[#0d0d0d]">
      {/* Background Grid */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(255,136,0,0.05),transparent_70%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:4rem_4rem]" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-6xl font-black mb-6 tracking-tighter">
            Simple <span className="text-neon-orange">Subscriptions</span>
          </h2>
          <p className="text-lg md:text-xl text-white/60 max-w-2xl mx-auto font-medium">
            Choose the plan that fits your needs. Upgrade anytime.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Free Plan */}
          <GlassCard className="p-8 border-white/10 relative bg-white/5">
            <h3 className="text-2xl font-black mb-2 tracking-tight">Free</h3>
            <p className="text-white/50 mb-6 font-medium">Perfect for getting started.</p>
            <div className="flex items-end gap-2 mb-8">
              <span className="text-5xl font-black">$0</span>
              <span className="text-white/40 font-bold mb-1">/forever</span>
            </div>
            <ul className="space-y-4 mb-8">
              <li className="flex items-center gap-3 text-white/70 font-medium">
                <CheckCircle2 size={18} className="text-neon-orange" /> Basic Profile Customization
              </li>
              <li className="flex items-center gap-3 text-white/70 font-medium">
                <CheckCircle2 size={18} className="text-neon-orange" /> Unlimited Links
              </li>
              <li className="flex items-center gap-3 text-white/70 font-medium">
                <CheckCircle2 size={18} className="text-neon-orange" /> Standard Analytics
              </li>
              <li className="flex items-center gap-3 text-white/70 font-medium">
                <CheckCircle2 size={18} className="text-neon-orange" /> Community Access
              </li>
            </ul>
            <NeonButton variant="outline" className="w-full">Get Started</NeonButton>
          </GlassCard>

          {/* Premium Plan */}
          <GlassCard className="p-8 border-neon-orange/30 relative overflow-hidden bg-gradient-to-br from-neon-orange/10 to-transparent bg-white/5">
            <div className="absolute top-0 right-0 bg-neon-orange text-black text-[10px] font-black px-3 py-1 rounded-bl-lg uppercase tracking-wider">
              Most Popular
            </div>
            <h3 className="text-2xl font-black mb-2 text-neon-orange flex items-center gap-2 tracking-tight">
              <Zap size={24} /> Premium
            </h3>
            <p className="text-white/50 mb-6 font-medium">Unlock your full potential.</p>
            <div className="flex items-end gap-2 mb-8">
              <span className="text-5xl font-black">$1.99</span>
              <span className="text-white/40 font-bold mb-1">/month</span>
            </div>
            <ul className="space-y-4 mb-8">
              <li className="flex items-center gap-3 text-white font-medium">
                <CheckCircle2 size={18} className="text-neon-orange" /> Everything in Free
              </li>
              <li className="flex items-center gap-3 text-white font-medium">
                <CheckCircle2 size={18} className="text-neon-orange" /> Animated Backgrounds
              </li>
              <li className="flex items-center gap-3 text-white font-medium">
                <CheckCircle2 size={18} className="text-neon-orange" /> Custom Themes & Fonts
              </li>
              <li className="flex items-center gap-3 text-white font-medium">
                <CheckCircle2 size={18} className="text-neon-orange" /> Advanced Analytics
              </li>
              <li className="flex items-center gap-3 text-white font-medium">
                <CheckCircle2 size={18} className="text-neon-orange" /> Premium Badge
              </li>
              <li className="flex items-center gap-3 text-white font-medium">
                <CheckCircle2 size={18} className="text-neon-orange" /> Priority Support
              </li>
            </ul>
            <NeonButton className="w-full">Upgrade to Premium</NeonButton>
          </GlassCard>

          {/* Lifetime Plan */}
          <GlassCard className="p-8 border-purple-500/30 relative overflow-hidden bg-gradient-to-br from-purple-500/10 to-transparent bg-white/5">
            <div className="absolute top-0 right-0 bg-purple-500 text-white text-[10px] font-black px-3 py-1 rounded-bl-lg uppercase tracking-wider">
              Best Value
            </div>
            <h3 className="text-2xl font-black mb-2 text-purple-500 flex items-center gap-2 tracking-tight">
              <Zap size={24} /> Lifetime
            </h3>
            <p className="text-white/50 mb-6 font-medium">One-time payment, forever access.</p>
            <div className="flex items-end gap-2 mb-8">
              <span className="text-5xl font-black">$9.99</span>
              <span className="text-white/40 font-bold mb-1">/one-time</span>
            </div>
            <ul className="space-y-4 mb-8">
              <li className="flex items-center gap-3 text-white font-medium">
                <CheckCircle2 size={18} className="text-purple-500" /> Everything in Premium
              </li>
              <li className="flex items-center gap-3 text-white font-medium">
                <CheckCircle2 size={18} className="text-purple-500" /> Unlimited Analytics History
              </li>
              <li className="flex items-center gap-3 text-white font-medium">
                <CheckCircle2 size={18} className="text-purple-500" /> 24/7 Priority Support
              </li>
              <li className="flex items-center gap-3 text-white font-medium">
                <CheckCircle2 size={18} className="text-purple-500" /> Lifetime Updates
              </li>
              <li className="flex items-center gap-3 text-white font-medium">
                <CheckCircle2 size={18} className="text-purple-500" /> Exclusive Lifetime Premium Badge
              </li>
              <li className="flex items-center gap-3 text-white font-medium">
                <CheckCircle2 size={18} className="text-purple-500" /> Early Access to New Features
              </li>
            </ul>
            <NeonButton className="w-full bg-purple-500 hover:bg-purple-600 border-purple-500">Upgrade to Lifetime Premium</NeonButton>
          </GlassCard>
        </div>
      </div>
    </section>
  );
}
