import { useState, useEffect } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import { NeonButton } from '../ui/NeonButton';
import { ArrowRight, Sparkles, Trophy, Zap, ShieldCheck, Star } from 'lucide-react';

interface HeroProps {
  onGetStarted: () => void;
  onViewLeaderboard: () => void;
}

export function Hero({ onGetStarted, onViewLeaderboard }: HeroProps) {
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springConfig = { damping: 25, stiffness: 150 };
  const dx = useSpring(mouseX, springConfig);
  const dy = useSpring(mouseY, springConfig);

  const rotateX = useTransform(dy, [-300, 300], [10, -10]);
  const rotateY = useTransform(dx, [-300, 300], [-10, 10]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e;
      const { innerWidth, innerHeight } = window;
      mouseX.set(clientX - innerWidth / 2);
      mouseY.set(clientY - innerHeight / 2);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden bg-[#0d0d0d]">
      {/* Futuristic Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 scanlines opacity-20" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,136,0,0.05),transparent_70%)]" />
        <div className="absolute top-1/4 -left-20 w-96 h-96 bg-neon-orange/10 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-neon-orange/10 blur-[120px] rounded-full animate-pulse" style={{ animationDelay: '1s' }} />
        
        {/* Grid lines */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:6rem_6rem] [mask-image:radial-gradient(ellipse_70%_60%_at_50%_50%,#000_70%,transparent_100%)]" />
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          style={{ rotateX, rotateY, perspective: 1000 }}
          className="text-center"
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-neon-orange text-xs font-black uppercase tracking-[0.2em] mb-8 backdrop-blur-md shadow-[0_0_20px_rgba(255,136,0,0.1)]"
          >
            <Zap size={14} className="fill-neon-orange" />
            <span>The Future of Bio Links</span>
            <div className="w-1 h-1 rounded-full bg-neon-orange animate-ping" />
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-6xl md:text-9xl font-black tracking-tighter mb-8 leading-[0.9] perspective-1000"
          >
            <span className="block text-white/90">DESIGN YOUR</span>
            <span className="relative inline-block">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-orange via-cyan to-neon-orange bg-[length:200%_auto] animate-gradient-x">
                CYBER IDENTITY
              </span>
              {/* Decorative elements */}
              <motion.div 
                className="absolute -top-4 -right-8 text-neon-orange opacity-50"
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              >
                <Star size={24} />
              </motion.div>
            </span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg md:text-xl text-white/40 max-w-2xl mx-auto mb-12 leading-relaxed font-medium"
          >
            Experience the most advanced bio-link platform ever created. 
            <span className="text-white/80"> Neon aesthetics, real-time data, and elite customization </span> 
            at your fingertips.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-6"
          >
            <NeonButton 
              size="lg" 
              className="w-full sm:w-auto px-10 py-5 text-xl font-black group relative overflow-hidden" 
              onClick={onGetStarted}
            >
              <span className="relative z-10 flex items-center gap-3">
                CLAIM YOUR URL
                <ArrowRight size={24} className="group-hover:translate-x-1 transition-transform" />
              </span>
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
            </NeonButton>
            
            <button 
              onClick={onViewLeaderboard}
              className="w-full sm:w-auto flex items-center justify-center gap-3 px-10 py-5 text-xl font-black text-white/60 hover:text-white transition-all group relative"
            >
              <Trophy size={24} className="group-hover:text-neon-orange transition-colors" />
              <span>LEADERBOARD</span>
              <div className="absolute bottom-0 left-0 w-0 h-[2px] bg-neon-orange group-hover:w-full transition-all duration-500 shadow-[0_0_10px_#ff8800]" />
            </button>
          </motion.div>

          {/* Stats Preview */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 1 }}
            className="mt-24 flex flex-wrap justify-center gap-12 text-white/20"
          >
            <div className="flex flex-col items-center">
              <span className="text-3xl font-black text-white/60">50K+</span>
              <span className="text-[10px] font-bold uppercase tracking-[0.3em]">Users</span>
            </div>
            <div className="w-px h-12 bg-white/5" />
            <div className="flex flex-col items-center">
              <span className="text-3xl font-black text-white/60">1.2M</span>
              <span className="text-[10px] font-bold uppercase tracking-[0.3em]">Views</span>
            </div>
            <div className="w-px h-12 bg-white/5" />
            <div className="flex flex-col items-center">
              <span className="text-3xl font-black text-white/60">99.9%</span>
              <span className="text-[10px] font-bold uppercase tracking-[0.3em]">Uptime</span>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div 
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-6 h-10 rounded-full border-2 border-white/10 flex justify-center p-1">
          <div className="w-1 h-2 bg-neon-orange rounded-full" />
        </div>
      </motion.div>
    </section>
  );
}
