import React, { useState, useEffect } from 'react';
import { GlassCard } from '../ui/GlassCard';
import { profileService } from '@/src/services/profileService';
import { moderationService } from '@/src/services/moderationService';
import { UserProfile } from '@/src/types';
import { Search, Shield, Ban, UserX, AlertTriangle, CheckCircle } from 'lucide-react';

export function ModerationPanel() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      const allUsers = await profileService.getAllUsers();
      setUsers(allUsers);
      setLoading(false);
    };
    fetchUsers();
  }, []);

  const filteredUsers = users.filter(user => 
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.displayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.uid.includes(searchTerm)
  );

  const handleAction = async (uid: string, action: 'Active' | 'Suspended' | 'Banned', reason: string) => {
    await profileService.updateUserStatus(uid, action);
    await moderationService.logAction('defwar155@gmail.com', uid, action, reason);
    const allUsers = await profileService.getAllUsers();
    setUsers(allUsers);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <h2 className="text-2xl font-black text-white">Moderation Panel</h2>
      
      <div className="relative group w-full max-w-md">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-neon-orange transition-colors" size={18} />
        <input 
          type="text" 
          placeholder="Search by username, display name, or ID..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-neon-orange/50 transition-all"
        />
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredUsers.map(user => (
          <GlassCard key={user.uid} className="p-4 flex items-center justify-between">
            <div>
              <p className="font-bold text-white">{user.displayName} (@{user.username})</p>
              <p className="text-xs text-white/40">{user.email}</p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => handleAction(user.uid, 'Active', 'Unbanned/Unsuspended')} className="p-2 rounded-lg bg-green-500/10 text-green-500 hover:bg-green-500/20"><CheckCircle size={16} /></button>
              <button onClick={() => handleAction(user.uid, 'Suspended', 'Suspended by admin')} className="p-2 rounded-lg bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20"><AlertTriangle size={16} /></button>
              <button onClick={() => handleAction(user.uid, 'Banned', 'Banned by admin')} className="p-2 rounded-lg bg-red-500/10 text-red-500 hover:bg-red-500/20"><Ban size={16} /></button>
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}
