import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Shield, X, User, BadgeCheck, Ban, UserMinus, Search, Trash2,
  AlertCircle, CheckCircle2, Users, FileText, ShieldCheck,
  RefreshCw, Clock, Crown, Lock, Unlock, Activity, Flag, BarChart3,
  UserPlus, Power, CreditCard, ChevronDown, Plus, Edit3, Eye, MessageSquare, Copy, Key, EyeOff,
  Code, Star, Rocket, Flame, FlaskConical, Trophy, Gem, Sparkles, Medal, Target, Award, Scale, BarChart3 as BarChartIcon
} from 'lucide-react';
import { getSupabase } from '../../lib/supabase';
import { api } from '../../lib/api';
import { UserProfile, CreditEntry } from '../../types';
import { GlassCard } from '../ui/GlassCard';
import { NeonButton } from '../ui/NeonButton';
import { cn } from '../../lib/utils';
import { showToast } from '../../lib/toast';
import { BADGES, getSortedBadges } from '../ui/badges/badgeDefinitions';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

type TabType = 'users' | 'reports' | 'credits' | 'analytics';

interface Report {
  id: string;
  reporter_uid: string | null;
  reported_uid: string;
  reason: string;
  status: string;
  createdat: number;
}

const USERS_PER_PAGE = 20;

export function AdminPanel({ isOpen, onClose }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<TabType>('users');
  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [credits, setCredits] = useState<CreditEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  
  // Users pagination
  const [displayedUsers, setDisplayedUsers] = useState<UserProfile[]>([]);
  const [usersPage, setUsersPage] = useState(0);
  const [hasMoreUsers, setHasMoreUsers] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);

  // User profile modal
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [userProfileTab, setUserProfileTab] = useState<'overview' | 'badges' | 'reports' | 'actions' | 'history'>('overview');
  const [userReports, setUserReports] = useState<Report[]>([]);
  const [userChangeHistory, setUserChangeHistory] = useState<any[]>([]);
  const [badgeInput, setBadgeInput] = useState('');
  
  // Credits management
  const [editingCredit, setEditingCredit] = useState<CreditEntry | null>(null);
  const [showCreditForm, setShowCreditForm] = useState(false);
  const [creditForm, setCreditForm] = useState({
    name: '',
    role: '',
    roleType: 'team' as 'team' | 'special_thanks',
    quote: '',
    avatar: '',
    link: '',
    highlighted: false,
    order: 0,
    active: true
  });

  // Premium give modal
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [premiumType, setPremiumType] = useState<'lifetime' | 'monthly'>('monthly');
  const [premiumMonths, setPremiumMonths] = useState(1);
  const [premiumTargetUser, setPremiumTargetUser] = useState<UserProfile | null>(null);
  const [selectedUserToken, setSelectedUserToken] = useState<string | null>(null);
  const [showToken, setShowToken] = useState(false);
  const [copiedToken, setCopiedToken] = useState(false);
  const [durationType, setDurationType] = useState<'days' | 'weeks' | 'months'>('months');
  const [durationValue, setDurationValue] = useState(1);
  const [isEditingPremium, setIsEditingPremium] = useState(false);

  const AVAILABLE_BADGES = Object.keys(BADGES);
  const BADGE_ICONS = Object.fromEntries(Object.entries(BADGES).map(([id, badge]) => [id, badge.icon]));

  useEffect(() => {
    if (isOpen) {
      loadUser();
      loadAllData();
    }
  }, [isOpen]);

  useEffect(() => {
    if (isOpen && activeTab === 'users') {
      loadUsersPage(0, true);
    }
  }, [isOpen, activeTab, searchQuery]);

  const loadUser = async () => {
    try {
      const sb = await getSupabase();
      const { data: { user } } = await sb.auth.getUser();
      if (user) setCurrentUser(user);
    } catch (e) { console.error(e); }
  };

  const loadAllData = async () => {
    setLoading(true);
    await Promise.all([loadReports(), loadCredits()]);
    setLoading(false);
  };

  const loadUsersPage = async (page: number, reset: boolean = false) => {
    if (!hasMoreUsers && !reset) return;
    setLoadingMore(true);
    const limit = USERS_PER_PAGE;
    const offset = page * USERS_PER_PAGE;
    
    try {
      const data = await api.getUsers(limit, offset, searchQuery);
      if (reset) {
        setDisplayedUsers(data || []);
        setUsersPage(0);
      } else {
        setDisplayedUsers(prev => [...prev, ...(data || [])]);
        setUsersPage(page);
      }
      setHasMoreUsers((data || []).length === USERS_PER_PAGE);
    } catch (e: any) {
      showToast(e.message || 'Failed to load users', 'error');
    }
    setLoadingMore(false);
  };

  const loadReports = async () => {
    try {
      const data = await api.getReports();
      if (data) setReports(data);
    } catch (e) { console.error(e); }
  };

  const loadCredits = async () => {
    try {
      const data = await api.getCredits();
      if (data) setCredits(data);
    } catch (e) { console.error(e); }
  };

  const loadUserReports = async (uid: string) => {
    try {
      const data = await api.getUserReports(uid);
      if (data) setUserReports(data);
    } catch (e) { console.error(e); }
  };

  const giveBadge = async (uid: string, badge: string) => {
    const user = users.find(u => u.uid === uid) || displayedUsers.find(u => u.uid === uid);
    if (!user) return;
    const newBadges = user.badges?.includes(badge) ? user.badges.filter((b: string) => b !== badge) : [...(user.badges || []), badge];
    setDisplayedUsers(prev => prev.map(u => u.uid === uid ? { ...u, badges: newBadges } : u));
    setSelectedUser(prev => prev && prev.uid === uid ? { ...prev, badges: newBadges } : prev);
    try {
      const result = await api.giveBadge(uid, badge);
      showToast(`${badge} ${user.badges?.includes(badge) ? 'removed from' : 'given to'} ${user.username}`, 'success');
      if (result) {
        setDisplayedUsers(prev => prev.map(u => u.uid === uid ? result : u));
        setSelectedUser(prev => prev && prev.uid === uid ? result : prev);
      }
    } catch (e: any) {
      showToast(e.message, 'error');
      setDisplayedUsers(prev => prev.map(u => u.uid === uid ? { ...u, badges: user.badges } : u));
      setSelectedUser(prev => prev && prev.uid === uid ? { ...prev, badges: user.badges } : prev);
    }
  };

  const setPremium = async (uid: string, isPro: boolean, premium_type: 'lifetime' | 'monthly' = 'monthly', durationValueLocal: number = 1, durationTypeLocal: 'days' | 'weeks' | 'months' = 'months') => {
    const user = users.find(u => u.uid === uid) || displayedUsers.find(u => u.uid === uid);
    if (!user) return;
    
    const newBadges = isPro 
      ? [...new Set([...(user.badges || []), 'Premium', ...(premium_type === 'lifetime' ? ['Lifetime'] : [])])]
      : (user.badges || []).filter((b: string) => b !== 'Premium' && b !== 'Lifetime' && b !== 'VIP');
    const newPlan = premium_type === 'lifetime' ? 'lifetime' : isPro ? 'premium' : 'free';
    
    setDisplayedUsers(prev => prev.map(u => u.uid === uid ? { ...u, isPro, badges: newBadges, plan: newPlan } : u));
    try {
      const result = await api.setPremium(uid, isPro, user.username, { 
        premium_type, 
        duration_value: durationValueLocal,
        duration_type: durationTypeLocal
      });
      showToast(`${user.username} is now ${premium_type === 'lifetime' ? 'Lifetime Premium' : isPro ? `Premium (${durationValueLocal} ${durationTypeLocal})` : 'Free'}`, 'success');
      if (result) {
        setDisplayedUsers(prev => prev.map(u => u.uid === uid ? result : u));
        setSelectedUser(prev => prev && prev.uid === uid ? result : prev);
      }
    } catch (e: any) {
      showToast(e.message, 'error');
      setDisplayedUsers(prev => prev.map(u => u.uid === uid ? { ...u, isPro: user.isPro, badges: user.badges, plan: user.plan } : u));
    }
  };

  const openPremiumModal = (user: UserProfile) => {
    setPremiumTargetUser(user);
    
    // Check if user already has premium
    const hasPremium = user.isPro || user.plan === 'premium' || user.plan === 'lifetime';
    setIsEditingPremium(hasPremium);
    
    if (user.plan === 'lifetime') {
      setPremiumType('lifetime');
    } else {
      setPremiumType('monthly');
    }
    setDurationType('months');
    setDurationValue(1);
    setShowPremiumModal(true);
  };

  const handleGivePremium = async () => {
    if (!premiumTargetUser) return;
    const isLifetime = premiumType === 'lifetime';
    await setPremium(premiumTargetUser.uid, true, premiumType, isLifetime ? 0 : durationValue, durationType);
    setShowPremiumModal(false);
    setPremiumTargetUser(null);
  };

  const toggleSuspension = async (uid: string, currentStatus: boolean) => {
    setDisplayedUsers(prev => prev.map(u => u.uid === uid ? { ...u, isSuspended: !currentStatus } : u));
    setSelectedUser(prev => prev && prev.uid === uid ? { ...prev, isSuspended: !currentStatus } : prev);
    try {
      const result = await api.suspendUser(uid, !currentStatus);
      showToast(`User ${currentStatus ? 'unsuspended' : 'suspended'}`, 'success');
      if (result) {
        setDisplayedUsers(prev => prev.map(u => u.uid === uid ? result : u));
        setSelectedUser(prev => prev && prev.uid === uid ? result : prev);
      }
    } catch (e: any) {
      showToast(e.message, 'error');
      setDisplayedUsers(prev => prev.map(u => u.uid === uid ? { ...u, isSuspended: currentStatus } : u));
      setSelectedUser(prev => prev && prev.uid === uid ? { ...prev, isSuspended: currentStatus } : prev);
    }
  };

  const banUsername = async (uid: string, currentUsername: string) => {
    const user = users.find(u => u.uid === uid) || displayedUsers.find(u => u.uid === uid);
    setDisplayedUsers(prev => prev.map(u => u.uid === uid ? { ...u, isSuspended: true, role: 'banned' as const } : u));
    setSelectedUser(prev => prev && prev.uid === uid ? { ...prev, isSuspended: true, role: 'banned' as const } : prev);
    try {
      const result = await api.banUser(uid, currentUsername);
      showToast('User banned', 'success');
      if (result) {
        setDisplayedUsers(prev => prev.map(u => u.uid === uid ? result : u));
        setSelectedUser(prev => prev && prev.uid === uid ? result : prev);
      }
    } catch (e: any) {
      showToast(e.message, 'error');
      setDisplayedUsers(prev => prev.map(u => u.uid === uid ? { ...u, isSuspended: false, role: user?.role } : u));
    }
  };

  const blacklistUser = async (_uid: string, username: string, reason?: string) => {
    try {
      await api.blacklistUser('username', username, reason || 'Blacklisted by admin');
      showToast(`Added ${username} to blacklist`, 'success');
    } catch (e: any) {
      showToast(e.message, 'error');
    }
  };

  const resolveReport = async (reportId: string, status: string) => {
    try {
      await api.resolveReport(reportId, status);
      showToast(`Report ${status}`, 'success');
      loadReports();
    } catch (e: any) {
      showToast(e.message, 'error');
    }
  };

  const saveCredit = async () => {
    if (!creditForm.name || !creditForm.role) {
      showToast('Name and role are required', 'error');
      return;
    }
    try {
      if (editingCredit) {
        await api.updateCredit({ id: editingCredit.id, ...creditForm });
        showToast('Credit updated', 'success');
      } else {
        await api.createCredit({ ...creditForm });
        showToast('Credit added', 'success');
      }
      loadCredits();
      setShowCreditForm(false);
      setEditingCredit(null);
    } catch (e: any) {
      showToast(e.message, 'error');
    }
  };

  const deleteCredit = async (id: string) => {
    try {
      await api.deleteCredit(id);
      showToast('Credit deleted', 'success');
      loadCredits();
    } catch (e: any) {
      showToast(e.message, 'error');
    }
  };

  const openUserProfile = async (user: UserProfile) => {
    setSelectedUser(user);
    setUserProfileTab('overview');
    setShowToken(false);
    setCopiedToken(false);
    setUserChangeHistory([]);
    await loadUserReports(user.uid);
    
    // Fetch user's token
    try {
      const tokenResult = await api.getToken(user.uid);
      setSelectedUserToken(tokenResult.token || null);
    } catch (e) {
      console.error('Failed to fetch token:', e);
    }

    // Fetch user's change history
    try {
      const history = await api.getChangeHistory(user.uid, 20);
      setUserChangeHistory(history || []);
    } catch (e) {
      console.error('Failed to fetch change history:', e);
    }
  };

  const handleCopyToken = async () => {
    if (selectedUserToken) {
      await navigator.clipboard.writeText(selectedUserToken);
      setCopiedToken(true);
      showToast('Token copied to clipboard!', 'success');
      setTimeout(() => setCopiedToken(false), 2000);
    }
  };

  const handleResetToken = async () => {
    if (!selectedUser) return;
    try {
      const result = await api.resetToken(selectedUser.uid);
      setSelectedUserToken(result.token);
      showToast('Token reset successfully!', 'success');
    } catch (e: any) {
      showToast(e.message || 'Failed to reset token', 'error');
    }
  };

  const toggleShadowBan = async (uid: string, username: string, currentStatus: boolean) => {
    setDisplayedUsers(prev => prev.map(u => u.uid === uid ? { ...u, isShadowBanned: !currentStatus } : u));
    setSelectedUser(prev => prev && prev.uid === uid ? { ...prev, isShadowBanned: !currentStatus } : prev);
    try {
      const result = await api.shadowbanUser(uid, username, !currentStatus);
      showToast(`User ${currentStatus ? 'unshadowbanned' : 'shadow banned'}`, 'success');
      if (result) {
        setDisplayedUsers(prev => prev.map(u => u.uid === uid ? result : u));
        setSelectedUser(prev => prev && prev.uid === uid ? result : prev);
      }
    } catch (e: any) {
      showToast(e.message, 'error');
      setDisplayedUsers(prev => prev.map(u => u.uid === uid ? { ...u, isShadowBanned: currentStatus } : u));
    }
  };

  const stats = {
    totalUsers: users.length,
    suspended: users.filter(u => u.isSuspended).length,
    shadowBanned: users.filter(u => u.isShadowBanned).length,
    banned: users.filter(u => u.role === 'banned').length,
    premium: users.filter(u => u.isPro).length,
    pendingReports: reports.filter(r => r.status === 'pending').length,
  };

  const tabs: { id: TabType; label: string; icon: any }[] = [
    { id: 'users', label: 'Users', icon: Users },
    { id: 'reports', label: 'Reports', icon: Flag },
    { id: 'credits', label: 'Credits', icon: CreditCard },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-7xl h-[90vh] glass border-white/10 rounded-3xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/5">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-neon-orange/20 flex items-center justify-center text-neon-orange">
              <Shield size={28} />
            </div>
            <div>
              <h2 className="text-xl font-black tracking-tighter">Admin Control Panel</h2>
              <div className="flex items-center gap-3 text-xs text-white/40 font-bold">
                <span>{stats.totalUsers} Users</span>
                <span>{stats.pendingReports} Pending</span>
                <span>{stats.premium} Premium</span>
                <span>{stats.shadowBanned} Shadow Banned</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={loadAllData} className="p-2 text-white/40 hover:text-neon-orange transition-colors"><RefreshCw size={18} className={cn(loading && 'animate-spin')} /></button>
            <button onClick={onClose} className="p-2 text-white/40 hover:text-white transition-colors"><X size={24} /></button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-white/5">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={cn("flex-1 py-4 flex items-center justify-center gap-2 text-xs font-black uppercase tracking-widest transition-all", activeTab === tab.id ? "text-neon-orange bg-neon-orange/5 border-b-2 border-neon-orange" : "text-white/40 hover:text-white hover:bg-white/5")}>
              <tab.icon size={14} />{tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
          {/* USERS TAB */}
          {activeTab === 'users' && (
            <div className="space-y-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" size={18} />
                <input 
                  type="text" 
                  placeholder="Search by UUID, username, email, or display name..." 
                  value={searchQuery} 
                  onChange={(e) => setSearchQuery(e.target.value)} 
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-sm focus:border-neon-orange/50 outline-none" 
                />
              </div>

              {/* Users List */}
              <div className="space-y-2">
                {displayedUsers.map(user => (
                  <GlassCard 
                    key={user.uid} 
                    className="p-4 flex items-center justify-between gap-4 cursor-pointer hover:border-neon-orange/30 transition-all"
                    onClick={() => openUserProfile(user)}
                  >
                    <div className="flex items-center gap-4">
                      <img src={user.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.username}`} className="w-12 h-12 rounded-full bg-white/5" />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold">{user.displayName || user.username}</span>
                          <span className={cn("px-2 py-0.5 rounded text-[9px] font-black uppercase border", 
                            user.role === 'admin' ? "bg-purple-500/20 text-purple-400 border-purple-500/50" : 
                            user.role === 'moderator' ? "bg-blue-500/20 text-blue-400 border-blue-500/50" : 
                            user.role === 'banned' ? "bg-red-500/20 text-red-400 border-red-500/50" : 
                            "bg-white/5 text-white/40 border-white/10"
                          )}>{user.role}</span>
                          {user.isPro && <Crown size={12} className="text-neon-orange" />}
                          {user.isShadowBanned && <EyeOff size={12} className="text-gray-500" />}
                          {user.isSuspended && <Ban size={12} className="text-red-500" />}
                        </div>
                        <p className="text-xs text-white/40">@{user.username}</p>
                        <p className="text-[10px] text-white/20 font-mono">{user.uid}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Eye size={16} className="text-white/40" />
                    </div>
                  </GlassCard>
                ))}
                
                {hasMoreUsers && (
                  <button 
                    onClick={() => loadUsersPage(usersPage + 1)} 
                    disabled={loadingMore}
                    className="w-full py-3 rounded-xl bg-white/5 border border-white/10 text-white/40 hover:text-white hover:border-white/20 transition-all text-sm font-bold disabled:opacity-50"
                  >
                    {loadingMore ? 'Loading...' : 'Load More Users'}
                  </button>
                )}
              </div>
            </div>
          )}

          {/* REPORTS TAB */}
          {activeTab === 'reports' && (
            <div className="space-y-2">
              {reports.length === 0 && <div className="text-center py-12 text-white/30">No reports yet</div>}
              {reports.map(report => (
                <GlassCard key={report.id} className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Flag size={14} className={report.status === 'pending' ? 'text-yellow-400' : report.status === 'resolved' ? 'text-green-400' : 'text-red-400'} />
                      <span className="text-sm font-bold">Report #{report.id.slice(0, 8)}</span>
                      <span className={cn("px-2 py-0.5 rounded text-[9px] font-black uppercase", 
                        report.status === 'pending' ? "bg-yellow-500/20 text-yellow-400" : 
                        report.status === 'resolved' ? "bg-green-500/20 text-green-400" : 
                        "bg-red-500/20 text-red-400"
                      )}>{report.status}</span>
                    </div>
                    <span className="text-xs text-white/30">{new Date(report.createdat).toLocaleDateString()}</span>
                  </div>
                  <div className="text-sm text-white/60 mb-3">{report.reason}</div>
                  <div className="flex items-center gap-4 text-xs text-white/40">
                    <span>Reported: {report.reported_uid?.slice(0, 10)}...</span>
                    <span>Reporter: {report.reporter_uid ? report.reporter_uid.slice(0, 10) + '...' : 'Anonymous'}</span>
                  </div>
                  {report.status === 'pending' && (
                    <div className="flex gap-2 mt-3">
                      <button onClick={() => resolveReport(report.id, 'resolved')} className="px-3 py-1.5 rounded-lg bg-green-500/20 text-green-400 text-xs font-bold hover:bg-green-500/30">Resolve</button>
                      <button onClick={() => resolveReport(report.id, 'dismissed')} className="px-3 py-1.5 rounded-lg bg-white/5 text-white/40 text-xs font-bold hover:bg-white/10">Dismiss</button>
                    </div>
                  )}
                </GlassCard>
              ))}
            </div>
          )}

          {/* CREDITS TAB */}
          {activeTab === 'credits' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-black">Team Credits</h3>
                <NeonButton 
                  size="sm" 
                  onClick={() => {
                    setEditingCredit(null);
                    setCreditForm({ name: '', role: '', roleType: 'team', quote: '', avatar: '', link: '', highlighted: false, order: 0, active: true });
                    setShowCreditForm(true);
                  }}
                >
                  <Plus size={14} /> Add Credit
                </NeonButton>
              </div>

              <AnimatePresence>
                {showCreditForm && (
                  <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
                    <GlassCard className="p-6 space-y-4">
                      <h4 className="font-bold">{editingCredit ? 'Edit' : 'Add'} Credit</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <input 
                          type="text" 
                          placeholder="Name" 
                          value={creditForm.name} 
                          onChange={(e) => setCreditForm({ ...creditForm, name: e.target.value })} 
                          className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-neon-orange/50" 
                        />
                        <input 
                          type="text" 
                          placeholder="Role" 
                          value={creditForm.role} 
                          onChange={(e) => setCreditForm({ ...creditForm, role: e.target.value })} 
                          className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-neon-orange/50" 
                        />
                        <select 
                          value={creditForm.roleType} 
                          onChange={(e) => setCreditForm({ ...creditForm, roleType: e.target.value as 'team' | 'special_thanks' })} 
                          className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-neon-orange/50"
                        >
                          <option value="team">Team</option>
                          <option value="special_thanks">Special Thanks</option>
                        </select>
                        <input 
                          type="number" 
                          placeholder="Order" 
                          value={creditForm.order} 
                          onChange={(e) => setCreditForm({ ...creditForm, order: parseInt(e.target.value) })} 
                          className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-neon-orange/50" 
                        />
                        <input 
                          type="text" 
                          placeholder="Avatar URL" 
                          value={creditForm.avatar} 
                          onChange={(e) => setCreditForm({ ...creditForm, avatar: e.target.value })} 
                          className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-neon-orange/50 col-span-2" 
                        />
                        <input 
                          type="text" 
                          placeholder="Link URL" 
                          value={creditForm.link} 
                          onChange={(e) => setCreditForm({ ...creditForm, link: e.target.value })} 
                          className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-neon-orange/50 col-span-2" 
                        />
                        <input 
                          type="text" 
                          placeholder="Quote" 
                          value={creditForm.quote} 
                          onChange={(e) => setCreditForm({ ...creditForm, quote: e.target.value })} 
                          className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-neon-orange/50 col-span-2" 
                        />
                        <label className="flex items-center gap-2 text-sm text-white/60 col-span-2">
                          <input 
                            type="checkbox" 
                            checked={creditForm.highlighted} 
                            onChange={(e) => setCreditForm({ ...creditForm, highlighted: e.target.checked })} 
                            className="rounded border-white/20 bg-white/5" 
                          />
                          Highlighted
                        </label>
                      </div>
                      <div className="flex gap-2">
                        <NeonButton size="sm" onClick={saveCredit}>{editingCredit ? 'Update' : 'Add'}</NeonButton>
                        <button onClick={() => setShowCreditForm(false)} className="px-4 py-2 rounded-lg bg-white/5 text-sm font-bold hover:bg-white/10">Cancel</button>
                      </div>
                    </GlassCard>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="space-y-2">
                {credits.map(credit => (
                  <GlassCard key={credit.id} className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <img src={credit.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${credit.name}`} className="w-12 h-12 rounded-full bg-white/5" />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold">{credit.name}</span>
                          {credit.highlighted && <Crown size={12} className="text-neon-orange" />}
                        </div>
                        <p className="text-xs text-white/40">{credit.role}</p>
                        {credit.quote && <p className="text-xs text-white/30 italic mt-1">{credit.quote}</p>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => { setEditingCredit(credit); setCreditForm({ name: credit.name, role: credit.role, roleType: credit.roleType || 'team', quote: credit.quote || '', avatar: credit.avatar || '', link: credit.link || '', highlighted: credit.highlighted || false, order: credit.order || 0, active: credit.active ?? true }); setShowCreditForm(true); }} className="p-2 rounded-lg bg-white/5 border border-white/10 text-white/40 hover:text-neon-orange"><Edit3 size={16} /></button>
                      <button onClick={() => deleteCredit(credit.id)} className="p-2 rounded-lg bg-white/5 border border-white/10 text-white/40 hover:text-red-400"><Trash2 size={16} /></button>
                    </div>
                  </GlassCard>
                ))}
              </div>
            </div>
          )}

          {/* ANALYTICS TAB */}
          {activeTab === 'analytics' && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <GlassCard className="p-6 text-center"><Users size={24} className="text-neon-orange mx-auto mb-3" /><p className="text-3xl font-black">{stats.totalUsers}</p><p className="text-xs text-white/40">Total Users</p></GlassCard>
              <GlassCard className="p-6 text-center"><Crown size={24} className="text-neon-orange mx-auto mb-3" /><p className="text-3xl font-black">{stats.premium}</p><p className="text-xs text-white/40">Premium Users</p></GlassCard>
              <GlassCard className="p-6 text-center"><Ban size={24} className="text-red-400 mx-auto mb-3" /><p className="text-3xl font-black">{stats.suspended + stats.banned}</p><p className="text-xs text-white/40">Suspended/Banned</p></GlassCard>
              <GlassCard className="p-6 text-center"><Flag size={24} className="text-yellow-400 mx-auto mb-3" /><p className="text-3xl font-black">{stats.pendingReports}</p><p className="text-xs text-white/40">Pending Reports</p></GlassCard>
            </div>
          )}
        </div>
      </motion.div>

      {/* User Profile Modal */}
      <AnimatePresence>
        {selectedUser && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }} 
            className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
            onClick={() => setSelectedUser(null)}
          >
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }} 
              animate={{ opacity: 1, scale: 1 }} 
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-3xl max-h-[85vh] glass border-white/10 rounded-3xl flex flex-col overflow-hidden shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              {/* User Profile Header */}
              <div className="p-6 border-b border-white/5 bg-white/5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <img src={selectedUser.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${selectedUser.username}`} className="w-16 h-16 rounded-full bg-white/5" />
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-xl font-black">{selectedUser.displayName || selectedUser.username}</h3>
                        {selectedUser.isPro && <Crown size={16} className="text-neon-orange" />}
                      </div>
                      <p className="text-sm text-white/40">@{selectedUser.username}</p>
                      <p className="text-[10px] text-white/20 font-mono">{selectedUser.uid}</p>
                      
                      {/* Login Token - shows on hover */}
                      {selectedUserToken && (
                        <div 
                          className="mt-2 relative group/token"
                          onMouseEnter={() => setShowToken(true)}
                          onMouseLeave={() => setShowToken(false)}
                        >
                          <div className={cn(
                            "flex items-center gap-2 px-3 py-2 rounded-lg transition-all cursor-pointer",
                            showToken ? "bg-white/10 border-white/20" : "bg-transparent border-transparent",
                            "border"
                          )} onClick={handleCopyToken}>
                            <Key size={12} className="text-white/40" />
                            <span className="text-[10px] font-mono text-white/40 group-hover/token:text-white/60 transition-colors">
                              {showToken ? selectedUserToken : '••••••••••••'}
                            </span>
                            {copiedToken ? (
                              <CheckCircle2 size={12} className="text-green-400" />
                            ) : (
                              <Copy size={12} className="text-white/20 group-hover/token:text-white/40" />
                            )}
                          </div>
                          {showToken && (
                            <div className="absolute top-full left-0 mt-1 px-2 py-1 rounded bg-black/80 text-[9px] text-white/60 whitespace-nowrap">
                              Click to copy
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                  <button onClick={() => setSelectedUser(null)} className="p-2 text-white/40 hover:text-white"><X size={20} /></button>
                </div>

                {/* Profile Tabs */}
                <div className="flex gap-2 flex-wrap">
                  {(['overview', 'badges', 'reports', 'actions', 'history'] as const).map(tab => (
                    <button key={tab} onClick={() => setUserProfileTab(tab)} className={cn("px-4 py-2 rounded-lg text-xs font-black uppercase transition-all", userProfileTab === tab ? "bg-neon-orange/20 text-neon-orange" : "bg-white/5 text-white/40 hover:bg-white/10")}>{tab}</button>
                  ))}
                </div>
              </div>

              {/* Profile Content */}
              <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
                {/* Overview Tab */}
                {userProfileTab === 'overview' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <GlassCard className="p-4">
                        <p className="text-xs text-white/40 mb-1">Role</p>
                        <p className="font-bold capitalize">{selectedUser.role}</p>
                      </GlassCard>
                      <GlassCard className="p-4">
                        <p className="text-xs text-white/40 mb-1">Status</p>
                        <p className="font-bold">{selectedUser.isSuspended ? 'Suspended' : 'Active'}</p>
                      </GlassCard>
                      <GlassCard className="p-4">
                        <p className="text-xs text-white/40 mb-1">Plan</p>
                        <p className="font-bold capitalize">{selectedUser.plan || 'free'}</p>
                      </GlassCard>
                      <GlassCard className="p-4">
                        <p className="text-xs text-white/40 mb-1">Joined</p>
                        <p className="font-bold">
                          {selectedUser.createdat 
                            ? new Date(selectedUser.createdat).toLocaleDateString('en-US', { 
                                year: 'numeric', 
                                month: 'short', 
                                day: 'numeric' 
                              })
                            : 'N/A'}
                        </p>
                      </GlassCard>
                    </div>
                    {selectedUser.bio && (
                      <GlassCard className="p-4">
                        <p className="text-xs text-white/40 mb-2">Bio</p>
                        <p className="text-sm text-white/60">{selectedUser.bio}</p>
                      </GlassCard>
                    )}
                    {selectedUser.badges && selectedUser.badges.length > 0 && (
                      <GlassCard className="p-4">
                        <p className="text-xs text-white/40 mb-3">Badges</p>
                        <div className="flex flex-wrap gap-2">
                          {getSortedBadges(selectedUser.badges).map((badge) => {
                            const BadgeIcon = badge.icon;
                            return (
                              <div
                                key={badge.id}
                                className="group relative px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 cursor-default transition-all hover:scale-105"
                                style={{
                                  background: badge.gradient,
                                  color: badge.textColor,
                                  borderColor: badge.borderColor,
                                  borderWidth: '1px',
                                  borderStyle: 'solid',
                                  boxShadow: `0 0 8px ${badge.glowColor}`,
                                }}
                              >
                                <BadgeIcon className="w-3.5 h-3.5" />
                                <span>{badge.name}</span>
                                {/* Tooltip */}
                                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 rounded-lg bg-[#1a1a1a] border border-white/10 shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
                                  <p className="text-[10px] text-white/60">{badge.description}</p>
                                  <div className="absolute top-full left-1/2 -translate-x-1/2 w-2 h-2 bg-[#1a1a1a] border-r border-b border-white/10 transform rotate-45 -mt-1" />
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </GlassCard>
                    )}
                  </div>
                )}

                {/* Badges Tab */}
                {userProfileTab === 'badges' && (
                  <div className="space-y-4">
                    {/* Badge input for custom badges */}
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Custom badge ID (e.g., 'owner', 'admin')..."
                        value={badgeInput}
                        onChange={(e) => setBadgeInput(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                        className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-neon-orange/50 placeholder:text-white/20"
                      />
                      <NeonButton size="sm" onClick={() => { if (badgeInput && BADGES[badgeInput]) { giveBadge(selectedUser.uid, badgeInput); setBadgeInput(''); } else if (badgeInput) { showToast('Invalid badge ID', 'error'); } }}>Give Badge</NeonButton>
                    </div>

                    {/* Current user badges */}
                    {selectedUser.badges && selectedUser.badges.length > 0 && (
                      <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                        <p className="text-[10px] font-black text-white/30 uppercase tracking-widest mb-3">Current Badges</p>
                        <div className="flex flex-wrap gap-2">
                          {getSortedBadges(selectedUser.badges).map((badge) => {
                            const BadgeIcon = badge.icon;
                            return (
                              <button
                                key={badge.id}
                                onClick={() => giveBadge(selectedUser.uid, badge.id)}
                                className="group relative px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer transition-all hover:scale-105"
                                style={{
                                  background: badge.gradient,
                                  color: badge.textColor,
                                  borderColor: badge.borderColor,
                                  borderWidth: '1px',
                                  borderStyle: 'solid',
                                  boxShadow: `0 0 8px ${badge.glowColor}`,
                                }}
                                title={`Click to remove ${badge.name}`}
                              >
                                <BadgeIcon className="w-3.5 h-3.5" />
                                <span>{badge.name}</span>
                                {/* Tooltip */}
                                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 rounded-lg bg-[#1a1a1a] border border-white/10 shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50 min-w-[150px]">
                                  <div className="flex items-center gap-2 mb-1">
                                    <BadgeIcon className="w-4 h-4" style={{ color: badge.borderColor }} />
                                    <span className="text-xs font-bold text-white">{badge.name}</span>
                                  </div>
                                  <p className="text-[10px] text-white/60">{badge.description}</p>
                                  <div className="absolute top-full left-1/2 -translate-x-1/2 w-2 h-2 bg-[#1a1a1a] border-r border-b border-white/10 transform rotate-45 -mt-1" />
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Available badges grid */}
                    <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                      <p className="text-[10px] font-black text-white/30 uppercase tracking-widest mb-3">Available Badges (click to add or remove)</p>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        {AVAILABLE_BADGES.map(badgeId => {
                          const badge = BADGES[badgeId];
                          if (!badge) return null;
                          const BadgeIcon = badge.icon;
                          const hasBadge = selectedUser.badges?.includes(badgeId);
                          return (
                            <button
                              key={badgeId}
                              onClick={() => giveBadge(selectedUser.uid, badgeId)}
                              className="group relative px-3 py-3 rounded-lg text-xs font-bold flex items-center gap-2 border transition-all hover:scale-105"
                              style={{
                                background: hasBadge ? badge.gradient : 'rgba(255,255,255,0.05)',
                                color: hasBadge ? badge.textColor : 'rgba(255,255,255,0.4)',
                                borderColor: hasBadge ? badge.borderColor : 'rgba(255,255,255,0.1)',
                                boxShadow: hasBadge ? `0 0 8px ${badge.glowColor}` : 'none',
                              }}
                            >
                              <BadgeIcon className="w-4 h-4" />
                              <span>{badge.name}</span>
                              {/* Tooltip */}
                              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 rounded-lg bg-[#1a1a1a] border border-white/10 shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50 min-w-[180px]">
                                <div className="flex items-center gap-2 mb-1">
                                  <BadgeIcon className="w-4 h-4" style={{ color: badge.borderColor }} />
                                  <span className="text-xs font-bold text-white">{badge.name}</span>
                                </div>
                                <p className="text-[10px] text-white/60">{badge.description}</p>
                                <div className="mt-1 pt-1 border-t border-white/5">
                                  <span className="text-[9px] text-white/40 uppercase tracking-wider">{badge.category} badge</span>
                                </div>
                                <div className="absolute top-full left-1/2 -translate-x-1/2 w-2 h-2 bg-[#1a1a1a] border-r border-b border-white/10 transform rotate-45 -mt-1" />
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}

                {/* Reports Tab */}
                {userProfileTab === 'reports' && (
                  <div className="space-y-2">
                    {userReports.length === 0 && <div className="text-center py-12 text-white/30">This user hasn't made any reports</div>}
                    {userReports.map(report => (
                      <GlassCard key={report.id} className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-bold">Report #{report.id.slice(0, 8)}</span>
                          <span className={cn("px-2 py-0.5 rounded text-[9px] font-black uppercase", report.status === 'pending' ? "bg-yellow-500/20 text-yellow-400" : report.status === 'resolved' ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400")}>{report.status}</span>
                        </div>
                        <p className="text-sm text-white/60 mb-2">{report.reason}</p>
                        <p className="text-xs text-white/30">Target: {report.reported_uid?.slice(0, 10)}...</p>
                        <p className="text-xs text-white/30">{new Date(report.createdat).toLocaleDateString()}</p>
                      </GlassCard>
                    ))}
                  </div>
                )}

                {/* Actions Tab */}
                {userProfileTab === 'actions' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <NeonButton size="sm" onClick={() => openPremiumModal(selectedUser)}>
                        <Crown size={14} className="mr-2" /> 
                        {isEditingPremium ? 'Edit Membership' : 'Give'}
                      </NeonButton>
                      <button 
                        onClick={() => toggleSuspension(selectedUser.uid, !!selectedUser.isSuspended)} 
                        className={cn("px-4 py-2 rounded-xl text-sm font-bold border flex items-center justify-center gap-2", 
                          selectedUser.isSuspended 
                            ? "bg-green-500/20 border-green-500/50 text-green-400" 
                            : "bg-yellow-500/20 border-yellow-500/50 text-yellow-400"
                        )}
                      >
                        {selectedUser.isSuspended ? <Unlock size={14} /> : <Lock size={14} />}
                        {selectedUser.isSuspended ? 'Unsuspend' : 'Suspend'}
                      </button>
                      <button 
                        onClick={() => toggleShadowBan(selectedUser.uid, selectedUser.username, !!selectedUser.isShadowBanned)} 
                        className={cn("px-4 py-2 rounded-xl text-sm font-bold border flex items-center justify-center gap-2", 
                          selectedUser.isShadowBanned 
                            ? "bg-green-500/20 border-green-500/50 text-green-400" 
                            : "bg-gray-500/20 border-gray-500/50 text-gray-400"
                        )}
                      >
                        {selectedUser.isShadowBanned ? <Eye size={14} /> : <EyeOff size={14} />}
                        {selectedUser.isShadowBanned ? 'Unshadowban' : 'Shadow Ban'}
                      </button>
                      <button 
                        onClick={() => banUsername(selectedUser.uid, selectedUser.username)} 
                        className="px-4 py-2 rounded-xl bg-red-500/20 border border-red-500/50 text-red-400 text-sm font-bold hover:bg-red-500/30 flex items-center justify-center gap-2"
                      >
                        <Ban size={14} /> Ban User
                      </button>
                      <button 
                        onClick={() => blacklistUser(selectedUser.uid, selectedUser.username)} 
                        className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-white/40 text-sm font-bold hover:text-red-400 flex items-center justify-center gap-2"
                      >
                        <UserMinus size={14} /> Blacklist
                      </button>
                    </div>
                    
                    {/* Token Management */}
                    <div className="mt-6 p-4 rounded-xl bg-white/5 border border-white/10">
                      <h4 className="text-xs font-bold text-white/60 mb-3">Login Token</h4>
                      <div className="flex gap-3">
                        <button 
                          onClick={handleCopyToken} 
                          className="flex-1 px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-sm font-bold hover:bg-white/10 transition-all flex items-center justify-center gap-2"
                        >
                          <Copy size={14} /> Copy Token
                        </button>
                        <button 
                          onClick={handleResetToken} 
                          className="px-4 py-2 rounded-xl bg-red-500/20 border border-red-500/50 text-red-400 text-sm font-bold hover:bg-red-500/30 flex items-center justify-center gap-2"
                        >
                          <Key size={14} /> Reset Token
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* History Tab */}
                {userProfileTab === 'history' && (
                  <div className="space-y-3">
                    <h4 className="text-sm font-bold text-white/60 mb-4">Change History</h4>
                    {userChangeHistory.length === 0 ? (
                      <div className="text-center py-8 text-white/30">No changes recorded yet</div>
                    ) : (
                      userChangeHistory.map((change: any, index: number) => (
                        <GlassCard key={change.id || index} className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <FileText size={14} className="text-white/40" />
                              <span className="text-xs font-bold text-white/60">{change.action}</span>
                            </div>
                            <span className="text-[10px] text-white/30">
                              {new Date(change.createdat).toLocaleDateString()} {new Date(change.createdat).toLocaleTimeString()}
                            </span>
                          </div>
                          <div className="text-xs text-white/40 mb-2">
                            By: {change.admin_email}
                          </div>
                          {change.details && (
                            <div className="text-xs text-white/50 bg-white/5 rounded-lg p-3 font-mono">
                              {change.details}
                            </div>
                          )}
                        </GlassCard>
                      ))
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* Premium Give Modal */}
        <AnimatePresence>
          {showPremiumModal && premiumTargetUser && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
              onClick={() => setShowPremiumModal(false)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                onClick={(e) => e.stopPropagation()}
                className="w-full max-w-md glass border-white/10 rounded-3xl overflow-hidden shadow-2xl"
              >
                {/* Header */}
                <div className={cn(
                  "p-6 border-b",
                  premiumType === 'lifetime' 
                    ? "border-purple-500/30 bg-gradient-to-r from-purple-500/10 to-transparent" 
                    : "border-neon-orange/30 bg-gradient-to-r from-neon-orange/10 to-transparent"
                )}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "w-12 h-12 rounded-xl flex items-center justify-center",
                        premiumType === 'lifetime' ? "bg-purple-500/20 text-purple-400" : "bg-neon-orange/20 text-neon-orange"
                      )}>
                        <Crown size={24} />
                      </div>
                      <div>
                        <h3 className="text-xl font-black tracking-tighter">Give Premium</h3>
                        <p className="text-xs text-white/40">to @{premiumTargetUser.username}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setShowPremiumModal(false)}
                      className="p-2 text-white/40 hover:text-white transition-colors"
                    >
                      <X size={20} />
                    </button>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 space-y-6">
                  {/* Premium Type Selector */}
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em]">Premium Type</label>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        onClick={() => setPremiumType('monthly')}
                        className={cn(
                          "p-4 rounded-xl border-2 transition-all",
                          premiumType === 'monthly'
                            ? "border-neon-orange bg-neon-orange/10"
                            : "border-white/10 bg-white/5 hover:border-white/20"
                        )}
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <div className={cn(
                            "w-8 h-8 rounded-lg flex items-center justify-center",
                            premiumType === 'monthly' ? "bg-neon-orange text-black" : "bg-white/10 text-white/40"
                          )}>
                            <Crown size={16} />
                          </div>
                          <span className={cn(
                            "font-bold text-sm",
                            premiumType === 'monthly' ? "text-neon-orange" : "text-white/60"
                          )}>Monthly</span>
                        </div>
                        <p className="text-[10px] text-white/40">Time-limited access</p>
                      </button>

                      <button
                        onClick={() => setPremiumType('lifetime')}
                        className={cn(
                          "p-4 rounded-xl border-2 transition-all",
                          premiumType === 'lifetime'
                            ? "border-purple-500 bg-purple-500/10"
                            : "border-white/10 bg-white/5 hover:border-white/20"
                        )}
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <div className={cn(
                            "w-8 h-8 rounded-lg flex items-center justify-center",
                            premiumType === 'lifetime' ? "bg-purple-500 text-white" : "bg-white/10 text-white/40"
                          )}>
                            <Crown size={16} />
                          </div>
                          <span className={cn(
                            "font-bold text-sm",
                            premiumType === 'lifetime' ? "text-purple-400" : "text-white/60"
                          )}>Lifetime</span>
                        </div>
                        <p className="text-[10px] text-white/40">Permanent access</p>
                      </button>
                    </div>
                  </div>

                  {/* Duration Input (only for monthly) */}
                  {premiumType === 'monthly' && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-3"
                    >
                      <label className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em]">Duration</label>
                      <div className="flex gap-2">
                        <div className="flex-1">
                          <input
                            type="number"
                            min="1"
                            max={durationType === 'days' ? 32 : durationType === 'weeks' ? 26 : 36}
                            value={durationValue}
                            onChange={(e) => setDurationValue(Math.min(durationType === 'days' ? 32 : durationType === 'weeks' ? 26 : 36, Math.max(1, parseInt(e.target.value) || 1)))}
                            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm font-bold text-white focus:outline-none focus:border-neon-orange/50"
                            placeholder="Enter duration"
                          />
                        </div>
                        <select
                          value={durationType}
                          onChange={(e) => setDurationType(e.target.value as 'days' | 'weeks' | 'months')}
                          className="px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sm font-bold text-white focus:outline-none focus:border-neon-orange/50"
                        >
                          <option value="days">Days (max 32)</option>
                          <option value="weeks">Weeks (max 26)</option>
                          <option value="months">Months (max 36)</option>
                        </select>
                      </div>
                    </motion.div>
                  )}

                  {/* Summary */}
                  <div className={cn(
                    "p-4 rounded-xl border",
                    premiumType === 'lifetime' 
                      ? "bg-purple-500/10 border-purple-500/30" 
                      : "bg-neon-orange/10 border-neon-orange/30"
                  )}>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-white/60">Summary:</span>
                      <span className={cn(
                        "font-bold",
                        premiumType === 'lifetime' ? "text-purple-400" : "text-neon-orange"
                      )}>
                        {premiumType === 'lifetime' 
                          ? 'Lifetime Premium' 
                          : `${durationValue} ${durationType}${durationValue > 1 ? 's' : ''} Premium`}
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowPremiumModal(false)}
                      className="flex-1 px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sm font-bold hover:bg-white/10 transition-all"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleGivePremium}
                      className={cn(
                        "flex-1 px-4 py-3 rounded-xl text-sm font-black uppercase tracking-widest transition-all",
                        premiumType === 'lifetime'
                          ? "bg-purple-500 text-white hover:bg-purple-600 shadow-[0_0_20px_rgba(168,85,247,0.3)]"
                          : "bg-neon-orange text-black hover:bg-orange-400 shadow-[0_0_20px_rgba(255,136,0,0.3)]"
                      )}
                    >
                      Give Premium
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </AnimatePresence>
    </div>
  );
}
