import { MessageSquare } from 'lucide-react';
import { useState } from 'react';
import { FeedbackModal } from '../dashboard/FeedbackModal';

export function FeedbackButton() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className="text-sm font-medium text-white/60 hover:text-white transition-colors flex items-center gap-2"
      >
        <MessageSquare size={16} />
        Feedback
      </button>
      <FeedbackModal isOpen={isOpen} onClose={() => setIsOpen(false)} />
    </>
  );
}
