import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Sparkles, CheckCircle2, Zap, Shield, Crown, Star } from 'lucide-react';
import { NeonButton } from './NeonButton';
import { GlassCard } from './GlassCard';
import { useSupabase } from '../SupabaseProvider';
import { profileService } from '@/src/services/profileService';
import { cn } from '@/src/lib/utils';

interface ProUpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ProUpgradeModal({ isOpen, onClose }: ProUpgradeModalProps) {
  const { profile, refreshProfile } = useSupabase();
  const [loading, setLoading] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleUpgrade = async (planName: string) => {
    if (!profile) return;
    setLoading(planName);
    try {
      const plan = planName.toLowerCase() as 'premium' | 'lifetime';
      
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: profile.uid,
          plan: plan,
          email: profile.email
        }),
      });

      const data = await response.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        throw new Error(data.error || 'Failed to create checkout session');
      }
    } catch (err: any) {
      console.error('Upgrade failed:', err);
      alert(err.message || 'Failed to start checkout process. Please try again.');
    } finally {
      setLoading(null);
    }
  };

  const plans = [
    {
      name: 'Free',
      price: '$0',
      period: '/forever',
      description: 'Perfect for getting started.',
      features: [
        'Basic Profile Customization',
        'Unlimited Links',
        'Standard Analytics',
        'Community Access'
      ],
      buttonText: 'Current Plan',
      variant: 'outline' as const,
      color: 'white'
    },
    {
      name: 'Premium',
      price: '$1.99',
      period: '/month',
      description: 'Unlock your full potential.',
      features: [
        'Everything in Free',
        'Animated Backgrounds',
        'Custom Themes & Fonts',
        'Advanced Analytics',
        'Premium Badge',
        'Priority Support'
      ],
      buttonText: 'Upgrade to Premium',
      variant: 'primary' as const,
      color: 'neon-orange',
      popular: true
    },
    {
      name: 'Lifetime',
      price: '$9.99',
      period: '/one-time',
      description: 'One-time payment, forever access.',
      features: [
        'Everything in Premium',
        'Unlimited Analytics History',
        '24/7 Priority Support',
        'Lifetime Updates',
        'Exclusive Lifetime Badge',
        'Early Access to New Features'
      ],
      buttonText: 'Upgrade to Lifetime',
      variant: 'primary' as const,
      color: 'purple-500',
      bestValue: true
    }
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/80 backdrop-blur-xl"
        />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative w-full max-w-6xl z-10"
        >
          <GlassCard className="p-8 md:p-12 border-white/10 overflow-hidden relative">
            {/* Background Accents */}
            <div className="absolute -top-24 -right-24 w-96 h-96 bg-neon-orange/10 blur-[120px] rounded-full pointer-events-none" />
            <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-purple-500/10 blur-[120px] rounded-full pointer-events-none" />

            <button 
              onClick={onClose}
              className="absolute top-6 right-6 p-2 rounded-full bg-white/5 hover:bg-white/10 text-white/40 hover:text-white transition-all z-20"
            >
              <X size={24} />
            </button>

            <div className="text-center mb-12 relative z-10">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-neon-orange text-[10px] font-black uppercase tracking-[0.2em] mb-4">
                <Crown size={12} className="fill-neon-orange" />
                <span>Premium Access</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-black tracking-tighter mb-4">
                Elevate Your <span className="text-neon-orange">Presence</span>
              </h2>
              <p className="text-white/40 font-medium max-w-xl mx-auto">
                Join thousands of creators who have already upgraded to unlock exclusive themes, advanced analytics, and more.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
              {plans.map((plan) => (
                <GlassCard 
                  key={plan.name}
                  className={cn(
                    "p-6 flex flex-col relative transition-all duration-500 group",
                    plan.popular ? "border-neon-orange/30 bg-neon-orange/5" : "border-white/5 bg-white/5",
                    plan.bestValue ? "border-purple-500/30 bg-purple-500/5" : ""
                  )}
                >
                  {plan.popular && (
                    <div className="absolute top-0 right-0 bg-neon-orange text-black text-[8px] font-black px-3 py-1 rounded-bl-lg uppercase tracking-wider">
                      Most Popular
                    </div>
                  )}
                  {plan.bestValue && (
                    <div className="absolute top-0 right-0 bg-purple-500 text-white text-[8px] font-black px-3 py-1 rounded-bl-lg uppercase tracking-wider">
                      Best Value
                    </div>
                  )}

                  <div className="mb-6">
                    <h3 className={cn(
                      "text-xl font-black mb-1 tracking-tight flex items-center gap-2",
                      plan.color === 'neon-orange' ? "text-neon-orange" : plan.color === 'purple-500' ? "text-purple-500" : "text-white"
                    )}>
                      {plan.name === 'Free' ? <Star size={20} /> : <Zap size={20} />}
                      {plan.name}
                    </h3>
                    <p className="text-white/40 text-xs font-medium">{plan.description}</p>
                  </div>

                  <div className="flex items-end gap-1 mb-8">
                    <span className="text-4xl font-black">{plan.price}</span>
                    <span className="text-white/20 text-[10px] font-black uppercase tracking-widest mb-1.5">{plan.period}</span>
                  </div>

                  <ul className="space-y-3 mb-8 flex-1">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-3 text-[11px] font-medium text-white/60">
                        <CheckCircle2 size={14} className={cn(
                          "shrink-0 mt-0.5",
                          plan.color === 'neon-orange' ? "text-neon-orange" : plan.color === 'purple-500' ? "text-purple-500" : "text-white/20"
                        )} />
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <NeonButton 
                    variant={plan.variant}
                    className={cn(
                      "w-full text-[10px] font-black tracking-widest",
                      plan.color === 'purple-500' && "bg-purple-500 hover:bg-purple-600 border-purple-500"
                    )}
                    onClick={() => handleUpgrade(plan.name)}
                    disabled={plan.name === 'Free' || (loading !== null && loading !== plan.name)}
                  >
                    {loading === plan.name ? 'UPGRADING...' : plan.buttonText}
                  </NeonButton>
                </GlassCard>
              ))}
            </div>

            <p className="text-center mt-8 text-[10px] font-black text-white/20 uppercase tracking-[0.2em]">
              Secure payment powered by Stripe. Cancel anytime.
            </p>
          </GlassCard>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
