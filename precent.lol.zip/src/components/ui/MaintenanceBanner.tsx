import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Wrench } from 'lucide-react';

interface MaintenanceBannerProps {
  message: string;
}

export function MaintenanceBanner({ message }: MaintenanceBannerProps) {
  return (
    <AnimatePresence>
      <motion.div
        initial={{ height: 0, opacity: 0 }}
        animate={{ height: 'auto', opacity: 1 }}
        exit={{ height: 0, opacity: 0 }}
        className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/95 backdrop-blur-md"
      >
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          className="text-center p-12 max-w-md"
        >
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
            className="w-24 h-24 rounded-full bg-yellow-500/20 flex items-center justify-center mx-auto mb-8"
          >
            <Wrench size={48} className="text-yellow-500" />
          </motion.div>
          
          <h1 className="text-4xl font-black text-white mb-4">We'll Be Right Back</h1>
          <p className="text-white/60 text-lg mb-8">{message || "We're performing some maintenance. Please check back soon!"}</p>
          
          <div className="flex items-center justify-center gap-2 text-yellow-500/60">
            <AlertTriangle size={16} />
            <span className="text-sm">Estimated return time: Soon™</span>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
