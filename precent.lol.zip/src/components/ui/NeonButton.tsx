import { motion, HTMLMotionProps } from 'motion/react';
import { cn } from '@/src/lib/utils';

interface NeonButtonProps extends HTMLMotionProps<'button'> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  glow?: boolean;
}

export function NeonButton({
  children,
  className,
  variant = 'primary',
  size = 'md',
  glow = true,
  ...props
}: NeonButtonProps) {
  const variants = {
    primary: 'bg-neon-orange text-black hover:bg-neon-orange/90 shadow-[0_0_20px_rgba(255,136,0,0.3)]',
    secondary: 'bg-cyan text-black hover:bg-cyan/90 shadow-[0_0_20px_rgba(34,211,238,0.3)]',
    outline: 'border border-white/10 text-white hover:border-neon-orange/50 hover:bg-neon-orange/10',
    ghost: 'text-white/70 hover:text-white hover:bg-white/5',
  };

  const sizes = {
    sm: 'px-4 py-1.5 text-sm',
    md: 'px-6 py-2.5 text-base',
    lg: 'px-8 py-3.5 text-lg font-bold',
  };

  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={cn(
        'rounded-full transition-all duration-300 relative overflow-hidden group',
        variants[variant],
        sizes[size],
        glow && variant === 'primary' && 'neon-glow',
        className
      )}
      {...props}
    >
      <span className="relative z-10 flex items-center justify-center gap-2">
        {children}
      </span>
      
      {/* Shine effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 pointer-events-none" />
    </motion.button>
  );
}
