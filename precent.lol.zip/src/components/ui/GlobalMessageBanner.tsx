import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Megaphone } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface GlobalMessageBannerProps {
  message: string;
  onClose: () => void;
}

export function GlobalMessageBanner({ message, onClose }: GlobalMessageBannerProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (message) {
      // Check if user has dismissed this message before
      const dismissed = localStorage.getItem('dismissed_global_message');
      if (dismissed !== message) {
        setIsVisible(true);
      }
    }
  }, [message]);

  const handleClose = () => {
    setIsVisible(false);
    localStorage.setItem('dismissed_global_message', message);
    setTimeout(() => onClose(), 300);
  };

  return (
    <AnimatePresence>
      {isVisible && message && (
        <motion.div
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -100, opacity: 0 }}
          className="sticky top-0 z-50"
        >
          <div className={cn(
            "flex items-center gap-4 px-6 py-4 border-b",
            "bg-gradient-to-r from-neon-orange/10 via-neon-orange/5 to-transparent",
            "border-neon-orange/20"
          )}>
            <Megaphone size={20} className="text-neon-orange shrink-0" />
            <p className="flex-1 text-sm font-bold text-white">{message}</p>
            <button
              onClick={handleClose}
              className="p-1 text-white/40 hover:text-white transition-colors shrink-0"
            >
              <X size={16} />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
