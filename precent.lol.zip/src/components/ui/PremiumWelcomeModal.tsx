import { motion, AnimatePresence } from 'motion/react';
import { X, Crown, Sparkles, Zap, Palette, Link, Music, Shield, Check } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface PremiumWelcomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  isLifetime?: boolean;
}

const perks = [
  { icon: Palette, text: 'Custom themes & advanced appearance settings' },
  { icon: Link, text: 'Unlimited bio links with analytics' },
  { icon: Music, text: 'Custom music player on your profile' },
  { icon: Zap, text: 'Priority support & early access to features' },
  { icon: Shield, text: 'Exclusive Premium badge on your profile' },
  { icon: Sparkles, text: 'Advanced customization options' },
];

export function PremiumWelcomeModal({ isOpen, onClose, isLifetime = false }: PremiumWelcomeModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 30 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-lg glass border-white/10 rounded-3xl overflow-hidden shadow-2xl"
          >
            {/* Header with gradient */}
            <div className={cn(
              "relative p-8 text-center overflow-hidden",
              isLifetime 
                ? "bg-gradient-to-br from-purple-500/20 via-purple-500/10 to-transparent"
                : "bg-gradient-to-br from-neon-orange/20 via-neon-orange/10 to-transparent"
            )}>
              {/* Animated background */}
              <div className="absolute inset-0">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                  className={cn(
                    "absolute -top-20 -right-20 w-40 h-40 rounded-full blur-3xl opacity-20",
                    isLifetime ? "bg-purple-500" : "bg-neon-orange"
                  )}
                />
                <motion.div
                  animate={{ rotate: -360 }}
                  transition={{ duration: 15, repeat: Infinity, ease: 'linear' }}
                  className={cn(
                    "absolute -bottom-20 -left-20 w-40 h-40 rounded-full blur-3xl opacity-20",
                    isLifetime ? "bg-purple-400" : "bg-orange-400"
                  )}
                />
              </div>

              <div className="relative z-10">
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: 'spring', delay: 0.2, stiffness: 300 }}
                  className={cn(
                    "w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center",
                    isLifetime 
                      ? "bg-gradient-to-br from-purple-500 to-purple-600 shadow-[0_0_40px_rgba(168,85,247,0.5)]"
                      : "bg-gradient-to-br from-neon-orange to-orange-500 shadow-[0_0_40px_rgba(255,136,0,0.5)]"
                  )}
                >
                  <Crown size={40} className="text-white" />
                </motion.div>

                <motion.h2
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="text-3xl font-black text-white mb-2"
                >
                  {isLifetime ? 'Lifetime Premium' : 'Thank you for joining Premium'}
                </motion.h2>

                <motion.p
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="text-white/60"
                >
                  {isLifetime 
                    ? 'You now have permanent access to all premium features'
                    : 'Unlock the full power of precent.lol'}
                </motion.p>
              </div>
            </div>

            {/* Perks List */}
            <div className="p-8">
              <h3 className="text-sm font-black text-white/40 uppercase tracking-[0.2em] mb-6">
                Your Premium Perks
              </h3>

              <div className="space-y-4">
                {perks.map((perk, index) => (
                  <motion.div
                    key={perk.text}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5 + index * 0.1 }}
                    className="flex items-start gap-4 p-4 rounded-xl bg-white/5 border border-white/5 hover:border-white/10 transition-all"
                  >
                    <div className={cn(
                      "w-10 h-10 rounded-lg flex items-center justify-center shrink-0",
                      isLifetime ? "bg-purple-500/20 text-purple-400" : "bg-neon-orange/20 text-neon-orange"
                    )}>
                      <perk.icon size={20} />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-bold text-white">{perk.text}</p>
                    </div>
                    <Check size={18} className={cn(
                      "shrink-0",
                      isLifetime ? "text-purple-400" : "text-neon-orange"
                    )} />
                  </motion.div>
                ))}
              </div>

              {/* Close Button */}
              <motion.button
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.2 }}
                onClick={onClose}
                className={cn(
                  "w-full mt-8 px-6 py-4 rounded-2xl text-sm font-black uppercase tracking-widest transition-all",
                  isLifetime
                    ? "bg-purple-500 text-white hover:bg-purple-600 shadow-[0_0_30px_rgba(168,85,247,0.3)]"
                    : "bg-neon-orange text-black hover:bg-orange-400 shadow-[0_0_30px_rgba(255,136,0,0.3)]"
                )}
              >
                Get Started
              </motion.button>
            </div>

            {/* Close X button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 text-white/40 hover:text-white transition-colors z-20"
            >
              <X size={20} />
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
