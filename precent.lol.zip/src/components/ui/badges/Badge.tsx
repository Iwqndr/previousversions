import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BadgeDefinition } from './badgeDefinitions';
import { cn } from '../../../lib/utils';

interface BadgeProps {
  badge: BadgeDefinition;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  variant?: 'default' | 'compact' | 'icon-only';
  showTooltip?: boolean;
  className?: string;
  onClick?: () => void;
}

export function Badge({
  badge,
  size = 'md',
  variant = 'default',
  showTooltip = true,
  className,
  onClick,
}: BadgeProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });
  const badgeRef = useRef<HTMLDivElement>(null);

  const sizeClasses = {
    xs: {
      container: 'h-5 px-1.5 gap-1',
      icon: 'w-2.5 h-2.5',
      text: 'text-[9px]',
    },
    sm: {
      container: 'h-6 px-2 gap-1.5',
      icon: 'w-3 h-3',
      text: 'text-[10px]',
    },
    md: {
      container: 'h-7 px-2.5 gap-2',
      icon: 'w-3.5 h-3.5',
      text: 'text-xs',
    },
    lg: {
      container: 'h-8 px-3 gap-2',
      icon: 'w-4 h-4',
      text: 'text-sm',
    },
  };

  const sizes = sizeClasses[size];
  const IconComponent = badge.icon;

  const handleMouseMove = (e: React.MouseEvent) => {
    if (badgeRef.current) {
      const rect = badgeRef.current.getBoundingClientRect();
      setTooltipPosition({
        x: rect.left + rect.width / 2,
        y: rect.top - 8,
      });
    }
  };

  return (
    <div
      ref={badgeRef}
      className="relative inline-block"
      onMouseEnter={(e) => {
        setIsHovered(true);
        handleMouseMove(e);
      }}
      onMouseLeave={() => setIsHovered(false)}
      onMouseMove={handleMouseMove}
    >
      <motion.div
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.95 }}
        onClick={onClick}
        className={cn(
          'inline-flex items-center justify-center rounded-full font-bold cursor-default relative overflow-hidden',
          'transition-all duration-200 border backdrop-blur-sm',
          sizes.container,
          variant === 'compact' && 'rounded-md',
          variant === 'icon-only' && 'rounded-full aspect-square p-0',
          className
        )}
        style={{
          background: badge.gradient,
          borderColor: badge.borderColor,
          boxShadow: `0 0 12px ${badge.glowColor}, inset 0 1px 0 rgba(255, 255, 255, 0.2)`,
        }}
      >
        {/* Shimmer effect overlay */}
        <div
          className="absolute inset-0 opacity-30"
          style={{
            background: 'linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.4) 50%, transparent 60%)',
          }}
        />

        {variant === 'icon-only' ? (
          <IconComponent className={cn('relative z-10', sizes.icon)} />
        ) : (
          <>
            <IconComponent className={cn('relative z-10', sizes.icon)} />
            {variant !== 'compact' && (
              <span
                className={cn('relative z-10 font-semibold whitespace-nowrap', sizes.text)}
                style={{ color: badge.textColor }}
              >
                {badge.name}
              </span>
            )}
          </>
        )}
      </motion.div>

      {/* Tooltip */}
      <AnimatePresence>
        {showTooltip && isHovered && variant !== 'compact' && (
          <motion.div
            initial={{ opacity: 0, y: 4, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 4, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="fixed z-[9999] pointer-events-none"
            style={{
              left: tooltipPosition.x,
              top: tooltipPosition.y,
              transform: 'translate(-50%, -100%)',
            }}
          >
            <div className="glass rounded-lg px-3 py-2 shadow-2xl border border-white/10 max-w-[200px]">
              <div className="flex items-center gap-2 mb-1">
                <IconComponent className="w-4 h-4" style={{ color: badge.borderColor }} />
                <span className="text-xs font-bold text-white">{badge.name}</span>
              </div>
              <p className="text-[10px] text-white/60 leading-relaxed">{badge.description}</p>
              {badge.category === 'role' && (
                <div className="mt-1.5 pt-1.5 border-t border-white/5">
                  <span className="text-[9px] text-white/40 uppercase tracking-wider">Role Badge</span>
                </div>
              )}
            </div>
            {/* Tooltip arrow */}
            <div
              className="absolute left-1/2 -translate-x-1/2 top-full w-2 h-1"
              style={{
                clipPath: 'polygon(0 0, 100% 0, 50% 100%)',
                background: 'rgba(255, 255, 255, 0.05)',
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Animated badge with entrance animation
export function AnimatedBadge(props: BadgeProps & { delay?: number }) {
  const { delay = 0, ...badgeProps } = props;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8, y: 8 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{
        duration: 0.3,
        delay,
        type: 'spring',
        stiffness: 300,
        damping: 20,
      }}
    >
      <Badge {...badgeProps} />
    </motion.div>
  );
}
