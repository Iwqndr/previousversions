// Badge system exports
export { Badge, AnimatedBadge } from './Badge';
export { BadgeGroup, BadgeRow, BadgeDisplay } from './BadgeGroup';
export { UserProfile, SideProfile, MainProfile } from './UserProfile';
export { ProfileShowcase } from './ProfileShowcase';
export { BADGES, getSortedBadges, getBadgesByCategory, DEMO_USERS } from './badgeDefinitions';
export type { BadgeDefinition } from './badgeDefinitions';
export type { UserProfileData } from './UserProfile';
