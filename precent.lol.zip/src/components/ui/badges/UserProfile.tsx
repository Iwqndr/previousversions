import { motion } from 'motion/react';
import { BadgeDefinition, getSortedBadges, getBadgesByCategory } from './badgeDefinitions';
import { BadgeGroup, BadgeRow, BadgeDisplay } from './BadgeGroup';
import { Badge } from './Badge';
import { cn } from '../../../lib/utils';
import { MapPin, Link, Eye, Heart } from 'lucide-react';

interface UserProfileData {
  username: string;
  displayName: string;
  bio: string;
  avatarUrl?: string;
  location?: string;
  website?: string;
  badges: string[];
  views?: number;
  likes?: number;
  joinDate?: string;
}

export interface UserProfileProps {
  user: UserProfileData;
  variant?: 'side' | 'main';
  accentColor?: string;
  className?: string;
}

// Side Profile - Compact view for sidebar/header
export function SideProfile({ user, accentColor = '#ff8800', className }: Omit<UserProfileProps, 'variant'>) {
  const sortedBadges = getSortedBadges(user.badges);
  const primaryBadge = sortedBadges[0];
  const secondaryBadges = sortedBadges.slice(1, 4);

  return (
    <div className={cn('glass rounded-2xl p-4 border border-white/10', className)}>
      {/* Avatar with primary badge */}
      <div className="flex items-center gap-3 mb-3">
        <div className="relative">
          <div
            className="w-12 h-12 rounded-full overflow-hidden flex items-center justify-center text-lg font-bold"
            style={{
              background: `linear-gradient(135deg, ${accentColor}20, ${accentColor}40)`,
              border: `2px solid ${accentColor}`,
              color: accentColor,
            }}
          >
            {user.avatarUrl ? (
              <img src={user.avatarUrl} alt={user.displayName} className="w-full h-full object-cover" />
            ) : (
              user.displayName.charAt(0).toUpperCase()
            )}
          </div>
          {/* Primary badge indicator */}
          {primaryBadge && (
            <div
              className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-[10px]"
              style={{
                background: primaryBadge.gradient,
                boxShadow: `0 0 8px ${primaryBadge.glowColor}`,
              }}
              title={primaryBadge.name}
            >
              {primaryBadge.icon}
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-bold text-white truncate">{user.displayName}</h3>
          <p className="text-[10px] text-white/40">@{user.username}</p>
        </div>
      </div>

      {/* Bio */}
      {user.bio && (
        <p className="text-[11px] text-white/60 mb-3 line-clamp-2">{user.bio}</p>
      )}

      {/* Location & Stats */}
      <div className="flex items-center gap-3 mb-3 text-[10px] text-white/40">
        {user.location && (
          <div className="flex items-center gap-1">
            <MapPin size={10} />
            <span>{user.location}</span>
          </div>
        )}
        {user.views && (
          <div className="flex items-center gap-1">
            <Eye size={10} />
            <span>{user.views}</span>
          </div>
        )}
      </div>

      {/* Secondary badges */}
      {secondaryBadges.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {secondaryBadges.map((badge) => (
            <Badge
              key={badge.id}
              badge={badge}
              size="xs"
              variant="icon-only"
              showTooltip={true}
            />
          ))}
          {user.badges.length > 4 && (
            <div className="h-5 px-1.5 rounded-full bg-white/5 border border-white/10 flex items-center text-[9px] text-white/40">
              +{user.badges.length - 4}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// Main Profile - Full detailed view
export function MainProfile({ user, accentColor = '#ff8800', className }: Omit<UserProfileProps, 'variant'>) {
  const sortedBadges = getSortedBadges(user.badges);
  const roleBadges = getBadgesByCategory(user.badges, 'role');
  const achievementBadges = getBadgesByCategory(user.badges, 'achievement');
  const specialBadges = getBadgesByCategory(user.badges, 'special');

  return (
    <div className={cn('space-y-6', className)}>
      {/* Profile Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-3xl p-8 border border-white/10"
      >
        <div className="flex items-start gap-6">
          {/* Avatar */}
          <div className="relative">
            <div
              className="w-24 h-24 rounded-2xl overflow-hidden flex items-center justify-center text-3xl font-bold"
              style={{
                background: `linear-gradient(135deg, ${accentColor}15, ${accentColor}30)`,
                border: `3px solid ${accentColor}`,
                color: accentColor,
              }}
            >
              {user.avatarUrl ? (
                <img src={user.avatarUrl} alt={user.displayName} className="w-full h-full object-cover" />
              ) : (
                user.displayName.charAt(0).toUpperCase()
              )}
            </div>

            {/* Top badge overlay */}
            {sortedBadges[0] && (
              <div
                className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-2 py-1 rounded-full text-[10px] font-bold flex items-center gap-1"
                style={{
                  background: sortedBadges[0].gradient,
                  color: sortedBadges[0].textColor,
                  boxShadow: `0 0 16px ${sortedBadges[0].glowColor}`,
                }}
              >
                <span>{sortedBadges[0].icon}</span>
                <span>{sortedBadges[0].name}</span>
              </div>
            )}
          </div>

          {/* User Info */}
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-black text-white">{user.displayName}</h1>
              {/* Verified badge if present */}
              {user.badges.includes('verified') && (
                <span className="text-emerald-400" title="Verified">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                  </svg>
                </span>
              )}
            </div>

            <p className="text-white/40 text-sm mb-3">@{user.username}</p>

            {user.bio && (
              <p className="text-white/70 mb-4 max-w-lg">{user.bio}</p>
            )}

            {/* Meta info */}
            <div className="flex flex-wrap items-center gap-4 text-sm text-white/50">
              {user.location && (
                <div className="flex items-center gap-1.5">
                  <MapPin size={14} />
                  <span>{user.location}</span>
                </div>
              )}
              {user.website && (
                <div className="flex items-center gap-1.5">
                  <Link size={14} />
                  <a href={user.website} className="hover:text-white transition-colors">{user.website}</a>
                </div>
              )}
              {user.joinDate && (
                <div className="text-white/30 text-xs">
                  Joined {user.joinDate}
                </div>
              )}
            </div>

            {/* Stats */}
            <div className="flex items-center gap-6 mt-4">
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10">
                <Eye size={16} style={{ color: accentColor }} />
                <span className="text-sm font-bold">{user.views || 0}</span>
                <span className="text-xs text-white/40">views</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10">
                <Heart size={16} style={{ color: accentColor }} />
                <span className="text-sm font-bold">{user.likes || 0}</span>
                <span className="text-xs text-white/40">likes</span>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* All Badges Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass rounded-3xl p-8 border border-white/10"
      >
        <BadgeDisplay badgeIds={user.badges} />
      </motion.div>

      {/* Badges by Category */}
      {roleBadges.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="glass rounded-2xl p-6 border border-white/10"
        >
          <BadgeGroup
            badgeIds={roleBadges.map(b => b.id)}
            layout="wrap"
            size="md"
            groupLabel="Roles"
          />
        </motion.div>
      )}

      {achievementBadges.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass rounded-2xl p-6 border border-white/10"
        >
          <BadgeGroup
            badgeIds={achievementBadges.map(b => b.id)}
            layout="wrap"
            size="sm"
            groupLabel="Achievements"
          />
        </motion.div>
      )}

      {specialBadges.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="glass rounded-2xl p-6 border border-white/10"
        >
          <BadgeGroup
            badgeIds={specialBadges.map(b => b.id)}
            layout="wrap"
            size="sm"
            groupLabel="Special"
          />
        </motion.div>
      )}
    </div>
  );
}

// Unified profile component that can switch between views
export function UserProfile({ user, variant = 'main', accentColor, className }: UserProfileProps) {
  if (variant === 'side') {
    return <SideProfile user={user} accentColor={accentColor} className={className} />;
  }

  return <MainProfile user={user} accentColor={accentColor} className={className} />;
}

export type { UserProfileData, UserProfileProps };
