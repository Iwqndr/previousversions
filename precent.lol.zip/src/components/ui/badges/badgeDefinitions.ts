// Badge definitions with styles, colors, and descriptions
import { LucideIcon, Crown, Shield, Scale, BarChart3, Code, Star, Rocket, Flame, FlaskConical, Trophy, BadgeCheck, Gem, Sparkles, Medal, Target, Award } from 'lucide-react';

export interface BadgeDefinition {
  id: string;
  name: string;
  description: string;
  icon: LucideIcon;
  // Visual styling
  gradient: string;
  textColor: string;
  borderColor: string;
  glowColor: string;
  // Hierarchy (higher = more significant)
  hierarchy: number;
  // Category
  category: 'role' | 'achievement' | 'special';
}

export const BADGES: Record<string, BadgeDefinition> = {
  // Role Badges
  owner: {
    id: 'owner',
    name: 'Owner',
    description: 'Platform owner with full system access',
    icon: Crown,
    gradient: 'linear-gradient(135deg, #FFD700 0%, #FFA500 50%, #FF8C00 100%)',
    textColor: '#000000',
    borderColor: '#FFD700',
    glowColor: 'rgba(255, 215, 0, 0.5)',
    hierarchy: 100,
    category: 'role',
  },
  admin: {
    id: 'admin',
    name: 'Admin',
    description: 'Administrator with elevated system permissions',
    icon: Shield,
    gradient: 'linear-gradient(135deg, #FF0000 0%, #DC2626 50%, #991B1B 100%)',
    textColor: '#FFFFFF',
    borderColor: '#EF4444',
    glowColor: 'rgba(239, 68, 68, 0.5)',
    hierarchy: 90,
    category: 'role',
  },
  moderator: {
    id: 'moderator',
    name: 'Moderator',
    description: 'Community moderator maintaining platform standards',
    icon: Scale,
    gradient: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 50%, #1E40AF 100%)',
    textColor: '#FFFFFF',
    borderColor: '#60A5FA',
    glowColor: 'rgba(59, 130, 246, 0.5)',
    hierarchy: 80,
    category: 'role',
  },
  manager: {
    id: 'manager',
    name: 'Manager',
    description: 'Team manager with organizational responsibilities',
    icon: BarChart3,
    gradient: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 50%, #6D28D9 100%)',
    textColor: '#FFFFFF',
    borderColor: '#A78BFA',
    glowColor: 'rgba(139, 92, 246, 0.5)',
    hierarchy: 70,
    category: 'role',
  },
  developer: {
    id: 'developer',
    name: 'Developer',
    description: 'Core platform developer contributing to the codebase',
    icon: Code,
    gradient: 'linear-gradient(135deg, #10B981 0%, #059669 50%, #047857 100%)',
    textColor: '#FFFFFF',
    borderColor: '#34D399',
    glowColor: 'rgba(16, 185, 129, 0.5)',
    hierarchy: 75,
    category: 'role',
  },

  // Achievement Badges
  contributor: {
    id: 'contributor',
    name: 'Contributor',
    description: 'Active community contributor with valuable input',
    icon: Star,
    gradient: 'linear-gradient(135deg, #F59E0B 0%, #D97706 50%, #B45309 100%)',
    textColor: '#000000',
    borderColor: '#FBBF24',
    glowColor: 'rgba(245, 158, 11, 0.5)',
    hierarchy: 50,
    category: 'achievement',
  },
  early_access: {
    id: 'early_access',
    name: 'Early Access',
    description: 'Early adopter who joined during beta phase',
    icon: Rocket,
    gradient: 'linear-gradient(135deg, #EC4899 0%, #DB2777 50%, #BE185D 100%)',
    textColor: '#FFFFFF',
    borderColor: '#F472B6',
    glowColor: 'rgba(236, 72, 153, 0.5)',
    hierarchy: 60,
    category: 'special',
  },
  og: {
    id: 'og',
    name: 'OG',
    description: 'Original Gangster - one of the first platform members',
    icon: Flame,
    gradient: 'linear-gradient(135deg, #F97316 0%, #EA580C 50%, #C2410C 100%)',
    textColor: '#FFFFFF',
    borderColor: '#FB923C',
    glowColor: 'rgba(249, 115, 22, 0.5)',
    hierarchy: 65,
    category: 'special',
  },
  tester: {
    id: 'tester',
    name: 'Tester',
    description: 'Beta tester helping identify bugs and improve features',
    icon: FlaskConical,
    gradient: 'linear-gradient(135deg, #06B6D4 0%, #0891B2 50%, #0E7490 100%)',
    textColor: '#FFFFFF',
    borderColor: '#22D3EE',
    glowColor: 'rgba(6, 182, 212, 0.5)',
    hierarchy: 55,
    category: 'achievement',
  },
  top_creator: {
    id: 'top_creator',
    name: 'Top Creator',
    description: 'Top 10 most viewed profile this month',
    icon: Trophy,
    gradient: 'linear-gradient(135deg, #FFD700 0%, #FFC107 50%, #FFB300 100%)',
    textColor: '#000000',
    borderColor: '#FFE082',
    glowColor: 'rgba(255, 215, 0, 0.5)',
    hierarchy: 45,
    category: 'achievement',
  },
  verified: {
    id: 'verified',
    name: 'Verified',
    description: 'Verified identity - authentic and trustworthy',
    icon: BadgeCheck,
    gradient: 'linear-gradient(135deg, #10B981 0%, #34D399 50%, #6EE7B7 100%)',
    textColor: '#000000',
    borderColor: '#34D399',
    glowColor: 'rgba(52, 211, 153, 0.5)',
    hierarchy: 40,
    category: 'achievement',
  },
  supporter: {
    id: 'supporter',
    name: 'Supporter',
    description: 'Premium supporter helping fund the platform',
    icon: Gem,
    gradient: 'linear-gradient(135deg, #6366F1 0%, #8B5CF6 50%, #A78BFA 100%)',
    textColor: '#FFFFFF',
    borderColor: '#8B5CF6',
    glowColor: 'rgba(139, 92, 246, 0.5)',
    hierarchy: 35,
    category: 'achievement',
  },

  // Special Badges
  founder: {
    id: 'founder',
    name: 'Founder',
    description: 'Platform founder who built this from the ground up',
    icon: Sparkles,
    gradient: 'linear-gradient(135deg, #FFFFFF 0%, #F5F5F5 50%, #E0E0E0 100%)',
    textColor: '#000000',
    borderColor: '#FFFFFF',
    glowColor: 'rgba(255, 255, 255, 0.6)',
    hierarchy: 95,
    category: 'special',
  },
  legend: {
    id: 'legend',
    name: 'Legend',
    description: 'Legendary member with outstanding community impact',
    icon: Medal,
    gradient: 'linear-gradient(135deg, #FF6B6B 0%, #FF8E53 50%, #FFC75F 100%)',
    textColor: '#000000',
    borderColor: '#FF8E53',
    glowColor: 'rgba(255, 142, 83, 0.5)',
    hierarchy: 85,
    category: 'special',
  },
  milestone_1000: {
    id: 'milestone_1000',
    name: '1K Club',
    description: 'Reached 1,000 profile views milestone',
    icon: Target,
    gradient: 'linear-gradient(135deg, #14B8A6 0%, #0D9488 50%, #0F766E 100%)',
    textColor: '#FFFFFF',
    borderColor: '#2DD4BF',
    glowColor: 'rgba(20, 184, 166, 0.5)',
    hierarchy: 30,
    category: 'achievement',
  },
  event_winner: {
    id: 'event_winner',
    name: 'Event Winner',
    description: 'Winner of a platform-hosted event or competition',
    icon: Award,
    gradient: 'linear-gradient(135deg, #EAB308 0%, #CA8A04 50%, #A16207 100%)',
    textColor: '#000000',
    borderColor: '#FACC15',
    glowColor: 'rgba(234, 179, 8, 0.5)',
    hierarchy: 25,
    category: 'achievement',
  },
};

// Helper function to get badges sorted by hierarchy
export function getSortedBadges(badgeIds: string[]): BadgeDefinition[] {
  return badgeIds
    .map(id => BADGES[id])
    .filter(Boolean)
    .sort((a, b) => b.hierarchy - a.hierarchy);
}

// Helper function to get badges by category
export function getBadgesByCategory(badgeIds: string[], category: 'role' | 'achievement' | 'special'): BadgeDefinition[] {
  return badgeIds
    .map(id => BADGES[id])
    .filter(badge => badge && badge.category === category)
    .sort((a, b) => b.hierarchy - a.hierarchy);
}

// Predefined badge combinations for demo users
export const DEMO_USERS = [
  {
    username: 'joe',
    displayName: 'Joe',
    role: 'owner',
    badges: ['owner', 'founder', 'og', 'developer', 'legend'],
    bio: 'Building the future 🔮',
    avatarSeed: 'joe',
  },
  {
    username: 'wonder',
    displayName: 'Wonder',
    role: 'co-owner',
    badges: ['admin', 'developer', 'early_access', 'top_creator'],
    bio: 'Code • Create • Conquer',
    avatarSeed: 'wonder',
  },
  {
    username: 'alex_moder',
    displayName: 'Alex Thompson',
    role: 'moderator',
    badges: ['moderator', 'tester', 'verified', 'milestone_1000'],
    bio: 'Keeping things awesome ✨',
    avatarSeed: 'alex',
  },
  {
    username: 'sarah_dev',
    displayName: 'Sarah Chen',
    role: 'developer',
    badges: ['developer', 'contributor', 'early_access', 'supporter'],
    bio: 'Full-stack wizard 🧙‍♀️',
    avatarSeed: 'sarah',
  },
  {
    username: 'mike_manager',
    displayName: 'Mike Johnson',
    role: 'manager',
    badges: ['manager', 'contributor', 'event_winner'],
    bio: 'Managing chaos since 2020',
    avatarSeed: 'mike',
  },
  {
    username: 'luna_og',
    displayName: 'Luna Park',
    role: 'user',
    badges: ['og', 'early_access', 'tester', 'verified', 'milestone_1000'],
    bio: 'Day one supporter 🌙',
    avatarSeed: 'luna',
  },
  {
    username: 'max_creator',
    displayName: 'Max Rivera',
    role: 'user',
    badges: ['top_creator', 'contributor', 'verified', 'supporter'],
    bio: 'Creating cool stuff daily',
    avatarSeed: 'max',
  },
  {
    username: 'nova_tester',
    displayName: 'Nova Kim',
    role: 'user',
    badges: ['tester', 'early_access', 'event_winner', 'milestone_1000'],
    bio: 'Breaking things to make them better 🐛',
    avatarSeed: 'nova',
  },
];
