import { motion } from 'motion/react';
import { BadgeDefinition, getSortedBadges } from './badgeDefinitions';
import { Badge, AnimatedBadge } from './Badge';
import { cn } from '../../../lib/utils';

interface BadgeGroupProps {
  badgeIds: string[];
  layout?: 'horizontal' | 'vertical' | 'wrap' | 'stack';
  size?: 'xs' | 'sm' | 'md' | 'lg';
  variant?: 'default' | 'compact' | 'icon-only';
  maxDisplay?: number;
  animated?: boolean;
  showCount?: boolean;
  className?: string;
  groupLabel?: string;
}

export function BadgeGroup({
  badgeIds,
  layout = 'wrap',
  size = 'md',
  variant = 'default',
  maxDisplay,
  animated = false,
  showCount = false,
  className,
  groupLabel,
}: BadgeGroupProps) {
  const sortedBadges = getSortedBadges(badgeIds);
  const displayBadges = maxDisplay ? sortedBadges.slice(0, maxDisplay) : sortedBadges;
  const remainingCount = maxDisplay && badgeIds.length > maxDisplay 
    ? badgeIds.length - maxDisplay 
    : 0;

  const layoutClasses = {
    horizontal: 'flex flex-row gap-2',
    vertical: 'flex flex-col gap-2',
    wrap: 'flex flex-wrap gap-2',
    stack: 'flex flex-wrap gap-1.5',
  };

  return (
    <div className={cn('relative', className)}>
      {groupLabel && (
        <div className="mb-2 flex items-center gap-2">
          <div className="h-px flex-1 bg-white/10" />
          <span className="text-[9px] font-bold text-white/30 uppercase tracking-[0.15em]">
            {groupLabel}
          </span>
          <div className="h-px flex-1 bg-white/10" />
        </div>
      )}

      <div className={cn(layoutClasses[layout])}>
        {displayBadges.map((badge, index) =>
          animated ? (
            <AnimatedBadge
              key={badge.id}
              badge={badge}
              size={size}
              variant={variant}
              delay={index * 0.05}
            />
          ) : (
            <Badge
              key={badge.id}
              badge={badge}
              size={size}
              variant={variant}
            />
          )
        )}

        {remainingCount > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className={cn(
              'inline-flex items-center justify-center rounded-full font-bold',
              'bg-white/5 border border-white/10 backdrop-blur-sm',
              size === 'xs' && 'h-5 px-1.5 text-[9px]',
              size === 'sm' && 'h-6 px-2 text-[10px]',
              size === 'md' && 'h-7 px-2.5 text-xs',
              size === 'lg' && 'h-8 px-3 text-sm',
            )}
          >
            +{remainingCount}
          </motion.div>
        )}
      </div>

      {showCount && badgeIds.length > 0 && (
        <div className="mt-2 text-[10px] text-white/30 text-center">
          {badgeIds.length} badge{badgeIds.length !== 1 ? 's' : ''} earned
        </div>
      )}
    </div>
  );
}

// Compact badge row for side profiles
export function BadgeRow({
  badgeIds,
  size = 'sm',
  maxDisplay = 5,
  className,
}: {
  badgeIds: string[];
  size?: 'xs' | 'sm' | 'md';
  maxDisplay?: number;
  className?: string;
}) {
  return (
    <BadgeGroup
      badgeIds={badgeIds}
      layout="wrap"
      size={size}
      variant="compact"
      maxDisplay={maxDisplay}
      className={cn('justify-center', className)}
    />
  );
}

// Full badge display for main profile
export function BadgeDisplay({
  badgeIds,
  animated = true,
  className,
}: {
  badgeIds: string[];
  animated?: boolean;
  className?: string;
}) {
  return (
    <BadgeGroup
      badgeIds={badgeIds}
      layout="wrap"
      size="md"
      variant="default"
      animated={animated}
      groupLabel="Badges & Roles"
      className={className}
    />
  );
}
