import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { DEMO_USERS } from './badgeDefinitions';
import { SideProfile, MainProfile, UserProfileData } from './UserProfile';
import { BadgeGroup } from './BadgeGroup';
import { CustomCursor } from '../CustomCursor';
import { BackgroundSystem } from '../BackgroundSystem';
import { ArrowLeft, Users, User, Grid, Star } from 'lucide-react';
import { cn } from '../../../lib/utils';

type ViewMode = 'grid' | 'individual' | 'side-profiles';

export function ProfileShowcase({ onBack }: { onBack?: () => void }) {
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [selectedUserIndex, setSelectedUserIndex] = useState(0);
  const selectedUser = DEMO_USERS[selectedUserIndex];

  // Transform demo users to profile data
  const profileUsers: UserProfileData[] = DEMO_USERS.map((user, index) => ({
    username: user.username,
    displayName: user.displayName,
    bio: user.bio,
    badges: user.badges,
    views: Math.floor(Math.random() * 5000) + 500,
    likes: Math.floor(Math.random() * 1000) + 100,
    location: ['San Francisco, CA', 'New York, NY', 'London, UK', 'Tokyo, JP', 'Toronto, CA', 'Seoul, KR', 'Sydney, AU', 'Berlin, DE'][index],
    website: `https://${user.username}.com`,
    joinDate: ['Jan 2024', 'Feb 2024', 'Mar 2024', 'Apr 2024', 'May 2024', 'Jun 2024', 'Jul 2024', 'Aug 2024'][index],
  }));

  const viewModeButtons = [
    { id: 'grid' as const, icon: Grid, label: 'All Profiles' },
    { id: 'individual' as const, icon: User, label: 'Individual' },
    { id: 'side-profiles' as const, icon: Users, label: 'Side Views' },
  ];

  return (
    <div className="min-h-screen bg-base text-white relative overflow-x-hidden">
      <CustomCursor />
      <BackgroundSystem />

      {/* Header */}
      <header className="sticky top-0 z-30 glass border-b border-white/10">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {onBack && (
                <button
                  onClick={onBack}
                  className="flex items-center gap-2 text-white/40 hover:text-white transition-colors"
                >
                  <ArrowLeft size={18} />
                  <span className="text-sm font-bold">Back</span>
                </button>
              )}
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-orange-500 to-amber-500 flex items-center justify-center">
                  <Star size={16} className="text-white" />
                </div>
                <h1 className="text-xl font-black tracking-tight">Profile Showcase</h1>
              </div>
            </div>

            {/* View Mode Switcher */}
            <div className="flex items-center gap-2 glass rounded-full p-1">
              {viewModeButtons.map(({ id, icon: Icon, label }) => (
                <button
                  key={id}
                  onClick={() => setViewMode(id)}
                  className={cn(
                    'flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold transition-all',
                    viewMode === id
                      ? 'bg-white/10 text-white'
                      : 'text-white/40 hover:text-white/60'
                  )}
                >
                  <Icon size={14} />
                  <span className="hidden sm:inline">{label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="container mx-auto px-6 py-12">
        <AnimatePresence mode="wait">
          {/* Grid View - All Users */}
          {viewMode === 'grid' && (
            <motion.div
              key="grid"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-12"
            >
              <div className="text-center mb-8">
                <h2 className="text-3xl font-black mb-2">All Users with Badges</h2>
                <p className="text-white/40 text-sm">Hover over badges to see descriptions</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {profileUsers.map((user, index) => (
                  <motion.div
                    key={user.username}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    whileHover={{ y: -4 }}
                    className="glass rounded-3xl p-6 border border-white/10 hover:border-white/20 transition-all cursor-pointer"
                    onClick={() => {
                      setSelectedUserIndex(index);
                      setViewMode('individual');
                    }}
                  >
                    {/* User Header */}
                    <div className="flex items-center gap-4 mb-4">
                      <div
                        className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-bold"
                        style={{
                          background: `linear-gradient(135deg, #ff880020, #ff880040)`,
                          border: `2px solid #ff8800`,
                          color: '#ff8800',
                        }}
                      >
                        {user.displayName.charAt(0)}
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg font-bold">{user.displayName}</h3>
                        <p className="text-white/40 text-sm">@{user.username}</p>
                        <p className="text-white/60 text-xs mt-1">{user.bio}</p>
                      </div>
                    </div>

                    {/* Badges */}
                    <BadgeGroup
                      badgeIds={user.badges}
                      layout="wrap"
                      size="sm"
                      variant="default"
                      animated={false}
                    />

                    {/* Stats */}
                    <div className="flex items-center gap-4 mt-4 pt-4 border-t border-white/5">
                      <div className="text-xs text-white/40">
                        <span className="text-white font-bold">{user.views?.toLocaleString()}</span> views
                      </div>
                      <div className="text-xs text-white/40">
                        <span className="text-white font-bold">{user.likes?.toLocaleString()}</span> likes
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {/* Individual View - Full Profile */}
          {viewMode === 'individual' && (
            <motion.div
              key="individual"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-4xl mx-auto"
            >
              {/* User Selector */}
              <div className="flex items-center gap-2 mb-8 overflow-x-auto pb-2">
                {profileUsers.map((user, index) => (
                  <button
                    key={user.username}
                    onClick={() => setSelectedUserIndex(index)}
                    className={cn(
                      'flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-all text-xs font-bold',
                      selectedUserIndex === index
                        ? 'bg-white/10 text-white border border-white/20'
                        : 'glass text-white/40 hover:text-white/60 border border-white/5'
                    )}
                  >
                    <div
                      className="w-6 h-6 rounded-full flex items-center justify-center text-xs"
                      style={{
                        background: `linear-gradient(135deg, #ff880020, #ff880040)`,
                        color: '#ff8800',
                      }}
                    >
                      {user.displayName.charAt(0)}
                    </div>
                    {user.displayName}
                  </button>
                ))}
              </div>

              {/* Main Profile View */}
              <MainProfile
                user={selectedUser}
                accentColor="#ff8800"
              />
            </motion.div>
          )}

          {/* Side Profiles View */}
          {viewMode === 'side-profiles' && (
            <motion.div
              key="side"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              <div className="text-center mb-8">
                <h2 className="text-3xl font-black mb-2">Side Profile Variants</h2>
                <p className="text-white/40 text-sm">Compact badge displays for sidebars and headers</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {profileUsers.map((user, index) => (
                  <motion.div
                    key={user.username}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <SideProfile
                      user={user}
                      accentColor="#ff8800"
                    />
                  </motion.div>
                ))}
              </div>

              {/* Comparison Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="mt-16 glass rounded-3xl p-8 border border-white/10"
              >
                <h3 className="text-2xl font-black mb-6 text-center">Side-by-Side Comparison</h3>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Side Profile */}
                  <div>
                    <h4 className="text-sm font-bold text-white/40 uppercase tracking-wider mb-4 text-center">Side Profile View</h4>
                    <SideProfile user={profileUsers[0]} accentColor="#ff8800" />
                  </div>
                  {/* Main Profile */}
                  <div>
                    <h4 className="text-sm font-bold text-white/40 uppercase tracking-wider mb-4 text-center">Main Profile View</h4>
                    <div className="scale-[0.6] origin-top">
                      <MainProfile user={profileUsers[0]} accentColor="#ff8800" />
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
