import { useState } from 'react';
import { motion } from 'motion/react';
import { X, AlertTriangle, Send, CheckCircle2 } from 'lucide-react';
import { getSupabase } from '@/src/lib/supabase';
import { api } from '@/src/lib/api';
import { showToast } from '@/src/lib/toast';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportedUsername: string;
  reportedUid: string;
}

export function ReportModal({ isOpen, onClose, reportedUsername, reportedUid }: ReportModalProps) {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    if (!reason.trim()) {
      showToast('Please provide a reason for the report', 'warning');
      return;
    }

    setLoading(true);
    try {
      // Get current user's actual email for verification (not sent to webhook)
      const { data: { user } } = await supabase.auth.getUser();
      
      // Verify email if provided
      if (email.trim() && user?.email && email.trim().toLowerCase() !== user.email.toLowerCase()) {
        showToast('Email does not match your account email', 'error');
        setLoading(false);
        return;
      }

      // Prepare report data
      const reportData = {
        reporterUsername: username.trim() || (user?.email?.split('@')[0] || 'Anonymous'),
        reporterEmail: email.trim() || user?.email || 'Anonymous',
        reportedUsername,
        reportedUid,
        reason: reason.trim(),
        timestamp: new Date().toISOString(),
        reporterUid: user?.id || 'Unknown',
      };

      // Send to Discord webhook
      const webhookUrl = 'https://discord.com/api/webhooks/1490327777721716918/EfDG4lNvA5D9Qp2Z4brg8y69Uu0DR3wAO2PKnlRWqkVGhZqWH4J1xsyfmK74KIKkLdVD';
      
      if (webhookUrl) {
        const webhookPayload = {
          embeds: [{
            title: '🚨 New User Report',
            color: 16753920, // Orange
            fields: [
              { name: 'Reported User', value: `${reportedUsername} (\`${reportedUid}\`)`, inline: false },
              { name: 'Reporter', value: `${reportData.reporterUsername}`, inline: true },
              { name: 'Reporter Email', value: reportData.reporterEmail, inline: true },
              { name: 'Reporter UID', value: reportData.reporterUid, inline: true },
              { name: 'Reason', value: reason.trim(), inline: false },
              { name: 'Timestamp', value: reportData.timestamp, inline: false },
            ],
            footer: { text: 'precent.lol Report System' },
          }],
        };

        await fetch(webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(webhookPayload),
        });
      }

      // Save to database via Worker
      await api.createReport(reportedUid, reason.trim());

      setSubmitted(true);
      showToast('Report submitted successfully', 'success');
      
      setTimeout(() => {
        onClose();
        setSubmitted(false);
        setUsername('');
        setEmail('');
        setReason('');
      }, 2000);
    } catch (error) {
      console.error('Error submitting report:', error);
      showToast('Failed to submit report. Please try again.', 'error');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="w-full max-w-md"
      >
        <div className="glass border border-white/10 rounded-2xl p-8 space-y-6 relative overflow-hidden">
          {/* Background accent */}
          <div className="absolute -top-24 -right-24 w-48 h-48 bg-red-500/10 blur-[100px] rounded-full pointer-events-none" />

          {submitted ? (
            <div className="text-center space-y-4 py-8">
              <CheckCircle2 size={64} className="text-green-400 mx-auto" />
              <h3 className="text-2xl font-black text-white">Report Submitted</h3>
              <p className="text-white/60">Thank you for your report. Our team will review it shortly.</p>
            </div>
          ) : (
            <>
              {/* Header */}
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold flex items-center gap-2 text-red-400">
                  <AlertTriangle size={20} /> Report User
                </h3>
                <button
                  onClick={onClose}
                  className="text-white/40 hover:text-white transition-colors"
                >
                  <X size={24} />
                </button>
              </div>

              <p className="text-sm text-white/60">
                Reporting: <span className="font-bold text-white">@{reportedUsername}</span>
              </p>

              {/* Form */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-black text-white/30 uppercase tracking-widest">
                    Username (Optional)
                  </label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Leave blank for anonymous or use profile username"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-red-500/50 transition-all placeholder:text-white/20 text-sm"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black text-white/30 uppercase tracking-widest">
                    Email (Optional)
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Leave blank for anonymous"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-red-500/50 transition-all placeholder:text-white/20 text-sm"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black text-white/30 uppercase tracking-widest">
                    Reason for Report *
                  </label>
                  <textarea
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="Please describe the issue..."
                    rows={4}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-red-500/50 transition-all placeholder:text-white/20 text-sm resize-none"
                    required
                  />
                </div>
              </div>

              {/* Submit Button */}
              <button
                onClick={handleSubmit}
                disabled={loading || !reason.trim()}
                className="w-full flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-red-500 text-white font-bold text-sm hover:bg-red-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <Send size={16} />
                    Submit Report
                  </>
                )}
              </button>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
}
