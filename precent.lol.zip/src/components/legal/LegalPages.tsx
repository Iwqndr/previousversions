import React from 'react';
import { motion } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { Shield, Lock, FileText, ChevronLeft } from 'lucide-react';
import { NeonButton } from '../ui/NeonButton';

interface LegalPageProps {
  title: string;
  lastUpdated: string;
  content: React.ReactNode;
  onBack: () => void;
}

export function LegalPage({ title, lastUpdated, content, onBack }: LegalPageProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="max-w-4xl mx-auto py-12 px-6"
    >
      <NeonButton variant="ghost" size="sm" onClick={onBack} className="mb-8">
        <ChevronLeft size={16} /> Back
      </NeonButton>

      <GlassCard className="p-10">
        <h1 className="text-4xl font-black mb-2">{title}</h1>
        <p className="text-white/40 text-sm mb-10">Last Updated: {lastUpdated}</p>
        
        <div className="prose prose-invert max-w-none space-y-6 text-white/70">
          {content}
        </div>
      </GlassCard>
    </motion.div>
  );
}

export const TermsOfService = ({ onBack }: { onBack: () => void }) => (
  <LegalPage 
    title="Terms of Service" 
    lastUpdated="April 4, 2026"
    onBack={onBack}
    content={
      <>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">1. Acceptance of Terms</h2>
          <p>By accessing and using precent.lol ("the Platform"), you agree to be bound by these Terms of Service. If you do not agree, please do not use the platform. We reserve the right to modify these terms at any time without prior notice. Your continued use of the Platform after any changes constitutes acceptance of the new terms.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">2. User Accounts</h2>
          <p>To access certain features, you must create an account. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You must notify us immediately of any unauthorized use of your account. You must be at least 13 years old to use this Platform.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">3. User Content & Conduct</h2>
          <p>You are solely responsible for the content you post on your profile. We reserve the right to remove any content that violates our community guidelines, including but not limited to: hate speech, harassment, illegal content, sexually explicit material, or content that infringes on third-party intellectual property rights. You agree not to use the platform for any unlawful purpose.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">4. Prohibited Conduct</h2>
          <p>Users may not engage in any activity that interferes with the platform's operation, including but not limited to: hacking, spamming, scraping, or impersonating others. Any attempt to disrupt our services, bypass security measures, or exploit vulnerabilities will result in immediate termination of your account and potential legal action.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">5. Fees and Payments (Pro Subscription)</h2>
          <p>Certain features of the Platform require a paid subscription ("Pro"). All fees are non-refundable unless required by law. We reserve the right to change our subscription fees at any time. Your subscription will automatically renew unless cancelled at least 24 hours before the end of the current period.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">6. Intellectual Property</h2>
          <p>The precent.lol name, logo, and platform design are the property of precent.lol. You may not use them without our express permission. By posting content on the platform, you grant us a non-exclusive, royalty-free, worldwide license to display, distribute, and modify that content for the purpose of operating and improving the Platform.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">7. Limitation of Liability</h2>
          <p>precent.lol is provided "as is" and "as available" without any warranties, express or implied. We are not liable for any damages arising from your use of the platform, including data loss, service interruptions, unauthorized access to your account, or the conduct of other users.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">8. Termination</h2>
          <p>We reserve the right to terminate or suspend your account at our sole discretion, without notice, for conduct that we believe violates these Terms of Service, is harmful to other users, or for any other reason we deem necessary.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">9. Governing Law</h2>
          <p>These terms shall be governed by and construed in accordance with the laws of the jurisdiction in which precent.lol operates, without regard to its conflict of law provisions.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">10. Platform Responsibilities</h2>
          <p>We strive to maintain high availability and security. However, we do not guarantee uninterrupted service. We are not responsible for third-party links or services integrated into user profiles.</p>
        </section>
      </>
    }
  />
);

export const PrivacyPolicy = ({ onBack }: { onBack: () => void }) => (
  <LegalPage 
    title="Privacy Policy" 
    lastUpdated="April 4, 2026"
    onBack={onBack}
    content={
      <>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">1. Information We Collect</h2>
          <p>We collect information you provide directly to us, such as your email, username, profile data, and payment information (processed through third-party providers). We also collect analytics data like views, clicks, IP addresses, and interaction history to improve your experience and ensure platform security.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">2. How We Use Information</h2>
          <p>We use your information to provide and improve our services, personalize your experience, process payments, and communicate with you about updates, security issues, or promotional offers. We may use aggregated, non-identifiable data for research, marketing, and platform optimization.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">3. Data Sharing & Security</h2>
          <p>We do not sell your personal data to third parties. We may share data with trusted service providers who help us operate the platform (e.g., payment processors, hosting providers). We implement industry-standard security measures to protect your data, but no method of transmission over the internet is 100% secure.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">4. Cookies & Tracking</h2>
          <p>We use cookies and similar tracking technologies to track activity on our service and hold certain information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our service.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">5. Data Retention</h2>
          <p>We retain your personal information for as long as your account is active or as needed to provide you with our services. We will also retain and use your information as necessary to comply with our legal obligations, resolve disputes, and enforce our agreements.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">6. Children's Privacy</h2>
          <p>Our service does not address anyone under the age of 13. We do not knowingly collect personally identifiable information from children under 13. If you are a parent or guardian and you are aware that your child has provided us with personal data, please contact us.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">7. Your Rights</h2>
          <p>You have the right to access, update, or delete your personal information at any time. Depending on your location, you may have additional rights under data protection laws (e.g., GDPR, CCPA). If you wish to exercise these rights, please contact us through the platform settings or support channels.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">8. Changes to this Policy</h2>
          <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date. You are advised to review this Privacy Policy periodically for any changes.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">9. Data Storage</h2>
          <p>Your data is stored securely on our cloud infrastructure. We take reasonable steps to ensure that your data is treated securely and in accordance with this Privacy Policy.</p>
        </section>
      </>
    }
  />
);

export const CookiePolicy = ({ onBack }: { onBack: () => void }) => (
  <LegalPage 
    title="Cookie Policy" 
    lastUpdated="April 4, 2026"
    onBack={onBack}
    content={
      <>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">1. What are Cookies?</h2>
          <p>Cookies are small text files that are placed on your computer or mobile device when you visit a website. They are widely used to make websites work, or work more efficiently, as well as to provide information to the owners of the site.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">2. How We Use Cookies</h2>
          <p>We use cookies to understand and save your preferences for future visits, keep track of advertisements, and compile aggregate data about site traffic and site interaction so that we can offer better site experiences and tools in the future.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">3. Types of Cookies We Use</h2>
          <p>We use both session cookies (which expire when you close your browser) and persistent cookies (which stay on your device until you delete them or they expire). These include essential cookies for platform functionality, analytics cookies to track usage, and preference cookies to remember your settings.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white mb-3">4. Managing Cookies</h2>
          <p>You can set your browser to not accept cookies, and the above website tells you how to remove cookies from your browser. However, in a few cases, some of our website features may not function as a result.</p>
        </section>
      </>
    }
  />
);

