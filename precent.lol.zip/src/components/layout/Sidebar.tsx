import { motion } from 'motion/react';
import { 
  LayoutDashboard, 
  User, 
  Palette, 
  Link as LinkIcon, 
  Image as ImageIcon, 
  Music, 
  Trophy, 
  Settings,
  LogOut,
  ChevronRight,
  Users,
  Zap,
  ExternalLink,
  FileText,
  ShieldCheck,
  MessageSquare,
  Heart,
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { useSupabase } from '../SupabaseProvider';
import { supabase } from '@/src/lib/supabase';
import { isAdmin } from '@/src/constants/admin';
import { localStorageService } from '@/src/services/localStorageService';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const menuGroups = [
  {
    title: 'DASHBOARD',
    items: [
      { id: 'overview', icon: <LayoutDashboard size={18} />, label: 'Overview' },
    ]
  },
  {
    title: 'CUSTOMIZE',
    items: [
      { id: 'profile', icon: <User size={18} />, label: 'Profile' },
      { id: 'appearance', icon: <Palette size={18} />, label: 'Appearance' },
      { id: 'links', icon: <LinkIcon size={18} />, label: 'Links' },
      { id: 'media', icon: <ImageIcon size={18} />, label: 'Media', disabled: true },
      { id: 'music', icon: <Music size={18} />, label: 'Music' },
    ]
  },
  {
    title: 'CONNECT',
    items: [
      { id: 'discord', icon: <Users size={18} />, label: 'Discord' },
      { id: 'community', icon: <Users size={18} />, label: 'Community' },
      { id: 'leaderboard', icon: <Trophy size={18} />, label: 'Leaderboard' },
      { id: 'feedback', icon: <MessageSquare size={18} />, label: 'Feedback' },
    ]
  },
  {
    title: 'ADVANCED',
    items: [
      { id: 'moderation', icon: <ShieldCheck size={18} />, label: 'Moderation' },
      { id: 'metadata', icon: <FileText size={18} />, label: 'Metadata' },
      { id: 'credits', icon: <Heart size={18} />, label: 'Credits' },
      { id: 'settings', icon: <Settings size={18} />, label: 'Settings' },
    ]
  }
];

export function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const { profile, isDemoMode } = useSupabase();

  const handleLogout = async () => {
    try {
      if (isDemoMode) {
        localStorageService.clear();
        localStorage.removeItem('demo_mode');
        window.location.href = '/';
        return;
      }
      
      // Sign out with scope to clear all sessions
      const { error } = await supabase.auth.signOut({ 
        scope: 'global' // Clear session across all tabs/browsers
      });
      
      if (error) {
        console.error('SignOut error:', error);
      }
      
      // Clear any local storage and demo flags
      localStorage.removeItem('demo_mode');
      localStorage.removeItem('sb-' + ((import.meta as any).env?.VITE_SUPABASE_URL?.split('//')[1]?.split('.')[0] || '') + '-auth-token');
      
      // Force redirect to home
      window.location.href = '/';
    } catch (err) {
      console.error('Logout failed:', err);
      // Force clear storage and redirect even if error occurs
      localStorage.removeItem('demo_mode');
      window.location.href = '/';
    }
  };

  return (
    <aside className="w-72 h-screen bg-surface border-r border-white/5 flex flex-col p-6 sticky top-0 overflow-y-auto custom-scrollbar">
      <div className="flex items-center gap-3 mb-12 px-3">
        <div className="w-10 h-10 rounded-2xl bg-neon-orange flex items-center justify-center neon-glow">
          <span className="text-black font-black text-lg">P</span>
        </div>
        <span className="text-xl font-black tracking-tighter text-white">precent.lol</span>
      </div>

      <nav className="flex-1 space-y-10">
        {menuGroups.map((group) => (
          <div key={group.title} className="space-y-3">
            <h3 className="text-[10px] font-black text-white/20 uppercase tracking-[0.2em] px-3">{group.title}</h3>
            <div className="space-y-1">
              {group.items.filter(item => {
                if (item.disabled) return false;
                if (item.id === 'moderation' && !isAdmin(profile?.email)) return false;
                return true;
              }).map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={cn(
                    "w-full flex items-center gap-3.5 px-4 py-3 rounded-xl transition-all duration-300 group",
                    activeTab === item.id
                      ? "bg-neon-orange/10 text-neon-orange"
                      : "text-white/40 hover:text-white hover:bg-white/5"
                  )}
                >
                  <span className={cn(
                    "transition-colors duration-300",
                    activeTab === item.id ? "text-neon-orange" : "group-hover:text-neon-orange"
                  )}>
                    {item.icon}
                  </span>
                  <span className="font-bold text-sm tracking-wide">{item.label}</span>
                </button>
              ))}
            </div>
          </div>
        ))}
      </nav>

      <div className="mt-auto pt-8 border-t border-white/5 space-y-6">
        <div className="p-5 rounded-3xl bg-surface-light border border-white/5 relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
              <span className="text-[10px] font-black text-white/20 uppercase tracking-widest">Plan</span>
              {profile?.isPro ? (
                <span className="text-[10px] font-black text-neon-orange px-2 py-0.5 rounded-full uppercase tracking-widest bg-neon-orange/10">Pro</span>
              ) : (
                <span className="text-[10px] font-black text-white/40 px-2 py-0.5 rounded-full uppercase tracking-widest bg-white/5">Free</span>
              )}
            </div>
            <p className="text-sm font-bold text-white mb-5">{profile?.displayName || 'User'}</p>
            <button 
              onClick={() => window.open(`/${profile?.username}`, '_blank')}
              className="w-full flex items-center justify-center gap-2 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-all text-[10px] font-black uppercase tracking-widest text-white/60 hover:text-white"
            >
              <ExternalLink size={12} /> View Profile
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between px-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full border border-white/10 p-0.5 relative">
              <img 
                src={profile?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile?.username}`} 
                className="w-full h-full rounded-full object-cover" 
                alt="" 
              />
              {profile?.badges?.includes('Staff') && (
                <div className="absolute -top-1 -right-1 bg-neon-orange text-black p-0.5 rounded-full shadow-lg">
                  <ShieldCheck size={10} />
                </div>
              )}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white truncate">@{profile?.username || 'username'}</p>
              <p className="text-[10px] text-white/30 truncate">Logout</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="p-2 text-white/20 hover:text-red-500 transition-colors"
          >
            <LogOut size={18} />
          </button>
        </div>
      </div>
    </aside>
  );
}
