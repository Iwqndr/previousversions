import { useState, useEffect } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'motion/react';
import { LogIn, UserPlus, Menu, X, Sparkles, Zap, ShieldCheck } from 'lucide-react';
import { NeonButton } from '../ui/NeonButton';
import { cn } from '../../lib/utils';

interface LandingHeaderProps {
  onSetView: (view: 'landing' | 'auth' | 'dashboard' | 'profile-showcase') => void;
  onSetActiveTab: (tab: string) => void;
}

export function LandingHeader({ onSetView, onSetActiveTab }: LandingHeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { scrollY } = useScroll();

  // Header background opacity and blur based on scroll
  const headerBg = useTransform(
    scrollY,
    [0, 50],
    ['rgba(13, 13, 13, 0)', 'rgba(13, 13, 13, 0.8)']
  );
  const headerBlur = useTransform(
    scrollY,
    [0, 50],
    ['blur(0px)', 'blur(12px)']
  );
  const headerBorder = useTransform(
    scrollY,
    [0, 50],
    ['rgba(255, 255, 255, 0)', 'rgba(255, 255, 255, 0.1)']
  );

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Features', href: '#features' },
    { name: 'Leaderboard', action: () => { onSetView('dashboard'); onSetActiveTab('leaderboard'); } },
    { name: 'Pricing', href: '#pricing' },
    { name: 'Community', action: () => { onSetView('dashboard'); onSetActiveTab('community'); } },
  ];

  return (
    <motion.nav
      style={{
        backgroundColor: headerBg,
        backdropFilter: headerBlur,
        borderBottomColor: headerBorder,
      }}
      className={cn(
        "fixed top-0 left-0 right-0 z-50 px-6 py-4 transition-all duration-500 border-b",
        isScrolled ? "py-3" : "py-6"
      )}
    >
      <div className="container mx-auto flex items-center justify-between">
        {/* Logo */}
        <motion.div 
          className="flex items-center gap-3 cursor-pointer group"
          onClick={() => onSetView('landing')}
          whileHover={{ scale: 1.02 }}
        >
          <div className="relative">
            <motion.div 
              className="w-10 h-10 rounded-xl bg-neon-orange flex items-center justify-center neon-glow relative z-10"
              animate={{
                boxShadow: ["0 0 10px rgba(255,136,0,0.3)", "0 0 25px rgba(255,136,0,0.6)", "0 0 10px rgba(255,136,0,0.3)"]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Zap size={20} className="text-black fill-black" />
            </motion.div>
            {/* Reflection/Glow effect */}
            <div className="absolute -inset-2 bg-neon-orange/20 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          </div>
          <div className="flex flex-col -space-y-1">
            <span className="text-2xl font-black tracking-tighter bg-gradient-to-br from-white to-white/50 bg-clip-text text-transparent">
              precent<span className="text-neon-orange">.lol</span>
            </span>
            <span className="text-[8px] font-black text-white/30 uppercase tracking-[0.3em] ml-1">Next-Gen Bio</span>
          </div>
        </motion.div>
        
        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-1 bg-white/5 border border-white/10 rounded-full px-2 py-1 backdrop-blur-md">
          {navItems.map((item) => (
            <NavItem key={item.name} item={item} />
          ))}
        </div>

        {/* Desktop CTAs */}
        <div className="hidden lg:flex items-center gap-4">
          <motion.button 
            onClick={() => onSetView('auth')}
            className="text-sm font-bold text-white/60 hover:text-white transition-all flex items-center gap-2 px-4 py-2 rounded-full hover:bg-white/5 group"
            whileHover={{ x: -2 }}
          >
            <LogIn size={18} className="group-hover:text-neon-orange transition-colors" />
            <span>Login</span>
          </motion.button>
          
          <NeonButton 
            size="md" 
            onClick={() => onSetView('auth')}
            className="relative group overflow-hidden"
          >
            <UserPlus size={18} /> 
            <span>Create Your Page</span>
            {/* Inner light sweep */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
          </NeonButton>
        </div>

        {/* Mobile Menu Toggle */}
        <button 
          className="lg:hidden p-2 text-white/60 hover:text-white transition-colors"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden absolute top-full left-0 right-0 bg-[#0d0d0d]/95 backdrop-blur-xl border-b border-white/10 overflow-hidden"
          >
            <div className="container mx-auto px-6 py-8 flex flex-col gap-6">
              {navItems.map((item) => (
                <button
                  key={item.name}
                  onClick={() => {
                    if (item.action) item.action();
                    setIsMobileMenuOpen(false);
                  }}
                  className="text-2xl font-black text-left hover:text-neon-orange transition-colors flex items-center justify-between group"
                >
                  {item.name}
                  <Sparkles size={20} className="opacity-0 group-hover:opacity-100 transition-opacity text-neon-orange" />
                </button>
              ))}
              <hr className="border-white/10" />
              <div className="flex flex-col gap-4">
                <NeonButton size="lg" onClick={() => onSetView('auth')} className="w-full">
                  Sign Up Free
                </NeonButton>
                <button 
                  onClick={() => onSetView('auth')}
                  className="w-full py-4 rounded-2xl border border-white/10 font-bold hover:bg-white/5 transition-colors"
                >
                  Login to Dashboard
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}

function NavItem({ item }: any) {
  const [isHovered, setIsHovered] = useState(false);

  const handleClick = () => {
    if (item.action) {
      item.action();
    } else if (item.href) {
      const element = document.querySelector(item.href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <motion.button
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onClick={handleClick}
      className="relative px-5 py-2 text-sm font-bold text-white/50 hover:text-white transition-colors group"
    >
      <span className="relative z-10">{item.name}</span>
      
      {/* Animated Underline/Trail */}
      {isHovered && (
        <motion.div
          layoutId="nav-glow"
          className="absolute inset-0 bg-neon-orange/10 rounded-full z-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        />
      )}
      
      {/* Bottom line */}
      <motion.div 
        className="absolute bottom-1 left-1/2 -translate-x-1/2 h-[2px] bg-neon-orange rounded-full shadow-[0_0_8px_#ff8800]"
        initial={{ width: 0 }}
        animate={{ width: isHovered ? '40%' : 0 }}
        transition={{ duration: 0.3 }}
      />
      
      {/* Light sweep effect on hover */}
      <div className="absolute inset-0 overflow-hidden rounded-full pointer-events-none">
        <div className={cn(
          "absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full transition-transform duration-500",
          isHovered && "translate-x-full"
        )} />
      </div>
    </motion.button>
  );
}
