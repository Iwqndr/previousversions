import React, { createContext, useContext, useEffect, useState } from 'react';
import { initSupabase, getSupabase } from '../lib/supabase';
import { api } from '../lib/api';
import { UserProfile } from '../types';
import { localStorageService } from '../services/localStorageService';
import { profileService } from '../services/profileService';
import { isAdmin } from '../constants/admin';
import { User } from '@supabase/supabase-js';

interface SupabaseContextType {
  user: User | null;
  profile: UserProfile | null;
  setProfile: React.Dispatch<React.SetStateAction<UserProfile | null>>;
  loading: boolean;
  isAuthReady: boolean;
  isOnline: boolean;
  isDemoMode: boolean;
  refreshProfile: () => Promise<void>;
}

const SupabaseContext = createContext<SupabaseContextType>({
  user: null,
  profile: null,
  setProfile: () => {},
  loading: true,
  isAuthReady: false,
  isOnline: true,
  isDemoMode: false,
  refreshProfile: async () => {},
});

export function SupabaseProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const [isDemoMode, setIsDemoMode] = useState(false);

  const refreshProfile = async () => {
    if (isDemoMode) {
      const localProfile = localStorageService.getProfile();
      if (localProfile) setProfile(localProfile);
    } else if (user) {
      try {
        const data = await api.getProfileByUid(user.id);
        if (data) setProfile(data as UserProfile);
      } catch (e) { console.error('Failed to refresh profile:', e); }
    }
  };

  useEffect(() => {
    let cancelled = false;
    const timeout = setTimeout(() => {
      if (!cancelled) {
        console.warn('Supabase init timeout');
        setIsOnline(false);
        setIsAuthReady(true);
        setLoading(false);
      }
    }, 8000);

    const init = async () => {
      try {
        await initSupabase();
      } catch (e) {
        console.error('Failed to init Supabase:', e);
        if (!cancelled) {
          setIsOnline(false);
          setIsAuthReady(true);
          setLoading(false);
          clearTimeout(timeout);
        }
        return;
      }

      const sb = getSupabase();
      const demoFlag = localStorage.getItem('demo_mode');
      const localProfile = localStorageService.getProfile();
      if (demoFlag === 'true' && localProfile) {
        if (!cancelled) {
          setUser({ id: localProfile.uid, email: localProfile.email } as any);
          setProfile(localProfile);
          setIsDemoMode(true);
          setIsAuthReady(true);
          setLoading(false);
        }
        clearTimeout(timeout);
        return;
      }

      try {
        const { data: { session } } = await sb.auth.getSession();
        if (!cancelled) {
          setIsOnline(true);
          if (session?.user) setUser(session.user);
          setIsAuthReady(true);
          setLoading(false);
        }
      } catch {
        if (!cancelled) {
          setIsOnline(false);
          setIsAuthReady(true);
          setLoading(false);
        }
      }
      clearTimeout(timeout);
    };

    init();
    return () => { cancelled = true; clearTimeout(timeout); };
  }, []);

  useEffect(() => {
    if (isDemoMode || !isAuthReady) return;
    const sb = getSupabase();
    if (!sb) return;
    const { data: { subscription } } = sb.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (!session?.user) {
        localStorage.removeItem('demo_mode');
        setProfile(null);
        setUser(null);
        setLoading(false);
      }
    });
    return () => subscription.unsubscribe();
  }, [isDemoMode, isAuthReady]);

  useEffect(() => {
    if (!user || !isAuthReady || isDemoMode) {
      if (isAuthReady && !user) setLoading(false);
      return;
    }

    let cancelled = false;
    const timeout = setTimeout(() => {
      if (!cancelled) {
        console.warn('Profile fetch timeout');
        setLoading(false);
      }
    }, 5000);

    const fetchProfile = async () => {
      try {
        const data = await api.getProfileByUid(user.id);
        if (cancelled) return;

        if (data) {
          let userProfile = data as UserProfile;
          if (!userProfile.username && user.email) userProfile.username = user.email.split('@')[0];
          if (isAdmin(user.email)) {
            if (!userProfile.badges.includes('Staff')) userProfile.badges = ['Staff', ...userProfile.badges];
            userProfile.role = 'admin';
          }
          if (userProfile.issuspended) {
            const sb = getSupabase();
            await sb.auth.signOut();
            setProfile(null);
            setUser(null);
            alert('Your account has been suspended.');
            return;
          }
          setProfile(userProfile);
        } else {
          const emailPrefix = user.email?.split('@')[0] || `user_${user.id.slice(0, 8)}`;
          const displayName = user.user_metadata?.full_name || emailPrefix || 'User';
          const avatarUrl = user.user_metadata?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.id}`;
          try {
            await profileService.createProfile(user.id, { email: user.email || '', username: emailPrefix, displayName, avatarUrl });
            const newData = await api.getProfileByUid(user.id);
            if (newData && !cancelled) {
              setProfile(profileService.normalizeProfile(newData));
            }
          } catch {
            const localProfile: UserProfile = {
              uid: user.id, username: emailPrefix, displayName, email: user.email, avatarUrl,
              bio: 'Welcome to my profile!', location: '', links: [],
              appearance: { backgroundType: 'gradient', backgroundColor: '#050505', accentColor: '#ff8800', fontFamily: 'inter', glassmorphism: true, buttonStyle: 'rounded', cardStyle: 'glass', theme: 'dark', avatarShape: 'circle', layout: 'center', cursorTrail: 'none', pageTransition: 'fade', crtEffect: false, glitchEffect: false, bloomIntensity: 50, borderWeight: 1, fontWeight: 'normal', textTransform: 'none' },
              analytics: { views: 0, clicks: 0, history: [] },
              badges: isAdmin(user.email) ? ['Staff', 'Early Access', 'OG'] : ['Early Access', 'OG'],
              likes: 0, createdat: Date.now(), role: isAdmin(user.email) ? 'admin' : 'user',
            };
            localStorageService.saveProfile(localProfile);
            setProfile(localProfile);
            setIsDemoMode(true);
          }
        }
      } catch (err) {
        console.error('Error fetching profile:', err);
        if (!cancelled) setProfile(null);
      } finally {
        clearTimeout(timeout);
        if (!cancelled) setLoading(false);
      }
    };

    fetchProfile();
    return () => { cancelled = true; clearTimeout(timeout); };
  }, [user, isAuthReady, isDemoMode]);

  return (
    <SupabaseContext.Provider value={{ user, profile, setProfile, loading, isAuthReady, isOnline, isDemoMode, refreshProfile }}>
      {children}
    </SupabaseContext.Provider>
  );
}

export const useSupabase = () => useContext(SupabaseContext);
