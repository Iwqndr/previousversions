import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { Trophy, TrendingUp, TrendingDown, Minus, Eye, Heart, ShieldCheck, Sparkles, Zap } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { profileService } from '@/src/services/profileService';
import { LeaderboardEntry } from '@/src/types';

function renderBadgeIcon(type: string) {
  switch (type) {
    case 'Staff': return <ShieldCheck size={14} className="text-neon-orange" />;
    case 'Early Adopter': return <ShieldCheck size={14} className="text-neon-orange" />;
    case 'Verified': return <BadgeCheck size={14} className="text-neon-orange" />;
    case 'Pro': return <Sparkles size={14} className="text-purple-500" />;
    default: return null;
  }
}

export function Leaderboard() {
  const [data, setData] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      const entries = await profileService.getLeaderboard();
      setData(entries as any);
      setLoading(false);
    };
    fetchLeaderboard();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-neon-orange border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const topThree = data.slice(0, 3);
  const others = data.slice(3);

  return (
    <div className="space-y-12 max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500 relative">
      <div className="absolute top-0 right-0 hidden lg:block">
        <h2 className="text-[10px] font-black text-white/10 tracking-[0.4em] uppercase">Leaderboard</h2>
      </div>

      <div className="text-center mb-12">
        <h2 className="text-4xl md:text-5xl font-black mb-4">
          Global <span className="text-neon-orange">Leaderboard</span>
        </h2>
        <p className="text-white/60 max-w-2xl mx-auto mb-6">
          The most influential creators on the network.
        </p>
        <div className="flex justify-center">
          <div className="flex gap-2 p-1 glass rounded-xl border-white/10">
            {['Views', 'Likes'].map((range) => (
              <button
                key={range}
                className={cn(
                  "px-6 py-2 rounded-lg text-xs font-black transition-all duration-300 uppercase tracking-widest",
                  range === 'Views' ? "bg-neon-orange text-black shadow-[0_0_20px_rgba(255,136,0,0.3)]" : "text-white/50 hover:text-white hover:bg-white/5"
                )}
              >
                {range}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Podium Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-end pt-10">
        {/* Rank 2 */}
        {topThree[1] && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="order-2 md:order-1"
          >
            <GlassCard className="p-6 text-center relative border-gray-400/30 group hover:border-gray-400/50 transition-all">
              <div className="relative mb-4">
                <div className="w-20 h-20 rounded-full border-4 border-gray-400 p-1 bg-base relative mx-auto">
                  <img src={topThree[1].avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${topThree[1].username}`} className="w-full h-full rounded-full object-cover" alt="" />
                  <div className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full bg-gray-400 text-black flex items-center justify-center font-black text-xs">2</div>
                </div>
              </div>
              <div>
                <h3 className="font-black text-lg truncate flex items-center justify-center gap-1">
                  {topThree[1].displayName}
                  {topThree[1].badges?.map((badge) => (
                    <span key={badge}>{renderBadgeIcon(badge)}</span>
                  ))}
                  {topThree[1].isPro && <Sparkles size={14} className="text-purple-500" />}
                </h3>
                <p className="text-xs text-white/40 mb-4">@{topThree[1].username}</p>
                <div className="flex justify-center gap-4">
                  <div className="text-center">
                    <p className="text-xs font-black text-neon-orange">{topThree[1].views.toLocaleString()}</p>
                    <p className="text-[8px] text-white/30 uppercase font-bold">Views</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs font-black text-neon-orange">{topThree[1].likes.toLocaleString()}</p>
                    <p className="text-[8px] text-white/30 uppercase font-bold">Likes</p>
                  </div>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        )}

        {/* Rank 1 */}
        {topThree[0] && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
            className="order-1 md:order-2"
          >
            <GlassCard className="p-8 text-center relative border-neon-orange/50 shadow-[0_0_50px_rgba(255,136,0,0.1)] group hover:border-neon-orange transition-all scale-105 z-10">
              <div className="relative mb-4">
                <div className="w-28 h-28 rounded-full border-4 border-neon-orange p-1 bg-base relative mx-auto neon-glow-orange">
                  <img src={topThree[0].avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${topThree[0].username}`} className="w-full h-full rounded-full object-cover" alt="" />
                  <div className="absolute -bottom-2 -right-2 w-10 h-10 rounded-full bg-neon-orange text-black flex items-center justify-center font-black text-sm shadow-xl">1</div>
                  <Trophy className="absolute -top-6 -right-6 text-yellow-500 animate-bounce" size={32} />
                </div>
              </div>
              <div>
                <h3 className="font-black text-2xl truncate flex items-center justify-center gap-2">
                  {topThree[0].displayName}
                  {topThree[0].badges?.map((badge) => (
                    <span key={badge}>{renderBadgeIcon(badge)}</span>
                  ))}
                  {topThree[0].isPro && <Sparkles size={18} className="text-purple-500" />}
                </h3>
                <p className="text-sm text-white/40 mb-6">@{topThree[0].username}</p>
                <div className="flex justify-center gap-8">
                  <div className="text-center">
                    <p className="text-xl font-black text-neon-orange">{topThree[0].views.toLocaleString()}</p>
                    <p className="text-[10px] text-white/30 uppercase font-bold tracking-widest">Views</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xl font-black text-neon-orange">{topThree[0].likes.toLocaleString()}</p>
                    <p className="text-[10px] text-white/30 uppercase font-bold tracking-widest">Likes</p>
                  </div>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        )}

        {/* Rank 3 */}
        {topThree[2] && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="order-3"
          >
            <GlassCard className="p-6 text-center relative border-amber-600/30 group hover:border-amber-600/50 transition-all">
              <div className="relative mb-4">
                <div className="w-20 h-20 rounded-full border-4 border-amber-600 p-1 bg-base relative mx-auto">
                  <img src={topThree[2].avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${topThree[2].username}`} className="w-full h-full rounded-full object-cover" alt="" />
                  <div className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full bg-amber-600 text-black flex items-center justify-center font-black text-xs">3</div>
                </div>
              </div>
              <div>
                <h3 className="font-black text-lg truncate flex items-center justify-center gap-1">
                  {topThree[2].displayName}
                  {topThree[2].badges?.map((badge) => (
                    <span key={badge}>{renderBadgeIcon(badge)}</span>
                  ))}
                  {topThree[2].isPro && <Sparkles size={14} className="text-purple-500" />}
                </h3>
                <p className="text-xs text-white/40 mb-4">@{topThree[2].username}</p>
                <div className="flex justify-center gap-4">
                  <div className="text-center">
                    <p className="text-xs font-black text-neon-orange">{topThree[2].views.toLocaleString()}</p>
                    <p className="text-[8px] text-white/30 uppercase font-bold">Views</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs font-black text-neon-orange">{topThree[2].likes.toLocaleString()}</p>
                    <p className="text-[8px] text-white/30 uppercase font-bold">Likes</p>
                  </div>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        )}
      </div>
      
      <div className="space-y-3 pt-10">
        {others.map((user, index) => (
          <motion.div
            key={user.uid}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <GlassCard className="p-4 flex items-center gap-6 hover:border-neon-orange/30 group transition-all duration-300">
              <div className="w-10 text-center">
                <span className="text-xl font-black text-white/10 group-hover:text-neon-orange/40 transition-colors">
                  #{user.rank}
                </span>
              </div>

              <div className="w-12 h-12 rounded-full border-2 border-white/10 p-0.5 group-hover:border-neon-orange/50 transition-all duration-300 shrink-0">
                <img 
                  src={user.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.username}`} 
                  alt={user.username}
                  className="w-full h-full rounded-full object-cover bg-white/5"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold truncate group-hover:text-neon-orange transition-colors">{user.displayName}</h3>
                  <div className="flex gap-1">
                    {user.badges?.map((badge) => (
                      <div key={badge}>{renderBadgeIcon(badge)}</div>
                    ))}
                    {user.isPro && <Sparkles size={14} className="text-purple-500" />}
                    {index < 2 && (
                      <div className="px-1.5 py-0.5 rounded bg-neon-orange/10 text-neon-orange text-[8px] font-black uppercase flex items-center gap-1 animate-pulse">
                        <TrendingUp size={8} /> Trending
                      </div>
                    )}
                  </div>
                </div>
                <p className="text-xs text-white/40 truncate">@{user.username}</p>
              </div>

              <div className="text-right flex items-center gap-8">
                <div className="hidden sm:flex flex-col items-end">
                  <div className="flex items-center gap-1.5 text-neon-orange font-black text-sm">
                    <Eye size={14} />
                    <span>{user.views.toLocaleString()}</span>
                  </div>
                  <p className="text-[8px] text-white/30 uppercase tracking-widest font-bold">Views</p>
                </div>

                <div className="flex flex-col items-end">
                  <div className="flex items-center gap-1.5 text-neon-orange font-black text-sm">
                    <Heart size={14} />
                    <span>{user.likes.toLocaleString()}</span>
                  </div>
                  <p className="text-[8px] text-white/30 uppercase tracking-widest font-bold">Likes</p>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
