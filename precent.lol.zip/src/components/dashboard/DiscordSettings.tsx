import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { NeonButton } from '../ui/NeonButton';
import { MessageSquare, Save, CheckCircle2, AlertCircle, ExternalLink, ShieldCheck, Zap, User, Hash, Crown } from 'lucide-react';
import { useSupabase } from '../SupabaseProvider';
import { profileService } from '@/src/services/profileService';
import { cn } from '@/src/lib/utils';

export function DiscordSettings() {
  const { profile, setProfile, refreshProfile } = useSupabase();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    status: '',
    active: false,
  });

  useEffect(() => {
    if (profile?.discord) {
      setFormData({
        username: profile.discord.username || '',
        status: profile.discord.status || '',
        active: profile.discord.active || false,
      });
    }
  }, [profile]);

  const updateGlobalProfile = (newDiscord: any) => {
    if (profile) {
      setProfile(prev => prev ? {
        ...prev,
        preview: {
          ...prev.preview,
          discord: newDiscord
        }
      } : null);
    }
  };

  const handleChange = (field: string, value: any) => {
    const newFormData = { ...formData, [field]: value };
    setFormData(newFormData);
    updateGlobalProfile(newFormData);
  };

  const handleSave = async () => {
    if (!profile) return;
    setLoading(true);
    try {
      await profileService.updateProfile(profile.uid, { 
        discord: formData 
      });
      await refreshProfile();
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
      
      // Clear preview
      if (profile) {
        setProfile(prev => prev ? {
          ...prev,
          preview: {
            ...prev.preview,
            discord: undefined
          }
        } : null);
      }
    } catch (err) {
      console.error('Failed to update discord settings:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-12 max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700 relative">
      {/* Background Accents */}
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-[#5865F2]/5 blur-[120px] rounded-full pointer-events-none" />
      
      <div className="text-center space-y-4 relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[#5865F2] text-[10px] font-black uppercase tracking-[0.2em] backdrop-blur-md">
          <MessageSquare size={12} className="fill-[#5865F2]" />
          <span>Discord Presence</span>
        </div>
        <h2 className="text-5xl md:text-7xl font-black tracking-tighter leading-[0.9]">
          Discord <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#5865F2] via-white to-[#5865F2] bg-[length:200%_auto] animate-gradient-x">Integration</span>
        </h2>
        <p className="text-white/40 max-w-2xl mx-auto font-medium">
          Sync your Discord presence to your profile. Showcase your status and make it easier for your community to connect.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <GlassCard className="p-8 border-white/10">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-[#5865F2]/10 flex items-center justify-center text-[#5865F2]">
                  <MessageSquare size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Connection Settings</h3>
                  <p className="text-xs text-white/40">Configure how your Discord appears.</p>
                </div>
              </div>
              <a 
                href="/api/auth/discord"
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all",
                  formData.active ? "bg-neon-orange/10 text-neon-orange" : "bg-[#5865F2] text-white hover:bg-[#4752C4]"
                )}
              >
                {formData.active ? 'Connected' : 'Connect Discord'}
              </a>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-white/40 uppercase tracking-widest flex items-center gap-2">
                    <Hash size={12} /> Discord Username
                  </label>
                  <input 
                    type="text" 
                    value={formData.username}
                    onChange={(e) => handleChange('username', e.target.value)}
                    placeholder="username#0000"
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 transition-all text-sm"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-white/40 uppercase tracking-widest flex items-center gap-2">
                    <Zap size={12} /> Custom Status
                  </label>
                  <input
                    type="text"
                    value={formData.status}
                    onChange={(e) => handleChange('status', e.target.value)}
                    placeholder="e.g. Playing Valorant"
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 transition-all text-sm"
                  />
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-white/10">
              <NeonButton
                onClick={handleSave}
                disabled={loading}
                className={cn(success && "bg-neon-orange border-neon-orange text-black")}
              >
                {loading ? 'Saving...' : success ? (
                  <>
                    <CheckCircle2 size={16} />
                    Saved!
                  </>
                ) : (
                  <>
                    <Save size={16} />
                    Save Changes
                  </>
                )}
              </NeonButton>
            </div>
          </GlassCard>

          <div className="p-6 rounded-3xl bg-[#5865F2]/5 border border-[#5865F2]/20 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-[#5865F2]/20 flex items-center justify-center text-[#5865F2]">
                <ExternalLink size={20} />
              </div>
              <div>
                <h4 className="font-bold text-sm">Join our Discord</h4>
                <p className="text-[10px] text-white/50 uppercase tracking-widest">Support & Community</p>
              </div>
            </div>
            <a 
              href="https://discord.gg/tMcqK56rgQ" 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-[#5865F2] text-white font-bold text-xs hover:bg-[#4752C4] transition-colors"
            >
              Join Server
            </a>
          </div>
        </div>

        <div className="space-y-6">
          <h4 className="text-[10px] font-black text-white/40 uppercase tracking-widest">Live Preview</h4>
          <GlassCard className="p-6 border-white/5 bg-black/40">
            <div className="relative">
              <div className="h-20 bg-gradient-to-r from-[#5865F2] to-[#7289DA] rounded-t-2xl" />
              <div className="px-4 pb-4">
                <div className="w-16 h-16 rounded-full border-[6px] border-[#18191C] bg-[#18191C] -mt-8 mb-2 overflow-hidden relative">
                  <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${profile?.username || 'Guest'}`} alt="Avatar" className="w-full h-full" />
                  <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 border-2 border-[#18191C] rounded-full" />
                </div>
                <h4 className="font-bold text-white text-lg">{formData.username || 'Discord User'}</h4>
                <p className="text-xs text-white/60 mb-4">{formData.status || 'Playing something...'}</p>
                <div className="h-px bg-white/10 mb-4" />
                <div className="flex items-center gap-2 text-[10px] font-bold text-white/40 uppercase">
                  <ShieldCheck size={12} className="text-neon-orange" />
                  Verified Member
                </div>
              </div>
            </div>
          </GlassCard>

          <div className="p-6 rounded-3xl bg-amber-500/5 border border-amber-500/20 flex gap-4">
            <AlertCircle className="text-amber-500 shrink-0" size={20} />
            <div>
              <h4 className="text-amber-500 font-bold text-xs mb-1">Privacy Note</h4>
              <p className="text-white/40 text-[10px] leading-relaxed">
                Your Discord username and status will be visible to everyone visiting your profile.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
