import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { NeonButton } from '../ui/NeonButton';
import { Palette, Type, Layout, Sparkles, Save, CheckCircle2, Monitor, MousePointer2, Box, Moon, Sun, Zap, Terminal, Crown, Lock, Image as ImageIcon, Video, Grid, AlignLeft, AlignCenter, AlignRight, Circle, Square, Hexagon, Layers, Plus, Search } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { useSupabase } from '../SupabaseProvider';
import { profileService } from '@/src/services/profileService';
import { themes as themeConfigs } from '@/src/constants/themes';
import { useGoogleFont } from '@/src/hooks/useGoogleFonts';
import { setPreviewAppearance } from '@/src/utils/appearancePreview';

const backgroundTypes = [
  { id: 'solid', label: 'Solid Color', icon: <Palette size={18} />, pro: false },
  { id: 'gradient', label: 'Gradient', icon: <Sparkles size={18} />, pro: false },
  { id: 'pattern', label: 'Pattern', icon: <Grid size={18} />, pro: false },
  { id: 'animated', label: 'Animated', icon: <Layout size={18} />, pro: true },
  { id: 'image', label: 'Image', icon: <ImageIcon size={18} />, pro: true },
  { id: 'video', label: 'Video', icon: <Video size={18} />, pro: true },
  { id: 'mesh', label: 'Mesh Gradient', icon: <Grid size={18} />, pro: true },
  { id: 'matrix', label: 'Digital Rain', icon: <Terminal size={18} />, pro: true },
  { id: 'particles', label: 'Particles', icon: <Sparkles size={18} />, pro: true },
];

const fonts = [
  { id: 'inter', label: 'Inter', class: 'font-sans', pro: false },
  { id: 'mono', label: 'JetBrains Mono', class: 'font-mono', pro: false },
  { id: 'outfit', label: 'Outfit', class: 'font-sans font-bold', pro: false },
  { id: 'space', label: 'Space Grotesk', class: 'font-sans tracking-tight', pro: false },
  { id: 'roboto', label: 'Roboto', class: 'font-sans', pro: false },
  { id: 'lato', label: 'Lato', class: 'font-sans', pro: false },
  { id: 'playfair', label: 'Playfair Display', class: 'font-serif', pro: true },
  { id: 'rubik', label: 'Rubik', class: 'font-sans', pro: true },
  { id: 'syne', label: 'Syne', class: 'font-sans font-extrabold', pro: true },
  { id: 'bricolage', label: 'Bricolage Grotesque', class: 'font-sans', pro: true },
  { id: 'clash', label: 'Clash Display', class: 'font-sans uppercase', pro: true },
  { id: 'chillax', label: 'Chillax', class: 'font-sans', pro: true },
];

const buttonStyles = [
  { id: 'rounded', label: 'Rounded', radius: 'rounded-xl', pro: false },
  { id: 'sharp', label: 'Sharp', radius: 'rounded-none', pro: false },
  { id: 'pill', label: 'Pill', radius: 'rounded-full', pro: false },
  { id: 'glass', label: 'Glass', radius: 'rounded-xl glass', pro: false },
  { id: 'outline', label: 'Outline', radius: 'rounded-xl border-2 border-white/20 bg-transparent hover:bg-white/5', pro: false },
  { id: 'neon', label: 'Neon Glow', radius: 'rounded-xl neon-glow', pro: true },
  { id: 'cyber', label: 'Cyberpunk', radius: 'rounded-none border-2 border-neon-orange', pro: true },
  { id: 'minimal', label: 'Minimal', radius: 'rounded-md border border-white/20', pro: true },
  { id: '3d', label: '3D Pop', radius: 'rounded-xl shadow-[0_4px_0_rgba(255,136,0,1)]', pro: true },
];

const cardStyles = [
  { id: 'flat', label: 'Flat', class: 'bg-white/5 border-white/10', pro: false },
  { id: 'elevated', label: 'Elevated', class: 'bg-white/10 border-white/20 shadow-xl', pro: false },
  { id: 'glass', label: 'Glass', class: 'glass border-white/10', pro: false },
  { id: 'bordered', label: 'Bordered', class: 'bg-transparent border-2 border-white/20', pro: false },
  { id: 'neon', label: 'Neon', class: 'bg-black/40 border-neon-orange/30 neon-glow', pro: true },
  { id: 'wireframe', label: 'Wireframe', class: 'bg-transparent border-2 border-dashed border-white/30', pro: true },
  { id: 'holographic', label: 'Holographic', class: 'bg-gradient-to-br from-white/10 to-white/5 border-white/20 backdrop-blur-xl', pro: true },
  { id: 'brutalist', label: 'Brutalist', class: 'bg-black border-4 border-white shadow-[8px_8px_0_white]', pro: true },
  { id: 'frosted', label: 'Frosted', class: 'bg-white/5 backdrop-blur-3xl border-white/10', pro: true },
];

const themes = themeConfigs.map(t => ({
  id: t.id,
  label: t.name,
  icon: t.id === 'dark' ? <Moon size={18} /> : 
        t.id === 'light' ? <Sun size={18} /> : 
        t.id === 'cyber' ? <Terminal size={18} /> : 
        t.id === 'neon' ? <Zap size={18} /> : 
        t.id === 'minimal' ? <Box size={18} /> : 
        t.id === 'hacker' ? <Terminal size={18} /> : 
        t.id === 'vaporwave' ? <Palette size={18} /> : 
        <Circle size={18} />,
  pro: ['cyber', 'neon', 'hacker', 'vaporwave', 'monochrome'].includes(t.id)
}));

const avatarShapes = [
  { id: 'circle', label: 'Circle', icon: <Circle size={18} />, pro: false },
  { id: 'square', label: 'Square', icon: <Square size={18} />, pro: false },
  { id: 'rounded', label: 'Rounded', icon: <Box size={18} />, pro: false },
  { id: 'squircle', label: 'Squircle', icon: <Box size={18} />, pro: false },
  { id: 'hexagon', label: 'Hexagon', icon: <Hexagon size={18} />, pro: true },
];

const layouts = [
  { id: 'center', label: 'Centered', icon: <AlignCenter size={18} />, pro: false },
  { id: 'compact', label: 'Compact', icon: <AlignCenter size={18} />, pro: false },
  { id: 'left', label: 'Left Aligned', icon: <AlignLeft size={18} />, pro: true },
  { id: 'right', label: 'Right Aligned', icon: <AlignRight size={18} />, pro: true },
  { id: 'split', label: 'Split Screen', icon: <Layout size={18} />, pro: true },
];

export function AppearanceSettings() {
  const { profile, setProfile, refreshProfile } = useSupabase();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState('background');
  const isInitialized = useRef(false);
  const [customFont, setCustomFont] = useState('');
  const [showCustomFontInput, setShowCustomFontInput] = useState(false);

  const [appearance, setAppearance] = useState({
    backgroundType: 'gradient' as any,
    backgroundColor: '#050505',
    accentColor: '#ff8800',
    fontFamily: 'inter',
    glassmorphism: true,
    buttonStyle: 'rounded' as any,
    cardStyle: 'glass' as any,
    theme: 'dark' as any,
    avatarShape: 'circle' as any,
    layout: 'center' as any,
    cursorTrail: 'none' as any,
    pageTransition: 'fade' as any,
    crtEffect: false,
    glitchEffect: false,
    bloomIntensity: 50,
    borderWeight: 1,
    fontWeight: 'normal',
    textTransform: 'none',
  });

  // Load the selected font from Google Fonts
  useGoogleFont(appearance.fontFamily);

  useEffect(() => {
    if (profile && !isInitialized.current) {
      setAppearance({
        ...appearance,
        ...profile.appearance
      });
      isInitialized.current = true;
    }
  }, [profile]);

  const updateGlobalProfile = (newAppearance: any) => {
    // Only update the LivePreview (no React context re-render)
    setPreviewAppearance(newAppearance);
  };

  const handleSave = async () => {
    if (!profile) return;
    setLoading(true);
    try {
      await profileService.updateProfile(profile.uid, { appearance });
      await refreshProfile();
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to update appearance:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectOption = (key: string, value: any, isProFeature: boolean) => {
    if (isProFeature && !profile?.isPro) {
      window.dispatchEvent(new CustomEvent('open-pro-modal'));
      return;
    }
    
    const newAppearance = { ...appearance, [key]: value };
    
    // If selecting a theme, also update accent color to match the theme's default neon
    if (key === 'theme') {
      const themeConfig = themeConfigs.find(t => t.id === value);
      if (themeConfig) {
        newAppearance.accentColor = themeConfig.colors.neon;
      }
    }
    
    setAppearance(newAppearance);
    updateGlobalProfile(newAppearance);
  };

  const subTabs = [
    { id: 'background', label: 'Background', icon: <Layout size={18} /> },
    { id: 'typography', label: 'Typography', icon: <Type size={18} /> },
    { id: 'components', label: 'Components', icon: <Box size={18} /> },
    { id: 'layout', label: 'Layout & Profile', icon: <Layers size={18} /> },
    { id: 'effects', label: 'Effects', icon: <Sparkles size={18} /> },
    { id: 'themes', label: 'Themes', icon: <Monitor size={18} /> },
  ];

  return (
    <div className="space-y-12 max-w-6xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700 relative">
      {/* Background Accents */}
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-neon-orange/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-0 -right-24 w-96 h-96 bg-cyan/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="text-center space-y-4 relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-neon-orange text-[10px] font-black uppercase tracking-[0.2em] backdrop-blur-md">
          <Palette size={12} className="fill-neon-orange" />
          <span>Visual Theme Settings</span>
        </div>
        <h2 className="text-5xl md:text-7xl font-black tracking-tighter leading-[0.9]">
          Profile <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-orange via-white to-neon-orange bg-[length:200%_auto] animate-gradient-x">Aesthetics</span>
        </h2>
        <p className="text-white/40 max-w-2xl mx-auto font-medium">
          Personalize your profile's visual style to match your unique brand identity.
        </p>
        <div className="flex justify-center gap-6 pt-4">
          <button 
            onClick={() => {
              const randomColors = ['#ff8800', '#00e5ff', '#ff00aa', '#ffaa00', '#aa00ff'];
              const randomAccent = randomColors[Math.floor(Math.random() * randomColors.length)];
              const randomBg = ['solid', 'gradient'][Math.floor(Math.random() * 2)];
              const newAppearance = {
                ...appearance,
                accentColor: randomAccent,
                backgroundType: randomBg as any,
                glassmorphism: Math.random() > 0.5,
              };
              setAppearance(newAppearance);
              updateGlobalProfile(newAppearance);
            }}
            className="px-6 py-3 rounded-xl border border-white/10 bg-white/5 text-white/40 hover:bg-white/10 hover:text-white transition-all font-black text-[10px] uppercase tracking-widest flex items-center gap-3 group"
          >
            <Sparkles size={16} className="text-neon-orange group-hover:rotate-12 transition-transform" />
            AI Theme Generator
          </button>
          <NeonButton 
            size="sm" 
            onClick={handleSave} 
            disabled={loading}
            className={cn(
              "px-8 py-3 text-[10px] font-black tracking-[0.2em]",
              success && "bg-white border-white text-black shadow-[0_0_20px_rgba(255,255,255,0.3)]"
            )}
          >
            {loading ? 'SAVING...' : success ? 'SETTINGS SAVED' : 'APPLY CHANGES'}
          </NeonButton>
        </div>
      </div>
      
      <div className="flex flex-col lg:flex-row gap-8 min-h-[600px]">
        {/* Sub-navigation Sidebar */}
        <div className="w-full lg:w-64 shrink-0 space-y-2">
          {subTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id)}
              className={cn(
                "w-full flex items-center gap-3 p-4 rounded-2xl transition-all duration-300 group",
                activeSubTab === tab.id
                  ? "bg-neon-orange/10 text-neon-orange border border-neon-orange/20"
                  : "text-white/40 hover:text-white hover:bg-white/5 border border-transparent"
              )}
            >
              <span className={cn(
                "transition-colors",
                activeSubTab === tab.id ? "text-neon-orange" : "group-hover:text-neon-orange"
              )}>
                {tab.icon}
              </span>
              <span className="font-bold text-sm">{tab.label}</span>
              {activeSubTab === tab.id && (
                <motion.div layoutId="subtab-indicator" className="ml-auto w-1.5 h-1.5 rounded-full bg-neon-orange neon-glow" />
              )}
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSubTab}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2 }}
              className="space-y-8"
            >
              {activeSubTab === 'background' && (
                <GlassCard className="p-8">
                  <h3 className="text-xl font-bold mb-8 flex items-center gap-2">
                    <Layout size={20} className="text-neon-orange" /> Background Configuration
                  </h3>
                  
                  <div className="space-y-10">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {backgroundTypes.map((type) => (
                        <button
                          key={type.id}
                          onClick={() => handleSelectOption('backgroundType', type.id, type.pro)}
                          className={cn(
                            "flex flex-col items-center gap-3 p-4 rounded-2xl border transition-all duration-300 relative overflow-hidden",
                            appearance.backgroundType === type.id
                              ? "bg-neon-orange/10 border-neon-orange/30 text-neon-orange"
                              : "bg-white/5 border-white/10 text-white/50 hover:text-white hover:bg-white/10"
                          )}
                        >
                          {type.pro && (
                            <div className="absolute top-2 right-2">
                              <Lock size={12} className="text-white/30" />
                            </div>
                          )}
                          {type.icon}
                          <span className="text-[10px] font-black uppercase tracking-wider">{type.label}</span>
                        </button>
                      ))}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-4">
                        <label className="text-xs font-bold text-white/50 uppercase tracking-widest flex items-center gap-2">
                          <Palette size={14} /> Accent Color
                        </label>
                        <div className="flex flex-wrap gap-3">
                          {['#ff8800', '#00f2ff', '#ff00ff', '#ffff00', '#ff4400', '#7c3aed', '#ff0055', '#0055ff'].map((color) => (
                            <button
                              key={color}
                              onClick={() => {
                          const newAppearance = { ...appearance, accentColor: color };
                          setAppearance(newAppearance);
                          updateGlobalProfile(newAppearance);
                        }}
                              className={cn(
                                "w-10 h-10 rounded-full border-2 transition-all duration-300",
                                appearance.accentColor === color ? "border-white scale-110 shadow-[0_0_15px_rgba(255,255,255,0.3)]" : "border-transparent hover:scale-105"
                              )}
                              style={{ backgroundColor: color }}
                            />
                          ))}
                          <div className="relative group">
                            <input
                              type="color"
                              value={appearance.accentColor}
                              onChange={(e) => {
                                const newAppearance = { ...appearance, accentColor: e.target.value };
                                setAppearance(newAppearance);
                                updateGlobalProfile(newAppearance);
                              }}
                              className="w-10 h-10 rounded-full bg-transparent cursor-pointer border-none p-0 overflow-hidden"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="space-y-4">
                        <label className="text-xs font-bold text-white/50 uppercase tracking-widest flex items-center gap-2">
                          <Palette size={14} /> Background Color
                        </label>
                        <div className="flex items-center gap-4">
                          <input
                            type="color"
                            value={appearance.backgroundColor}
                            onChange={(e) => {
                              const newAppearance = { ...appearance, backgroundColor: e.target.value };
                              setAppearance(newAppearance);
                              updateGlobalProfile(newAppearance);
                            }}
                            className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 cursor-pointer p-1"
                          />
                          <input
                            type="text"
                            value={appearance.backgroundColor}
                            onChange={(e) => {
                              const newAppearance = { ...appearance, backgroundColor: e.target.value };
                              setAppearance(newAppearance);
                              updateGlobalProfile(newAppearance);
                            }}
                            className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm font-mono focus:outline-none focus:border-neon-orange/50"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </GlassCard>
              )}

              {activeSubTab === 'typography' && (
                <GlassCard className="p-8">
                  <h3 className="text-xl font-bold mb-8 flex items-center gap-2">
                    <Type size={20} className="text-neon-orange" /> Typography Settings
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                    {fonts.map((font) => (
                      <button
                        key={font.id}
                        onClick={() => handleSelectOption('fontFamily', font.id, font.pro)}
                        className={cn(
                          "flex items-center justify-between p-6 rounded-2xl border transition-all duration-300 relative",
                          appearance.fontFamily === font.id
                            ? "bg-neon-orange/10 border-neon-orange/30 text-neon-orange"
                            : "bg-white/5 border-white/10 text-white/50 hover:text-white hover:bg-white/10"
                        )}
                      >
                        <div className="text-left">
                          <span className={cn("text-xl block mb-1", font.class)}>{font.label}</span>
                          <span className="text-[10px] text-white/20 uppercase font-bold tracking-widest">Font Family</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {font.pro && <Lock size={14} className="text-white/30" />}
                          {appearance.fontFamily === font.id && <CheckCircle2 size={20} className="text-neon-orange" />}
                        </div>
                      </button>
                    ))}
                  </div>

                  {/* Custom Font Input */}
                  <div className="mt-6 p-6 rounded-2xl bg-white/5 border border-white/10">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-xs font-black text-white/30 uppercase tracking-widest flex items-center gap-2">
                        <Search size={14} /> Custom Google Font
                      </h4>
                      <button
                        onClick={() => setShowCustomFontInput(!showCustomFontInput)}
                        className="text-[10px] text-neon-orange hover:text-white font-bold flex items-center gap-1"
                      >
                        <Plus size={12} /> {showCustomFontInput ? 'Cancel' : 'Add Font'}
                      </button>
                    </div>
                    
                    {showCustomFontInput && (
                      <div className="space-y-3">
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={customFont}
                            onChange={(e) => setCustomFont(e.target.value)}
                            placeholder="Enter any Google Font name (e.g., Poppins, Montserrat)"
                            className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-neon-orange/50 placeholder:text-white/20"
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' && customFont.trim()) {
                                const fontId = customFont.trim().toLowerCase().replace(/\s+/g, '-');
                                const newAppearance = { ...appearance, fontFamily: fontId };
                                setAppearance(newAppearance);
                                updateGlobalProfile(newAppearance);
                                setShowCustomFontInput(false);
                              }
                            }}
                          />
                          <button
                            onClick={() => {
                              if (customFont.trim()) {
                                const fontId = customFont.trim().toLowerCase().replace(/\s+/g, '-');
                                const newAppearance = { ...appearance, fontFamily: fontId };
                                setAppearance(newAppearance);
                                updateGlobalProfile(newAppearance);
                                setShowCustomFontInput(false);
                              }
                            }}
                            className="px-6 py-3 rounded-xl bg-neon-orange text-black font-bold text-sm hover:bg-neon-orange/80 transition-colors"
                          >
                            Apply
                          </button>
                        </div>
                        <p className="text-[10px] text-white/30">
                          💡 Type any font name from fonts.google.com and press Apply. The font will load instantly on your profile.
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-8 border-t border-white/10">
                    <div className="space-y-4">
                      <h4 className="text-xs font-black text-white/30 uppercase tracking-widest mb-4">Font Weight</h4>
                      <div className="flex gap-2">
                        {['light', 'normal', 'bold', 'black'].map((weight) => (
                          <button 
                            key={weight}
                            onClick={() => {
                            const newAppearance = { ...appearance, fontWeight: weight };
                            setAppearance(newAppearance);
                            updateGlobalProfile(newAppearance);
                          }}
                            className={cn(
                              "flex-1 py-2 rounded-lg text-xs font-bold capitalize border transition-all",
                              appearance.fontWeight === weight ? "bg-neon-orange/20 border-neon-orange/50 text-neon-orange" : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10"
                            )}
                          >
                            {weight}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h4 className="text-xs font-black text-white/30 uppercase tracking-widest mb-4">Text Transform</h4>
                      <div className="flex gap-2">
                        {['none', 'uppercase', 'lowercase'].map((transform) => (
                          <button 
                            key={transform}
                            onClick={() => {
                            const newAppearance = { ...appearance, textTransform: transform };
                            setAppearance(newAppearance);
                            updateGlobalProfile(newAppearance);
                          }}
                            className={cn(
                              "flex-1 py-2 rounded-lg text-xs font-bold capitalize border transition-all",
                              appearance.textTransform === transform ? "bg-neon-orange/20 border-neon-orange/50 text-neon-orange" : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10"
                            )}
                          >
                            {transform}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </GlassCard>
              )}

              {activeSubTab === 'components' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <GlassCard className="p-8">
                    <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                      <MousePointer2 size={20} className="text-neon-orange" /> Button Style
                    </h3>
                    <div className="grid grid-cols-1 gap-3">
                      {buttonStyles.map((style) => (
                        <button
                          key={style.id}
                          onClick={() => handleSelectOption('buttonStyle', style.id, style.pro)}
                          className={cn(
                            "p-4 rounded-xl border transition-all duration-300 text-sm font-bold text-left flex items-center justify-between",
                            appearance.buttonStyle === style.id
                              ? "bg-neon-orange/10 border-neon-orange/30 text-neon-orange"
                              : "bg-white/5 border-white/10 text-white/50 hover:text-white hover:bg-white/10"
                          )}
                        >
                          <div className="flex items-center gap-2">
                            {style.label}
                            {style.pro && <Lock size={12} className="text-white/30" />}
                          </div>
                          {appearance.buttonStyle === style.id && <CheckCircle2 size={16} />}
                        </button>
                      ))}
                    </div>

                    <div className="mt-8 pt-8 border-t border-white/10">
                      <h4 className="text-xs font-black text-white/30 uppercase tracking-widest mb-4">Hover Animation</h4>
                      <div className="grid grid-cols-2 gap-3">
                        {['Scale', 'Glow', 'Slide', 'None', 'Glitch (Pro)', '3D Flip (Pro)'].map((effect) => (
                          <button 
                            key={effect} 
                            onClick={() => (effect.includes('Pro') && !profile?.isPro) ? window.dispatchEvent(new CustomEvent('open-pro-modal')) : null}
                            className="p-3 rounded-lg bg-white/5 border border-white/10 text-[10px] font-bold hover:border-neon-orange/30 transition-all flex justify-between items-center"
                          >
                            {effect.replace(' (Pro)', '')}
                            {effect.includes('Pro') && <Lock size={10} className="text-white/30" />}
                          </button>
                        ))}
                      </div>
                    </div>
                  </GlassCard>

                  <GlassCard className="p-8">
                    <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                      <Box size={20} className="text-neon-orange" /> Card Style
                    </h3>
                    <div className="grid grid-cols-1 gap-3">
                      {cardStyles.map((style) => (
                        <button
                          key={style.id}
                          onClick={() => handleSelectOption('cardStyle', style.id, style.pro)}
                          className={cn(
                            "p-4 rounded-xl border transition-all duration-300 text-sm font-bold text-left flex items-center justify-between",
                            appearance.cardStyle === style.id
                              ? "bg-neon-orange/10 border-neon-orange/30 text-neon-orange"
                              : "bg-white/5 border-white/10 text-white/50 hover:text-white hover:bg-white/10"
                          )}
                        >
                          <div className="flex items-center gap-2">
                            {style.label}
                            {style.pro && <Lock size={12} className="text-white/30" />}
                          </div>
                          {appearance.cardStyle === style.id && <CheckCircle2 size={16} />}
                        </button>
                      ))}
                    </div>

                    <div className="mt-8 pt-8 border-t border-white/10">
                      <h4 className="text-xs font-black text-white/30 uppercase tracking-widest mb-4">Border Weight</h4>
                      <div className="flex items-center gap-4">
                        <input 
                          type="range" 
                          min="0" 
                          max="4" 
                          step="1" 
                          value={appearance.borderWeight}
                          onChange={(e) => {
                          const newAppearance = { ...appearance, borderWeight: parseInt(e.target.value) };
                          setAppearance(newAppearance);
                          updateGlobalProfile(newAppearance);
                        }}
                          className="flex-1 accent-neon-orange"
                        />
                        <span className="text-xs font-mono text-white/40">{appearance.borderWeight}px</span>
                      </div>
                    </div>
                  </GlassCard>
                </div>
              )}

              {activeSubTab === 'layout' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <GlassCard className="p-8">
                    <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                      <Layers size={20} className="text-neon-orange" /> Page Layout
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      {layouts.map((layout) => (
                        <button
                          key={layout.id}
                          onClick={() => handleSelectOption('layout', layout.id, layout.pro)}
                          className={cn(
                            "flex flex-col items-center gap-3 p-4 rounded-2xl border transition-all duration-300 relative",
                            appearance.layout === layout.id
                              ? "bg-neon-orange/10 border-neon-orange/30 text-neon-orange"
                              : "bg-white/5 border-white/10 text-white/50 hover:text-white hover:bg-white/10"
                          )}
                        >
                          {layout.pro && <Lock size={12} className="absolute top-2 right-2 text-white/30" />}
                          {layout.icon}
                          <span className="text-[10px] font-black uppercase tracking-wider">{layout.label}</span>
                        </button>
                      ))}
                    </div>
                  </GlassCard>

                  <GlassCard className="p-8">
                    <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                      <Circle size={20} className="text-neon-orange" /> Avatar Shape
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      {avatarShapes.map((shape) => (
                        <button
                          key={shape.id}
                          onClick={() => handleSelectOption('avatarShape', shape.id, shape.pro)}
                          className={cn(
                            "flex flex-col items-center gap-3 p-4 rounded-2xl border transition-all duration-300 relative",
                            appearance.avatarShape === shape.id
                              ? "bg-neon-orange/10 border-neon-orange/30 text-neon-orange"
                              : "bg-white/5 border-white/10 text-white/50 hover:text-white hover:bg-white/10"
                          )}
                        >
                          {shape.pro && <Lock size={12} className="absolute top-2 right-2 text-white/30" />}
                          {shape.icon}
                          <span className="text-[10px] font-black uppercase tracking-wider">{shape.label}</span>
                        </button>
                      ))}
                    </div>
                  </GlassCard>
                </div>
              )}

              {activeSubTab === 'effects' && (
                <GlassCard className="p-8">
                  <h3 className="text-xl font-bold mb-8 flex items-center gap-2">
                    <Sparkles size={20} className="text-neon-orange" /> Visual Effects
                  </h3>
                  <div className="space-y-6">
                    <div className="flex items-center justify-between p-6 rounded-2xl bg-white/5 border border-white/10">
                      <div>
                        <h4 className="font-bold">Glassmorphism</h4>
                        <p className="text-xs text-white/30 mt-1">Enable frosted glass effects on cards and navigation.</p>
                      </div>
                      <button 
                        onClick={() => {
                          const newAppearance = { ...appearance, glassmorphism: !appearance.glassmorphism };
                          setAppearance(newAppearance);
                          updateGlobalProfile(newAppearance);
                        }}
                        className={cn(
                          "w-14 h-7 rounded-full p-1 transition-all duration-300 relative",
                          appearance.glassmorphism ? "bg-neon-orange" : "bg-white/10"
                        )}
                      >
                        <div className={cn(
                          "w-5 h-5 rounded-full bg-black transition-all duration-300",
                          appearance.glassmorphism ? "translate-x-7" : "translate-x-0"
                        )} />
                      </button>
                    </div>

                    <div className="flex items-center justify-between p-6 rounded-2xl bg-white/5 border border-white/10">
                      <div>
                        <h4 className="font-bold flex items-center gap-2">
                          CRT Scanlines <Lock size={12} className="text-white/30" />
                        </h4>
                        <p className="text-xs text-white/30 mt-1">Add retro CRT monitor scanlines over your profile.</p>
                      </div>
                      <button 
                        onClick={() => {
                          if (!profile?.isPro) {
                            window.dispatchEvent(new CustomEvent('open-pro-modal'));
                          } else {
                            const newAppearance = { ...appearance, crtEffect: !appearance.crtEffect };
                            setAppearance(newAppearance);
                            updateGlobalProfile(newAppearance);
                          }
                        }}
                        className={cn(
                          "w-14 h-7 rounded-full p-1 transition-all duration-300 relative",
                          appearance.crtEffect ? "bg-neon-orange" : "bg-white/10"
                        )}
                      >
                        <div className={cn(
                          "w-5 h-5 rounded-full bg-black transition-all duration-300",
                          appearance.crtEffect ? "translate-x-7" : "translate-x-0"
                        )} />
                      </button>
                    </div>

                    <div className="flex items-center justify-between p-6 rounded-2xl bg-white/5 border border-white/10">
                      <div>
                        <h4 className="font-bold flex items-center gap-2">
                          Glitch Effect <Lock size={12} className="text-white/30" />
                        </h4>
                        <p className="text-xs text-white/30 mt-1">Random text and image glitch effects.</p>
                      </div>
                      <button 
                        onClick={() => {
                          if (!profile?.isPro) {
                            window.dispatchEvent(new CustomEvent('open-pro-modal'));
                          } else {
                            const newAppearance = { ...appearance, glitchEffect: !appearance.glitchEffect };
                            setAppearance(newAppearance);
                            updateGlobalProfile(newAppearance);
                          }
                        }}
                        className={cn(
                          "w-14 h-7 rounded-full p-1 transition-all duration-300 relative",
                          appearance.glitchEffect ? "bg-neon-orange" : "bg-white/10"
                        )}
                      >
                        <div className={cn(
                          "w-5 h-5 rounded-full bg-black transition-all duration-300",
                          appearance.glitchEffect ? "translate-x-7" : "translate-x-0"
                        )} />
                      </button>
                    </div>

                    <div className="p-6 rounded-2xl bg-white/5 border border-white/10">
                      <div className="mb-4">
                        <h4 className="font-bold flex items-center gap-2">
                          Bloom Intensity <Lock size={12} className="text-white/30" />
                        </h4>
                        <p className="text-xs text-white/30 mt-1">Adjust the glow intensity of neon elements.</p>
                      </div>
                      <div className={cn("flex items-center gap-4", !profile?.isPro && "opacity-50")} onClick={() => !profile?.isPro && window.dispatchEvent(new CustomEvent('open-pro-modal'))}>
                        <input 
                          type="range" 
                          min="0" 
                          max="100" 
                          value={appearance.bloomIntensity} 
                          onChange={(e) => {
                            if (profile?.isPro) {
                              const newAppearance = { ...appearance, bloomIntensity: parseInt(e.target.value) };
                              setAppearance(newAppearance);
                              updateGlobalProfile(newAppearance);
                            }
                          }}
                          className={cn("flex-1 accent-neon-orange", !profile?.isPro && "pointer-events-none")}
                        />
                        <span className="text-xs font-mono text-white/40">{appearance.bloomIntensity}%</span>
                      </div>
                    </div>
                  </div>
                </GlassCard>
              )}

              {activeSubTab === 'themes' && (
                <GlassCard className="p-8">
                  <h3 className="text-xl font-bold mb-8 flex items-center gap-2">
                    <Monitor size={20} className="text-neon-orange" /> Global Theme Presets
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {themes.map((theme) => (
                      <button
                        key={theme.id}
                        onClick={() => handleSelectOption('theme', theme.id, theme.pro)}
                        className={cn(
                          "flex items-center justify-between p-6 rounded-2xl border transition-all duration-300 relative",
                          appearance.theme === theme.id
                            ? "bg-neon-orange/10 border-neon-orange/30 text-neon-orange"
                            : "bg-white/5 border-white/10 text-white/50 hover:text-white hover:bg-white/10"
                        )}
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center">
                            {theme.icon}
                          </div>
                          <div className="text-left">
                            <span className="font-bold block flex items-center gap-2">
                              {theme.label}
                              {theme.pro && <Lock size={12} className="text-white/30" />}
                            </span>
                            <span className="text-[10px] text-white/20 uppercase font-bold tracking-widest">Preset</span>
                          </div>
                        </div>
                        {appearance.theme === theme.id && <CheckCircle2 size={20} className="text-neon-orange" />}
                      </button>
                    ))}
                  </div>
                </GlassCard>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
