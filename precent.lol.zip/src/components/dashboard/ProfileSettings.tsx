import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { NeonButton } from '../ui/NeonButton';
import { Camera, MapPin, AtSign, User, FileText, Save, CheckCircle2, ShieldCheck, Sparkles, Loader2, Crown, Lock, Unlock, AlertCircle, XCircle } from 'lucide-react';
import { useSupabase } from '../SupabaseProvider';
import { profileService } from '@/src/services/profileService';
import { cn } from '@/src/lib/utils';
import { showToast } from '@/src/lib/toast';
import { supabase } from '@/src/lib/supabase';

// NSFW and Grabify link patterns
const BLOCKED_DOMAINS = [
  'grabify.link', 'bit.ly', 'tinyurl.com', 't.co', 'ow.ly', 'is.gd',
  'v.gd', 'adf.ly', 'short.link', 'cutt.ly', 'rb.gy'
];

const NSFW_KEYWORDS = [
  'porn', 'xxx', 'adult', 'nsfw', 'hentai', 'erotic', 'sex'
];

function isValidUrl(url: string): { valid: boolean; reason?: string } {
  if (!url) return { valid: true };
  
  try {
    const urlObj = new URL(url.startsWith('http') ? url : `https://${url}`);
    const hostname = urlObj.hostname.toLowerCase();
    
    // Check for blocked domains
    for (const domain of BLOCKED_DOMAINS) {
      if (hostname.includes(domain)) {
        return { valid: false, reason: 'URL shorteners and tracking links are not allowed' };
      }
    }
    
    // Check for NSFW keywords
    for (const keyword of NSFW_KEYWORDS) {
      if (hostname.includes(keyword) || url.toLowerCase().includes(keyword)) {
        return { valid: false, reason: 'NSFW content is not allowed' };
      }
    }
    
    return { valid: true };
  } catch {
    return { valid: false, reason: 'Invalid URL format' };
  }
}

export function ProfileSettings() {
  const { profile, setProfile, refreshProfile, user } = useSupabase();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatingBio, setGeneratingBio] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Username change state
  const [usernameInput, setUsernameInput] = useState('');
  const [usernameStatus, setUsernameStatus] = useState<'idle' | 'checking' | 'available' | 'taken'>('idle');
  const [usernameError, setUsernameError] = useState('');
  const [usernameCooldown, setUsernameCooldown] = useState<{ canChange: boolean; unlockDate?: Date }>({ canChange: true });
  const [showCooldownTooltip, setShowCooldownTooltip] = useState(false);
  const [usernameLoading, setUsernameLoading] = useState(false);
  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [formData, setFormData] = useState({
    displayName: '',
    bio: '',
    location: '',
    avatarUrl: '',
  });

  const isInitialized = useRef(false);

  useEffect(() => {
    if (profile && !isInitialized.current) {
      setFormData({
        displayName: profile.displayName || '',
        bio: profile.bio || '',
        location: profile.location || '',
        avatarUrl: profile.avatarUrl || '',
      });
      setUsernameInput(profile.username || '');
      setUsernameStatus('idle');
      setUsernameError('');
      isInitialized.current = true;
    }
  }, [profile]);

  // Check username change cooldown
  useEffect(() => {
    if (!profile?.metadata?.lastUsernameChange) {
      setUsernameCooldown({ canChange: true });
      return;
    }
    
    const lastChange = new Date(profile.metadata.lastUsernameChange);
    const unlockDate = new Date(lastChange.getTime() + 3 * 24 * 60 * 60 * 1000); // 3 days
    const now = new Date();
    
    if (now >= unlockDate) {
      setUsernameCooldown({ canChange: true });
    } else {
      setUsernameCooldown({ canChange: false, unlockDate });
    }
  }, [profile?.metadata?.lastUsernameChange]);

  const formatCooldownDate = (date: Date) => {
    return date.toLocaleString('en-US', {
      month: 'numeric',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  // Handle field changes with real-time preview
  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Update global profile for live preview
    if (profile) {
      setProfile(prev => prev ? {
        ...prev,
        preview: {
          ...prev.preview,
          [field]: value
        }
      } : null);
    }
  };

  const handleSave = async () => {
    if (!profile) return;

    // Validation
    if (!formData.displayName.trim()) {
      setError('Display name cannot be empty');
      return;
    }
    if (formData.displayName.length > 32) {
      setError('Display name is too long (max 32 characters)');
      return;
    }

    // Validate links if they exist
    if (profile.links && profile.links.length > 0) {
      for (const link of profile.links) {
        if (link.url) {
          const validation = isValidUrl(link.url);
          if (!validation.valid) {
            setError(`Link "${link.title}": ${validation.reason}`);
            return;
          }
        }
      }
    }

    setLoading(true);
    setError(null);
    try {
      console.log('Updating profile with data:', formData);
      
      // Update profile in database (only send non-null values)
      const updateData: Record<string, any> = {};
      if (formData.displayName !== undefined) updateData.displayName = formData.displayName;
      if (formData.bio !== undefined) updateData.bio = formData.bio;
      if (formData.location !== undefined) updateData.location = formData.location;
      if (formData.avatarUrl !== undefined) updateData.avatarUrl = formData.avatarUrl;
      
      await profileService.updateProfile(profile.uid, updateData);
      
      // Immediately update local state for better UX
      setProfile(prev => prev ? {
        ...prev,
        displayName: formData.displayName,
        bio: formData.bio,
        location: formData.location,
        avatarUrl: formData.avatarUrl,
      } : null);
      
      await refreshProfile();
      setSuccess(true);
      showToast('Profile saved successfully!', 'success');
      setTimeout(() => setSuccess(false), 3000);

      // Clear preview
      setProfile(prev => prev ? {
        ...prev,
        preview: {
          displayName: undefined,
          bio: undefined,
          location: undefined
        }
      } : null);
    } catch (err: any) {
      console.error('Failed to update profile:', err);
      setError(err.message || 'Failed to save changes. Please try again.');
      showToast('Failed to save profile', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Debounced username availability checker
  const checkUsernameAvailability = useCallback((username: string) => {
    if (!profile) return;

    // Don't check if it's their current username
    if (username.toLowerCase() === profile.username?.toLowerCase()) {
      setUsernameStatus('idle');
      setUsernameError('');
      return;
    }

    setUsernameStatus('checking');

    profileService.isUsernameAvailable(username.toLowerCase())
      .then((available) => {
        if (available) {
          setUsernameStatus('available');
          setUsernameError('');
        } else {
          setUsernameStatus('taken');
          setUsernameError('Username is already taken');
        }
      })
      .catch(() => {
        setUsernameStatus('idle');
      });
  }, [profile]);

  const handleUsernameChange = (newUsername: string) => {
    if (!usernameCooldown.canChange || usernameLoading) return;

    setUsernameInput(newUsername);
    setUsernameError('');

    // Clear previous timer
    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }

    // Validate length and characters in real-time
    if (newUsername.length > 0 && newUsername.length < 3) {
      setUsernameStatus('idle');
      setUsernameError('Username must be at least 3 characters');
      return;
    }

    if (newUsername.length > 20) {
      setUsernameStatus('idle');
      setUsernameError('Username must be less than 20 characters');
      return;
    }

    if (newUsername.length > 0 && !/^[a-zA-Z0-9_]+$/.test(newUsername)) {
      setUsernameStatus('idle');
      setUsernameError('Only letters, numbers, and underscores');
      return;
    }

    if (newUsername.length === 0) {
      setUsernameStatus('idle');
      setUsernameError('Username cannot be empty');
      return;
    }

    // Debounce availability check (wait 800ms after user stops typing)
    debounceTimer.current = setTimeout(() => {
      checkUsernameAvailability(newUsername);
    }, 800);
  };

  const handleUsernameSubmit = async () => {
    if (!profile || !usernameCooldown.canChange || usernameLoading) return;

    if (usernameInput.toLowerCase() === profile.username?.toLowerCase()) {
      showToast('Username unchanged', 'warning');
      return;
    }

    if (usernameStatus !== 'available') {
      showToast(usernameError || 'Please choose a valid username', 'error');
      return;
    }

    setUsernameLoading(true);
    try {
      await profileService.updateProfile(profile.uid, {
        username: usernameInput.toLowerCase(),
        metadata: {
          ...profile.metadata,
          lastUsernameChange: Date.now()
        }
      });

      await refreshProfile();
      setUsernameStatus('idle');
      showToast('Username updated successfully!', 'success');
    } catch (err: any) {
      console.error('Failed to update username:', err);
      showToast(err.message || 'Failed to update username', 'error');
    } finally {
      setUsernameLoading(false);
    }
  };

  // Cleanup debounce on unmount
  useEffect(() => {
    return () => {
      if (debounceTimer.current) {
        clearTimeout(debounceTimer.current);
      }
    };
  }, []);

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Convert to base64 for persistence
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setFormData({ ...formData, avatarUrl: base64String });

        // Update global profile for live preview
        if (profile) {
          setProfile(prev => prev ? {
            ...prev,
            avatarUrl: base64String
          } : null);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerateBio = async () => {
    setGeneratingBio(true);
    // Simulate AI generation delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const bios = [
      "Digital creator exploring the intersection of art and technology. 🎨✨ Building the future, one pixel at a time.",
      "Tech enthusiast, developer, and lifelong learner. 🚀 Passionate about creating seamless user experiences.",
      "Welcome to my digital space! 🌌 Sharing my journey, projects, and thoughts on the ever-evolving tech landscape.",
      "Creative mind with a focus on futuristic design and cyberpunk aesthetics. ⚡ Let's build something amazing."
    ];
    
    const randomBio = bios[Math.floor(Math.random() * bios.length)];
    setFormData({ ...formData, bio: randomBio });
    
    // Update global profile for live preview
    if (profile) {
      setProfile(prev => prev ? {
        ...prev,
        preview: {
          ...prev.preview,
          bio: randomBio
        }
      } : null);
    }
    
    setGeneratingBio(false);
  };

  return (
    <div className="space-y-12 max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700 relative">
      {/* Background Accents */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-neon-orange/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-0 -left-24 w-96 h-96 bg-purple-500/5 blur-[120px] rounded-full pointer-events-none" />
       
      <div className="text-center space-y-4 relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-neon-orange text-[10px] font-black uppercase tracking-[0.2em] backdrop-blur-md">
          <User size={12} className="fill-neon-orange" />
          <span>Profile Settings</span>
        </div>
        <h2 className="text-5xl md:text-7xl font-black tracking-tighter leading-[0.9]">
          Edit <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-orange via-white to-neon-orange bg-[length:200%_auto] animate-gradient-x">Profile</span>
        </h2>
        <p className="text-white/40 max-w-2xl mx-auto font-medium">
          Customize your profile and let others know who you are.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 relative z-10">
        {/* Left Column: Avatar & Basic Info */}
        <div className="lg:col-span-4 space-y-8">
          <GlassCard className="p-8 flex flex-col items-center text-center relative overflow-hidden group">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(255,136,0,0.05),transparent_70%)]" />
            
            <div className="relative group/avatar mb-6">
              <div className="w-32 h-32 rounded-[2rem] border-4 border-white/5 p-1.5 overflow-hidden relative transition-all duration-500 group-hover/avatar:border-neon-orange/30 group-hover/avatar:scale-105">
                <div className="absolute inset-0 bg-gradient-to-br from-neon-orange/20 to-cyan/20 opacity-0 group-hover/avatar:opacity-100 transition-opacity" />
                {formData.avatarUrl ? (
                  <img 
                    src={formData.avatarUrl} 
                    alt="Avatar"
                    className="w-full h-full rounded-[1.5rem] object-cover bg-white/10 relative z-10"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-full h-full rounded-[1.5rem] flex items-center justify-center bg-white/5 text-neon-orange font-black text-4xl relative z-10">
                    {formData.displayName?.[0] || '?'}
                  </div>
                )}
              </div>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleAvatarUpload}
                accept="image/*"
                className="hidden"
                style={{ display: 'none' }}
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="absolute -bottom-2 -right-2 w-10 h-10 rounded-xl bg-white text-black flex items-center justify-center hover:bg-neon-orange transition-all duration-300 shadow-xl z-20"
                type="button"
              >
                <Camera size={18} />
              </button>
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-black tracking-tight">{formData.displayName || 'Your Name'}</h3>
              <p className="text-white/40 text-[10px] font-black uppercase tracking-widest">@{profile?.username || formData.displayName?.toLowerCase().replace(/\s+/g, '') || 'user'}</p>
            </div>

            <div className="mt-6 pt-6 border-t border-white/5 w-full">
              <div className="flex items-center justify-center gap-4">
                <div className="text-center">
                  <p className="text-[10px] font-black text-white/20 uppercase tracking-widest mb-1">Views</p>
                  <p className="text-lg font-black">{profile?.analytics?.views || 0}</p>
                </div>
                <div className="w-px h-8 bg-white/5" />
                <div className="text-center">
                  <p className="text-[10px] font-black text-white/20 uppercase tracking-widest mb-1">Likes</p>
                  <p className="text-lg font-black">{profile?.likes || 0}</p>
                </div>
              </div>
            </div>
          </GlassCard>

          <GlassCard className="p-8 space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-black text-white/20 flex items-center gap-2 uppercase tracking-[0.2em]">
                  <AtSign size={12} /> Username
                </label>
                <div className="relative">
                  <button
                    onMouseEnter={() => setShowCooldownTooltip(true)}
                    onMouseLeave={() => setShowCooldownTooltip(false)}
                    className="text-white/30 hover:text-white/60 transition-colors"
                  >
                    {usernameCooldown.canChange ? <Unlock size={14} /> : <Lock size={14} />}
                  </button>
                  
                  {/* Cooldown tooltip */}
                  {showCooldownTooltip && !usernameCooldown.canChange && usernameCooldown.unlockDate && (
                    <motion.div
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="absolute bottom-full right-0 mb-2 px-3 py-2 rounded-lg bg-[#1a1a1a] border border-white/10 shadow-xl whitespace-nowrap z-50"
                    >
                      <div className="flex items-center gap-2 text-[10px] text-white/60">
                        <AlertCircle size={12} className="text-neon-orange" />
                        <span>You can change your username after {formatCooldownDate(usernameCooldown.unlockDate)}</span>
                      </div>
                      <div className="absolute top-full right-3 w-2 h-2 bg-[#1a1a1a] border-r border-b border-white/10 transform rotate-45 -mt-1" />
                    </motion.div>
                  )}
                </div>
              </div>
              
              <div className="relative">
                <div className={cn(
                  "w-full bg-white/5 border rounded-2xl transition-all pr-12",
                  usernameCooldown.canChange
                    ? "border-white/10 focus-within:border-neon-orange/50 focus-within:bg-white/10"
                    : "border-white/5 bg-white/2 cursor-not-allowed"
                )}>
                  <input
                    type="text"
                    value={usernameInput}
                    onChange={(e) => handleUsernameChange(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') handleUsernameSubmit(); }}
                    disabled={!usernameCooldown.canChange || usernameLoading}
                    className={cn(
                      "w-full bg-transparent px-6 py-4 font-bold text-sm transition-all outline-none",
                      usernameCooldown.canChange
                        ? "text-white placeholder:text-white/30"
                        : "text-white/20 placeholder:text-white/10"
                    )}
                    placeholder="username"
                  />
                </div>
                {/* Status indicator */}
                <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-1">
                  {usernameLoading ? (
                    <Loader2 size={16} className="text-neon-orange animate-spin" />
                  ) : usernameStatus === 'checking' ? (
                    <Loader2 size={16} className="text-yellow-400 animate-spin" />
                  ) : usernameStatus === 'available' ? (
                    <motion.div
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                    >
                      <CheckCircle2 size={16} className="text-green-400" />
                    </motion.div>
                  ) : usernameStatus === 'taken' ? (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', stiffness: 300 }}
                    >
                      <XCircle size={16} className="text-red-400" />
                    </motion.div>
                  ) : null}
                </div>
              </div>
              {/* Status text */}
              <AnimatePresence>
                {usernameStatus === 'available' && (
                  <motion.p
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="text-[10px] font-bold text-green-400 px-2 flex items-center gap-1"
                  >
                    <CheckCircle2 size={10} /> Username available!
                  </motion.p>
                )}
                {usernameStatus === 'taken' && (
                  <motion.p
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="text-[10px] font-bold text-red-400 px-2 flex items-center gap-1"
                  >
                    <XCircle size={10} /> Username taken
                  </motion.p>
                )}
                {usernameError && usernameStatus !== 'taken' && (
                  <motion.p
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="text-[10px] font-medium text-yellow-400/60 px-2"
                  >
                    {usernameError}
                  </motion.p>
                )}
              </AnimatePresence>
              {/* Apply button */}
              {usernameStatus === 'available' && usernameInput !== profile?.username && (
                <motion.button
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  onClick={handleUsernameSubmit}
                  disabled={usernameLoading}
                  className="mt-2 px-4 py-2 rounded-xl bg-green-400/10 border border-green-400/30 text-green-400 text-xs font-bold hover:bg-green-400/20 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {usernameLoading ? <Loader2 size={14} className="animate-spin inline mr-2" /> : <CheckCircle2 size={14} className="inline mr-2" />}
                  {usernameLoading ? 'Applying...' : 'Apply Username Change'}
                </motion.button>
              )}
              <p className="text-[9px] text-white/20 font-medium px-2 mt-1">
                {usernameCooldown.canChange
                  ? 'Username can be changed once every 3 days'
                  : `Next change available after ${formatCooldownDate(usernameCooldown.unlockDate!)}`
                }
              </p>
            </div>
          </GlassCard>
        </div>

        {/* Right Column: Detailed Info */}
        <div className="lg:col-span-8 space-y-8">
          <GlassCard className="p-8 space-y-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-neon-orange/5 blur-[100px] rounded-full pointer-events-none" />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <label className="text-[10px] font-black text-white/20 flex items-center gap-2 uppercase tracking-[0.2em]">
                  <User size={12} /> Display Name
                </label>
                <div className="relative group/input">
                  <input
                    type="text"
                    value={formData.displayName}
                    onChange={(e) => handleChange('displayName', e.target.value)}
                    placeholder="Alex Doe"
                    className="w-full bg-white/5 border border-white/5 rounded-2xl px-6 py-4 focus:outline-none focus:border-neon-orange/30 focus:bg-white/10 transition-all font-bold text-white placeholder:text-white/10"
                  />
                  <div className="absolute bottom-0 left-6 right-6 h-[1px] bg-gradient-to-r from-transparent via-neon-orange/0 to-transparent group-focus-within/input:via-neon-orange/50 transition-all duration-500" />
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-[10px] font-black text-white/20 flex items-center gap-2 uppercase tracking-[0.2em]">
                  <MapPin size={12} /> Location
                </label>
                <div className="relative group/input">
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => handleChange('location', e.target.value)}
                    placeholder="San Francisco, CA"
                    className="w-full bg-white/5 border border-white/5 rounded-2xl px-6 py-4 focus:outline-none focus:border-neon-orange/30 focus:bg-white/10 transition-all font-bold text-white placeholder:text-white/10"
                  />
                  <div className="absolute bottom-0 left-6 right-6 h-[1px] bg-gradient-to-r from-transparent via-neon-orange/0 to-transparent group-focus-within/input:via-neon-orange/50 transition-all duration-500" />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-black text-white/20 flex items-center gap-2 uppercase tracking-[0.2em]">
                  <FileText size={12} /> Biography
                </label>
                <button
                  onClick={handleGenerateBio}
                  disabled={generatingBio}
                  className="text-[10px] text-neon-orange hover:text-white flex items-center gap-2 font-black uppercase tracking-widest transition-all group/gen"
                >
                  <Sparkles size={12} className={cn("group-hover:rotate-12 transition-transform", generatingBio && "animate-spin")} />
                  {generatingBio ? 'Generating...' : 'Auto-Generate'}
                </button>
              </div>
              <div className="relative group/input">
                <textarea
                  rows={6}
                  value={formData.bio}
                  onChange={(e) => handleChange('bio', e.target.value)}
                  placeholder="Tell us about yourself..."
                  className="w-full bg-white/5 border border-white/5 rounded-2xl px-6 py-4 focus:outline-none focus:border-neon-orange/30 focus:bg-white/10 transition-all resize-none font-medium text-white placeholder:text-white/10 leading-relaxed"
                />
                <div className="absolute bottom-0 left-6 right-6 h-[1px] bg-gradient-to-r from-transparent via-neon-orange/0 to-transparent group-focus-within/input:via-neon-orange/50 transition-all duration-500" />
              </div>
            </div>

            <div className="pt-4 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex-1 w-full">
                {error && (
                  <motion.div 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-center gap-3"
                  >
                    <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                    <p className="text-red-500 text-[10px] font-black uppercase tracking-widest">{error}</p>
                  </motion.div>
                )}
              </div>
              
              <NeonButton
                onClick={handleSave}
                disabled={loading}
                size="lg"
                className={cn(
                  "w-full md:w-auto px-12 py-5 text-[10px] font-black tracking-[0.2em] shadow-[0_0_30px_rgba(255,136,0,0.1)]",
                  success && "bg-white border-white text-black shadow-[0_0_30px_rgba(255,255,255,0.2)]"
                )}
              >
                {loading ? (
                  <div className="flex items-center gap-3">
                    <Loader2 size={18} className="animate-spin" />
                    SAVING...
                  </div>
                ) : success ? (
                  <div className="flex items-center gap-3">
                    <CheckCircle2 size={18} />
                    SETTINGS SAVED
                  </div>
                ) : (
                  <div className="flex items-center gap-3">
                    <Save size={18} />
                    SAVE PROFILE
                  </div>
                )}
              </NeonButton>
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
}
