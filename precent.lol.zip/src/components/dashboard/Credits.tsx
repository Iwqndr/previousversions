import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { Crown, Code, Briefcase, Heart, Shield, Users, Headset, Bug, Star, AlertCircle, Sparkles, ExternalLink, ShieldCheck } from 'lucide-react';
import { cn } from '@/src/lib/utils';

const team = {
  owners: [
    { name: 'Joe', role: 'Owner', desc: '"wonderoo is stupid 🥹"', avatar: 'https://media.discordapp.net/attachments/1489617086715138232/1489937577355116817/d19861b79e4749de8cad9ce1ad3be7d3tplv-jj85edgx6n-image-origin.jpeg?ex=69d23c00&is=69d0ea80&hm=91b22de1b977611549633c33302cbb6acf3a8e88fc8252aeee348b429500e90e&=&format=webp&width=760&height=1006', link: '#', highlighted: true },
  ],
  coowners: [
    { name: 'Wonderoo', role: 'Co-Owner', desc: '"when life gives you boobs squeeze them"', avatar: 'https://media.discordapp.net/attachments/1489617086891163812/1489937781202354236/b258f7be6f95e29f57b0db063d146bc0.jpg?ex=69d23c30&is=69d0eab0&hm=5b3e1e220af3dee946f4f2a378f6708791fa7d87267e29b1a898c39a5e538b16&=&format=webp', link: '#', highlighted: true },
  ],
  opmanagers: [
    { name: 'littledripperr', role: 'Operations Manager', desc: '"hi"', avatar: 'https://images-ext-1.discordapp.net/external/WJWDC1t-lHTmdYJOpSlObyQH2Dyq6r1i0ceAJguH_Lg/%3Fsize%3D1024/https/cdn.discordapp.com/avatars/1243983895481815114/53f5b154b1771d7ae6a841dc7f20e05f.png?format=webp&quality=lossless', link: '#' },
    { name: 'cool', role: 'Operations Manager (larp)', desc: '"people will hear the word ametkin and think "he couldve been something big".... (im lying bro nobody gonna think that ur streams ass)"', avatar: 'https://images-ext-1.discordapp.net/external/cmpDnsoBmgy2YNHbs1zwQgX8ABMDdzeO30cCb025EVw/%3Fsize%3D1024/https/cdn.discordapp.com/avatars/1313997045794865248/a_7a0a484bb5b91ec1783a7c99043f8aab.gif', link: '#' },
  ],
  developers: [
    { name: '98hk', role: 'Developer', desc: '"glocky"', avatar: 'https://cdn.pfps.gg/pfps/19753-bolsonaro-rebaixado.gif', link: '#', highlighted: true },
  ],
  managers: [],
  administrators: [],
  moderators: [
    { name: 'awpawlogyyyy', role: 'Trial Moderator', desc: '"meow"', avatar: 'https://images-ext-1.discordapp.net/external/BUmuMkE-bgir_m7bmqefmp44SteYHNTlakUc2wv_xoU/%3Fsize%3D1024/https/cdn.discordapp.com/avatars/1484421579692834907/75e51284ede39296699286f742387eb2.png?format=webp&quality=lossless', link: '#', highlighted: false },
    { name: 'xw1bx', role: 'Trial Moderator & Contributor', desc: '"why am i here 🤦‍♂️"', avatar: 'https://images-ext-1.discordapp.net/external/SGBhAN9hhA_t4yLQv6pI22bLzkwe5tRsQ_gy3fn0yvs/%3Fsize%3D1024/https/cdn.discordapp.com/avatars/1189764088486703137/af048fbe93340610feba953927c508ef.png?format=webp&quality=lossless&width=300&height=300', link: '#', highlighted: false },
    { name: 'Bxrer', role: 'Trial Moderator', desc: '"N/A"', avatar: 'https://images-ext-1.discordapp.net/external/cIdjZUOBcjJoC9Oi0r02iEmgjkuizY3mQFSz_yv8PWE/%3Fsize%3D1024/https/cdn.discordapp.com/avatars/1134264800554254426/0c37543fe011b49318cd038f480c679b.png?format=webp&quality=lossless', link: '#', highlighted: false },
    { name: 'w5ry', role: 'Trial Moderator', desc: '"imma pass the blunt to anne frank"', avatar: 'https://images-ext-1.discordapp.net/external/X4IbX7a0Vb81vVGo18vtdQu63wkHgyAHHmUafFEVH_c/%3Fsize%3D1024/https/cdn.discordapp.com/avatars/1455697646395195464/6ed294288d6c9d5af0ec10524bc7b173.png?format=webp&quality=lossless', link: '#', highlighted: false },
  ],
  supportteam: [],
  contributors: [],
};

const specialThanks = ['Community Members', 'Early Access Members', 'Beta Testers'];

export function Credits() {
  const [activeTab, setActiveTab] = useState<keyof typeof team>('owners');

  const tabs = [
    { id: 'owners', label: 'Owner', icon: Crown },
    { id: 'coowners', label: 'Co-Owner', icon: Crown },
    { id: 'opmanagers', label: 'Operations Manager', icon: Shield },
    { id: 'developers', label: 'Developers', icon: Code },
    { id: 'managers', label: 'Managers', icon: Briefcase },
    { id: 'administrators', label: 'Administrators', icon: ShieldCheck },
    { id: 'moderators', label: 'Moderators', icon: Users },
    { id: 'supportteam', label: 'Support Team', icon: Headset },
    { id: 'contributors', label: 'Testers', icon: Bug },
  ] as const;

  return (
    <div className="space-y-12 max-w-6xl mx-auto animate-in fade-in duration-700">
      <div className="text-center space-y-4">
        <h2 className="text-5xl md:text-6xl font-black tracking-tighter bg-clip-text text-transparent bg-gradient-to-b from-white to-white/50">
          The <span className="text-neon-orange">Precent</span> Team
        </h2>
        <p className="text-white/40 max-w-lg mx-auto text-lg">
          The brilliant minds and dedicated souls building the future of bio-links.
        </p>
      </div>

      <div className="flex flex-wrap justify-center gap-2 p-1 bg-white/5 rounded-2xl max-w-5xl mx-auto backdrop-blur-sm border border-white/5">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all duration-300",
              activeTab === tab.id
                ? "bg-neon-orange text-black shadow-[0_0_20px_rgba(255,136,0,0.3)]"
                : "text-white/40 hover:text-white hover:bg-white/5"
            )}
          >
            <tab.icon size={12} />
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className={cn(
            "grid gap-6",
            team[activeTab].length > 0 ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"
          )}
        >
          {team[activeTab].length > 0 ? (
            team[activeTab].map((member, index) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
              >
                <GlassCard className={cn(
                  "p-6 border-white/10 flex items-center gap-4 hover:border-neon-orange/50 transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,136,0,0.1)] group",
                  member.highlighted && "border-neon-orange/30 bg-neon-orange/5"
                )}>
                  <div className="relative">
                    <img src={member.avatar} alt={member.name} className="w-16 h-16 rounded-full bg-white/5 group-hover:scale-105 transition-transform duration-300" />
                    <div className="absolute inset-0 rounded-full ring-2 ring-neon-orange/20 group-hover:ring-neon-orange/50 transition-all duration-300" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-black text-lg group-hover:text-neon-orange transition-colors">{member.name}</h4>
                      {member.link && (
                        <a href={member.link} className="text-white/20 hover:text-neon-orange transition-colors">
                          <ExternalLink size={14} />
                        </a>
                      )}
                    </div>
                    <p className="text-[10px] font-black text-white/30 uppercase tracking-widest mb-1">{member.role}</p>
                    <p className="text-xs text-white/50">{member.desc}</p>
                  </div>
                </GlassCard>
              </motion.div>
            ))
          ) : (
            <GlassCard className="p-16 border-white/5 flex flex-col items-center justify-center text-center gap-4 bg-gradient-to-b from-white/5 to-transparent">
              <AlertCircle size={48} className="text-white/10" />
              <h3 className="text-2xl font-black text-white/40">No active {activeTab}</h3>
              <p className="text-sm text-white/30">The team is currently expanding. Please come back later!</p>
            </GlassCard>
          )}
        </motion.div>
      </AnimatePresence>

      <div className="pt-12 border-t border-white/5">
        <h3 className="text-center text-sm font-black text-white/20 uppercase tracking-[0.2em] mb-8 flex items-center justify-center gap-2">
          <Sparkles size={16} className="text-neon-orange" /> Special Thanks
        </h3>
        <div className="flex flex-wrap justify-center gap-4">
          {specialThanks.map((name) => (
            <div key={name} className="px-6 py-3 rounded-full bg-white/5 border border-white/5 text-xs font-bold text-white/60 hover:border-neon-orange/50 hover:text-neon-orange transition-all cursor-default">
              {name}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
