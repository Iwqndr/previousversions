import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { NeonButton } from '../ui/NeonButton';
import { Plus, GripVertical, Trash2, Edit2, ExternalLink, Eye, EyeOff, Link as LinkIcon, Save, CheckCircle2, X, Crown, AlertCircle } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { useSupabase } from '../SupabaseProvider';
import { profileService } from '@/src/services/profileService';
import { BioLink } from '@/src/types';
import { showToast } from '@/src/lib/toast';

// Reuse the same validation from ProfileSettings
const BLOCKED_DOMAINS = [
  'grabify.link', 'bit.ly', 'tinyurl.com', 't.co', 'ow.ly', 'is.gd',
  'v.gd', 'adf.ly', 'short.link', 'cutt.ly', 'rb.gy'
];

const NSFW_KEYWORDS = [
  'porn', 'xxx', 'adult', 'nsfw', 'hentai', 'erotic', 'sex'
];

function isValidLinkUrl(url: string): { valid: boolean; reason?: string } {
  if (!url) return { valid: true };
  
  try {
    const urlObj = new URL(url.startsWith('http') ? url : `https://${url}`);
    const hostname = urlObj.hostname.toLowerCase();
    
    for (const domain of BLOCKED_DOMAINS) {
      if (hostname.includes(domain)) {
        return { valid: false, reason: 'URL shorteners and tracking links are not allowed' };
      }
    }
    
    for (const keyword of NSFW_KEYWORDS) {
      if (hostname.includes(keyword) || url.toLowerCase().includes(keyword)) {
        return { valid: false, reason: 'NSFW content is not allowed' };
      }
    }
    
    return { valid: true };
  } catch {
    return { valid: false, reason: 'Invalid URL format' };
  }
}

export function LinksSettings() {
  const { profile, setProfile, refreshProfile } = useSupabase();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [links, setLinks] = useState<BioLink[]>([]);
  const [editingLink, setEditingLink] = useState<BioLink | null>(null);
  const isInitialized = useRef(false);

  useEffect(() => {
    if (profile && !isInitialized.current) {
      setLinks(profile.links || []);
      isInitialized.current = true;
    }
  }, [profile]);

  const updateGlobalProfile = (newLinks: BioLink[]) => {
    if (profile) {
      setProfile({
        ...profile,
        links: newLinks
      });
    }
  };

  const handleAddLink = () => {
    const newLink: BioLink = {
      id: Math.random().toString(36).substr(2, 9),
      title: '',
      url: '',
      active: true,
      clicks: 0
    };
    const newLinks = [newLink, ...links];
    setLinks(newLinks);
    setEditingLink(newLink);
    updateGlobalProfile(newLinks);
  };

  const handleUpdateLink = (id: string, updates: Partial<BioLink>) => {
    const newLinks = links.map(link => link.id === id ? { ...link, ...updates } : link);
    setLinks(newLinks);
    if (editingLink?.id === id) {
      const updatedEditingLink = { ...editingLink, ...updates };
      setEditingLink(updatedEditingLink);
      
      // Update global profile for real-time preview of the link being edited
      if (profile) {
        setProfile(prev => prev ? {
          ...prev,
          links: newLinks,
          preview: {
            ...prev.preview,
            link: updatedEditingLink
          }
        } : null);
      }
    } else {
      updateGlobalProfile(newLinks);
    }
  };

  const handleDeleteLink = (id: string) => {
    const newLinks = links.filter(link => link.id !== id);
    setLinks(newLinks);
    if (editingLink?.id === id) setEditingLink(null);
    updateGlobalProfile(newLinks);
  };

  const handleSave = async () => {
    if (!profile) return;
    
    // Validate all links before saving
    for (const link of links) {
      if (link.url && link.active) {
        const validation = isValidLinkUrl(link.url);
        if (!validation.valid) {
          showToast(`Link "${link.title || 'Untitled'}": ${validation.reason}`, 'error');
          return;
        }
      }
    }
    
    setLoading(true);
    try {
      await profileService.updateProfile(profile.uid, { links });
      await refreshProfile();
      setSuccess(true);
      showToast('Links saved successfully!', 'success');
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to update links:', err);
      showToast('Failed to save links', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-12 max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700 relative">
      {/* Background Accents */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-neon-orange/5 blur-[120px] rounded-full pointer-events-none" />
      
      <div className="text-center space-y-4 relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-neon-orange text-[10px] font-black uppercase tracking-[0.2em] backdrop-blur-md">
          <LinkIcon size={12} className="fill-neon-orange" />
          <span>Link Management</span>
        </div>
        <h2 className="text-5xl md:text-7xl font-black tracking-tighter leading-[0.9]">
          Link <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-orange via-white to-neon-orange bg-[length:200%_auto] animate-gradient-x">Management</span>
        </h2>
        <p className="text-white/40 max-w-2xl mx-auto font-medium">
          Manage your links and social connections.
        </p>
        <div className="pt-4">
          <NeonButton 
            onClick={handleAddLink}
            size="lg"
            className="px-10 py-5 text-[10px] font-black tracking-[0.2em] shadow-[0_0_30px_rgba(255,136,0,0.2)]"
          >
            <Plus size={18} className="mr-2" />
            ADD NEW LINK
          </NeonButton>
        </div>
      </div>
      
      <div className="space-y-6 relative z-10">
        <div className="flex items-center justify-between px-4">
          <h3 className="text-[10px] font-black text-white/20 uppercase tracking-[0.4em]">Active Links</h3>
          <span className="text-[10px] font-black text-neon-orange uppercase tracking-widest">{links.length} Connected</span>
        </div>
        
        <div className="space-y-4">
          {links.map((link, index) => (
            <motion.div
              key={link.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <GlassCard className="p-6 bg-surface/50 border-white/5 hover:border-white/10 transition-all group overflow-hidden relative">
                <div className="absolute inset-0 bg-gradient-to-r from-neon-orange/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                
                <div className="flex items-center gap-6 relative z-10">
                  <div className="cursor-grab active:cursor-grabbing p-2 text-white/10 hover:text-white/40 transition-colors">
                    <GripVertical size={20} />
                  </div>
                  
                  <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center text-white/40 group-hover:text-neon-orange group-hover:bg-neon-orange/10 transition-all duration-500">
                    <LinkIcon size={24} />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-1">
                      <h4 className="text-lg font-black tracking-tight text-white/90 group-hover:text-white transition-colors truncate">{link.title || 'Untitled Link'}</h4>
                      <span className="text-[10px] font-black text-neon-orange bg-neon-orange/10 px-2 py-0.5 rounded-lg uppercase tracking-widest">
                        {link.clicks} CLICKS
                      </span>
                    </div>
                    <p className="text-xs font-medium text-white/20 truncate flex items-center gap-2">
                      <ExternalLink size={12} /> {link.url || 'No URL set'}
                    </p>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={() => handleUpdateLink(link.id, { active: !link.active })}
                      className={cn(
                        "w-12 h-6 rounded-full transition-all duration-500 relative p-1",
                        link.active ? "bg-neon-orange shadow-[0_0_15px_rgba(255,136,0,0.3)]" : "bg-white/10"
                      )}
                    >
                      <div className={cn(
                        "w-4 h-4 rounded-full bg-white transition-all duration-500",
                        link.active ? "translate-x-6" : "translate-x-0"
                      )} />
                    </button>
                    
                    <button 
                      onClick={() => setEditingLink(link)}
                      className="p-3 rounded-xl bg-white/5 text-white/40 hover:text-white hover:bg-white/10 transition-all"
                    >
                      <Edit2 size={18} />
                    </button>
                    
                    <button 
                      onClick={() => handleDeleteLink(link.id)}
                      className="p-3 rounded-xl bg-white/5 text-white/40 hover:text-red-500 hover:bg-red-500/10 transition-all"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </div>

      {links.length === 0 && (
        <div className="text-center py-20 glass rounded-3xl border-dashed border-2 border-white/10">
          <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4">
            <LinkIcon size={32} className="text-white/20" />
          </div>
          <h3 className="text-xl font-bold mb-2">No links yet</h3>
          <p className="text-white/40 mb-8">Add your first link to start building your profile.</p>
          <NeonButton onClick={handleAddLink}>Add Your First Link</NeonButton>
        </div>
      )}

      {links.length > 0 && (
        <div className="pt-4">
          <NeonButton 
            size="lg" 
            onClick={handleSave} 
            disabled={loading}
            className={cn(success && "bg-neon-orange border-neon-orange text-black shadow-[0_0_20px_rgba(255,136,0,0.3)]")}
          >
            {loading ? 'Saving...' : success ? (
              <>
                <CheckCircle2 size={18} />
                Saved!
              </>
            ) : (
              <>
                <Save size={18} />
                Save Link Order
              </>
            )}
          </NeonButton>
        </div>
      )}

      {/* Edit Link Modal */}
      <AnimatePresence>
        {editingLink && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="w-full max-w-lg"
            >
              <GlassCard className="p-8 space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold">Edit Link</h3>
                  <button onClick={() => setEditingLink(null)} className="text-white/40 hover:text-white">
                    <X size={24} />
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-white/50 uppercase tracking-widest">Title</label>
                    <input 
                      type="text" 
                      value={editingLink.title}
                      onChange={(e) => handleUpdateLink(editingLink.id, { title: e.target.value })}
                      placeholder="e.g. My Portfolio"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 transition-all font-bold"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-white/50 uppercase tracking-widest">URL</label>
                    <div className="relative">
                      <input
                        type="text"
                        value={editingLink.url}
                        onChange={(e) => {
                          const url = e.target.value;
                          let newTitle = editingLink.title;

                          // Auto-detect title if empty
                          if (!editingLink.title && url && url.includes('.')) {
                            try {
                              let domainStr = url;
                              if (!domainStr.startsWith('http')) {
                                domainStr = 'https://' + domainStr;
                              }
                              const domain = new URL(domainStr).hostname.replace('www.', '');
                              const name = domain.split('.')[0];
                              newTitle = name.charAt(0).toUpperCase() + name.slice(1);
                            } catch (err) {
                              // Invalid URL, ignore
                            }
                          }

                          // Validate URL in real-time
                          if (url) {
                            const validation = isValidLinkUrl(url);
                            if (!validation.valid) {
                              showToast(validation.reason!, 'warning');
                            }
                          }

                          handleUpdateLink(editingLink.id, { url, title: newTitle });
                        }}
                        placeholder="e.g. https://alexdoe.com"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 transition-all text-sm"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <NeonButton className="w-full" onClick={() => {
                    setEditingLink(null);
                    // Clear preview when done
                    if (profile) {
                      setProfile(prev => prev ? {
                        ...prev,
                        preview: {
                          ...prev.preview,
                          link: undefined
                        }
                      } : null);
                    }
                  }}>
                    Done
                  </NeonButton>
                </div>
              </GlassCard>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
