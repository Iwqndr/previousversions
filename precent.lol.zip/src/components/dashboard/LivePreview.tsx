import { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { BioLink, AppearanceSettings, MusicTrack, MediaItem, UserProfile } from '@/src/types';
import { cn } from '@/src/lib/utils';
import { ExternalLink, Music, Eye, MapPin, Heart, Play, Pause, Volume2, Flag, Video, ImageIcon, MessageSquare } from 'lucide-react';
import { subscribeToAppearance } from '@/src/utils/appearancePreview';

interface LivePreviewProps {
  displayName: string;
  username: string;
  bio: string;
  avatarUrl?: string;
  links: BioLink[];
  appearance: AppearanceSettings;
  music?: MusicTrack[];
  media?: MediaItem[];
  preview?: UserProfile['preview'];
}

export function LivePreview({
  displayName,
  username,
  bio,
  avatarUrl,
  links,
  appearance: appearanceProp,
  music,
  media = [],
  location,
  views = 0,
  likes = 0,
  preview
}: LivePreviewProps & { location?: string; views?: number; likes?: number }) {
  // Use local state for appearance to avoid parent re-renders
  const [appearance, setAppearance] = useState(appearanceProp);

  // Subscribe to live preview appearance changes
  useEffect(() => {
    setAppearance(appearanceProp);
    const unsubscribe = subscribeToAppearance((newAppearance) => {
      setAppearance({ ...newAppearance });
    });
    return unsubscribe;
  }, [appearanceProp]);

  // Apply preview overrides
  const displayDisplayName = preview?.displayName || displayName;
  const displayBio = preview?.bio || bio;
  const displayLocation = preview?.location || location;

  // For links, if we are editing/adding one, show it in the list
  const displayLinks = [...links];
  if (preview?.link) {
    const existingIndex = displayLinks.findIndex(l => l.id === preview.link?.id);
    if (existingIndex > -1) {
      displayLinks[existingIndex] = { ...displayLinks[existingIndex], ...preview.link };
    } else if (preview.link.title || preview.link.url) {
      displayLinks.push({
        id: 'preview',
        title: preview.link.title || 'New Link',
        url: preview.link.url || '#',
        active: true,
        clicks: 0,
        ...preview.link
      });
    }
  }

  // For music, if we are adding one, show it as active
  const activeTrack = preview?.music ? {
    id: 'preview',
    title: preview.music.title || 'New Track',
    artist: preview.music.artist || 'Unknown Artist',
    url: preview.music.url || '',
    active: true,
    ...preview.music
  } : music?.find(t => t.active);

  // For discord, handle preview overrides
  const discordData = preview?.discord ? {
    ...preview.discord
  } : undefined;

  // Helper functions for appearance
  const getFontFamily = () => {
    const fontMap: Record<string, string> = {
      'inter': '"Inter", sans-serif',
      'mono': '"JetBrains Mono", monospace',
      'outfit': '"Outfit", sans-serif',
      'space': '"Space Grotesk", sans-serif',
      'roboto': '"Roboto", sans-serif',
      'lato': '"Lato", sans-serif',
      'playfair': '"Playfair Display", serif',
      'rubik': '"Rubik", sans-serif',
      'syne': '"Syne", sans-serif',
      'bricolage': '"Bricolage Grotesque", sans-serif',
      'clash': '"Clash Display", sans-serif',
      'chillax': '"Chillax", sans-serif',
    };
    return fontMap[appearance.fontFamily || 'inter'] || '"Inter", sans-serif';
  };

  const getAvatarShape = () => {
    switch (appearance.avatarShape) {
      case 'circle': return 'rounded-full';
      case 'square': return 'rounded-none';
      case 'rounded': return 'rounded-2xl';
      case 'squircle': return 'rounded-[2rem]';
      default: return 'rounded-full';
    }
  };

  const getBackgroundStyle = () => {
    switch (appearance.backgroundType) {
      case 'solid':
        return { backgroundColor: appearance.backgroundColor || '#050505' };
      case 'gradient':
        return { background: `linear-gradient(135deg, ${appearance.backgroundColor || '#050505'}, #0a0a0a)` };
      default:
        return { backgroundColor: '#050505' };
    }
  };

  const getCardClass = () => {
    const baseClasses = "w-full h-full p-8 flex flex-col items-center text-center overflow-y-auto custom-scrollbar relative z-10";
    switch (appearance.cardStyle) {
      case 'flat': return `${baseClasses} bg-white/5`;
      case 'elevated': return `${baseClasses} bg-white/10 shadow-xl`;
      case 'glass': return appearance.glassmorphism ? `${baseClasses} glass backdrop-blur-md` : `${baseClasses} bg-white/5`;
      case 'bordered': return `${baseClasses} bg-transparent border-2 border-white/20`;
      case 'neon': return `${baseClasses} bg-black/40 border-neon-orange/30 neon-glow`;
      default: return `${baseClasses} bg-white/5`;
    }
  };

  return (
    <div className="w-full max-w-[350px] mx-auto aspect-[9/16] rounded-[2.5rem] border-[12px] border-[#1a1a1a] overflow-hidden bg-base shadow-[0_0_50px_rgba(0,0,0,0.5)] relative group">
      <div
        className={cn(
          getCardClass(),
          appearance.backgroundType === 'animated' && "animate-pulse"
        )}
        style={{
          ...getBackgroundStyle(),
          fontFamily: getFontFamily(),
        }}
      >
        {/* Avatar with Glow */}
        <div className="relative mb-6">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className={cn(
              "w-24 h-24 border-4 p-1 relative z-10 bg-base",
              appearance.accentColor ? `border-[${appearance.accentColor}]` : "border-neon-orange",
              getAvatarShape()
            )}
            style={{ borderColor: appearance.accentColor || '#ff8800' }}
          >
            <div className={cn("w-full h-full overflow-hidden bg-white/5 flex items-center justify-center text-4xl font-black", getAvatarShape())}
                 style={{ color: appearance.accentColor || '#ff8800' }}>
              {avatarUrl ? (
                <img
                  src={avatarUrl}
                  alt={username}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                displayName?.charAt(0).toUpperCase() || '?'
              )}
            </div>
          </motion.div>
          <div className="absolute inset-0 blur-2xl rounded-full animate-pulse" 
               style={{ backgroundColor: `${appearance.accentColor || '#ff8800'}30` }} />
          <div className="absolute bottom-1 right-1 w-5 h-5 border-4 border-base rounded-full z-20" 
               style={{ backgroundColor: appearance.accentColor || '#ff8800' }} />
        </div>

        <h2 className="text-xl font-black mb-0.5 text-white"
            style={{ color: appearance.accentColor || '#ffffff' }}>
          {displayDisplayName || 'Your Name'}
        </h2>
        <p className="text-white/40 text-[10px] font-bold mb-2 tracking-tight">@{username || 'username'}</p>

        {displayBio && (
          <p className="text-white/60 text-[10px] mb-6 line-clamp-2 px-4 leading-relaxed">
            {displayBio}
          </p>
        )}

        {/* Stats Row */}
        <div className="flex items-center gap-4 mb-8">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/5">
            <Eye size={12} style={{ color: appearance.accentColor || '#ff8800' }} />
            <span className="text-[10px] font-black text-white/60">{views}</span>
          </div>
          {displayLocation && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/5">
              <MapPin size={12} style={{ color: appearance.accentColor || '#ff8800' }} />
              <span className="text-[10px] font-black text-white/60 truncate max-w-[80px]">{displayLocation}</span>
            </div>
          )}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/5">
            <Heart size={12} style={{ color: appearance.accentColor || '#ff8800' }} />
            <span className="text-[10px] font-black text-white/60">{likes}</span>
          </div>
        </div>

        {/* Links */}
        <div className="w-full space-y-2 mb-6">
          {displayLinks.filter(l => l.active).map((link, index) => (
            <motion.a
              key={link.id}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              className={cn(
                "w-full p-3 rounded-xl flex items-center justify-between group transition-all duration-300 border border-white/5",
                appearance.buttonStyle === 'rounded' && "rounded-xl",
                appearance.buttonStyle === 'sharp' && "rounded-none",
                appearance.buttonStyle === 'pill' && "rounded-full",
                appearance.buttonStyle === 'glass' && "rounded-xl glass",
                appearance.buttonStyle === 'outline' && "rounded-xl border-2 bg-transparent",
                appearance.glassmorphism ? "bg-white/5 backdrop-blur-md" : "bg-white/5"
              )}
              style={{ 
                borderColor: appearance.buttonStyle === 'outline' ? appearance.accentColor : undefined,
                color: appearance.accentColor || '#ffffff'
              }}
            >
              <span className="font-bold text-xs text-white/80 group-hover:text-white transition-colors">{link.title}</span>
              <ExternalLink size={12} className="text-white/20 group-hover:text-neon-orange transition-colors" />
            </motion.a>
          ))}
        </div>

        {/* Media Gallery */}
        {media.length > 0 && (
          <div className="w-full mb-6">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-1 h-1 rounded-full" style={{ backgroundColor: appearance.accentColor || '#ff8800' }} />
              <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">Gallery</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {media.slice(0, 6).map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="aspect-square rounded-lg overflow-hidden bg-white/5 border border-white/5 relative group/media"
                >
                  {item.type === 'image' ? (
                    <img
                      src={item.url}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = `https://picsum.photos/seed/${item.id}/100/100`;
                      }}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Video size={16} className="text-white/20" />
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Discord Status */}
        {discordData?.active && (
          <div className="w-full mb-6">
            <div className="bg-white/5 border border-white/5 rounded-2xl p-3 flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full overflow-hidden bg-white/10">
                  <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${username || 'Guest'}`} alt="Discord Avatar" className="w-full h-full" />
                </div>
                <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 border-2 border-base rounded-full" />
              </div>
              <div className="text-left flex-1 min-w-0">
                <p className="text-[10px] font-black text-white truncate">{discordData.username || 'Discord User'}</p>
                <p className="text-[8px] text-white/40 font-bold truncate">{discordData.status || 'Online'}</p>
              </div>
              <div className="w-6 h-6 rounded-lg bg-[#5865F2]/20 flex items-center justify-center text-[#5865F2]">
                <MessageSquare size={12} />
              </div>
            </div>
          </div>
        )}

        {/* Music Player Card - Only show if music is added */}
        {activeTrack && (
          <div className="mt-auto w-full">
            <div className="bg-base border border-white/5 rounded-3xl p-4 flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center relative overflow-hidden group/music"
                     style={{ backgroundColor: `${appearance.accentColor || '#ff8800'}15` }}>
                  <Music size={20} style={{ color: appearance.accentColor || '#ff8800' }} className="relative z-10" />
                  <div className="absolute inset-0 animate-pulse" style={{ backgroundColor: `${appearance.accentColor || '#ff8800'}20` }} />
                </div>
                <div className="text-left flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-black text-white truncate">
                      {activeTrack.title || 'Unknown Track'}
                    </p>
                    <div className="flex gap-0.5">
                      {[1, 2, 3, 4].map(i => (
                        <div key={i} className={cn("w-0.5 rounded-full animate-music-bar", i === 2 && "animation-delay-200", i === 3 && "animation-delay-500")}
                             style={{ height: `${Math.random() * 10 + 5}px`, backgroundColor: appearance.accentColor || '#ff8800' }} />
                      ))}
                    </div>
                  </div>
                  <p className="text-[10px] text-white/30 font-bold truncate">
                    {activeTrack.artist || 'No Artist'}
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full rounded-full w-1/3" style={{ backgroundColor: appearance.accentColor || '#ff8800' }} />
                </div>
                <div className="flex justify-between text-[8px] font-bold text-white/20 uppercase tracking-widest">
                  <span>0:00</span>
                  <span>2:33</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <button className="w-8 h-8 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                        style={{ backgroundColor: appearance.accentColor || '#ff8800', color: '#000' }}>
                  <Pause size={16} fill="currentColor" />
                </button>
                <button className="text-white/20 hover:text-white transition-colors">
                  <Volume2 size={16} />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* View Live Button Overlay */}
      <div className="absolute top-4 right-4 z-20 opacity-0 group-hover:opacity-100 transition-opacity">
        <button 
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/50 backdrop-blur-md border border-white/10 text-[10px] font-black text-white/60 hover:text-white hover:bg-black/70 transition-all"
          onClick={() => window.open(`/${username}`, '_blank')}
        >
          <ExternalLink size={12} /> View live
        </button>
      </div>
    </div>
  );
}
