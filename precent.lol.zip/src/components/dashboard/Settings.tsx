import React, { useState } from 'react';
import { motion } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { NeonButton } from '../ui/NeonButton';
import { Settings as SettingsIcon, Shield, Bell, CreditCard, Trash2, Key, CheckCircle2, AlertTriangle, MessageSquare, X } from 'lucide-react';
import { useSupabase } from '../SupabaseProvider';
import { supabase } from '@/src/lib/supabase';
import { profileService } from '@/src/services/profileService';
import { sendReport } from '@/src/services/reportService';
import { ProUpgradeModal } from '../ui/ProUpgradeModal';

export function Settings() {
  const { profile, user } = useSupabase();
  const [tfaEnabled, setTfaEnabled] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [reportDetails, setReportDetails] = useState('');
  const [isProModalOpen, setIsProModalOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [passwordData, setPasswordData] = useState({
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState(false);

  const handleLogout = async () => {
    try {
      const { error } = await supabase.auth.signOut({ 
        scope: 'global' // Clear session across all tabs/browsers
      });
      
      if (error) {
        console.error('SignOut error:', error);
      }
      
      // Clear any local storage and demo flags
      localStorage.removeItem('demo_mode');
      localStorage.removeItem('sb-' + ((import.meta as any).env?.VITE_SUPABASE_URL?.split('//')[1]?.split('.')[0] || '') + '-auth-token');
      
      // Force redirect to home
      window.location.href = '/';
    } catch (err) {
      console.error('Logout failed:', err);
      // Force clear storage and redirect even if error occurs
      localStorage.removeItem('demo_mode');
      window.location.href = '/';
    }
  };

  const handlePasswordChange = async () => {
    if (!passwordData.oldPassword || !passwordData.newPassword || !passwordData.confirmPassword) {
      setPasswordError('Please fill in all fields');
      return;
    }
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setPasswordError('New passwords do not match');
      return;
    }
    if (passwordData.newPassword.length < 6) {
      setPasswordError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    setPasswordError('');
    try {
      // In a real app with Supabase, we'd use supabase.auth.updateUser({ password: newPassword })
      // For this demo/mock environment, we'll simulate success
      await new Promise(resolve => setTimeout(resolve, 1500));
      setPasswordSuccess(true);
      setPasswordData({ oldPassword: '', newPassword: '', confirmPassword: '' });
      setTimeout(() => {
        setPasswordSuccess(false);
        setIsPasswordModalOpen(false);
      }, 2000);
    } catch (err) {
      setPasswordError('Failed to update password. Please check your old password.');
    } finally {
      setLoading(false);
    }
  };

  const handleReport = async () => {
    if (!reportReason || !reportDetails) return;
    setLoading(true);
    await sendReport(reportReason, reportDetails, user?.email);
    setReportReason('');
    setReportDetails('');
    setLoading(false);
    alert('Report submitted successfully!');
  };

  const handleUpgrade = () => {
    setIsProModalOpen(true);
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500 relative">
      <ProUpgradeModal isOpen={isProModalOpen} onClose={() => setIsProModalOpen(false)} />
      
      <div className="absolute top-0 right-0 hidden lg:block">
        <h2 className="text-[10px] font-black text-white/10 tracking-[0.4em] uppercase">Settings</h2>
      </div>

      <div className="text-center mb-12">
        <h2 className="text-4xl md:text-5xl font-black mb-4">
          Account <span className="text-neon-orange">Settings</span>
        </h2>
        <p className="text-white/60 max-w-2xl mx-auto">
          Manage your security, subscription, and account preferences.
        </p>
      </div>
      
      <div className="grid grid-cols-1 gap-8">
        <GlassCard className="p-8">
          <h3 className="text-xl font-bold mb-8 flex items-center gap-2">
            <Shield size={20} className="text-neon-orange" /> Security
          </h3>
          <div className="space-y-6">
            <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10">
              <div>
                <p className="font-bold flex items-center gap-2">
                  Two-Factor Authentication
                  {tfaEnabled && <CheckCircle2 size={14} className="text-neon-orange" />}
                </p>
                <p className="text-xs text-white/40">Add an extra layer of security to your account.</p>
              </div>
              <NeonButton 
                variant={tfaEnabled ? "outline" : "primary"} 
                size="sm"
                onClick={() => setTfaEnabled(!tfaEnabled)}
              >
                {tfaEnabled ? 'Disable' : 'Enable'}
              </NeonButton>
            </div>
            
            <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10">
              <div>
                <p className="font-bold">Change Password</p>
                <p className="text-xs text-white/40">Update your account password regularly.</p>
              </div>
              <NeonButton variant="outline" size="sm" onClick={() => setIsPasswordModalOpen(true)}>Update</NeonButton>
            </div>
          </div>
        </GlassCard>

        {/* Change Password Modal */}
        {isPasswordModalOpen && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              className="w-full max-w-md"
            >
              <GlassCard className="p-8 space-y-6 relative overflow-hidden">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold flex items-center gap-2">
                    <Key size={20} className="text-neon-orange" /> Update Password
                  </h3>
                  <button 
                    onClick={() => {
                      setIsPasswordModalOpen(false);
                      setPasswordError('');
                      setPasswordSuccess(false);
                    }} 
                    className="text-white/40 hover:text-white"
                  >
                    <X size={24} />
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-white/30 uppercase tracking-widest">Current Password</label>
                    <input 
                      type="password" 
                      value={passwordData.oldPassword}
                      onChange={(e) => setPasswordData({ ...passwordData, oldPassword: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-white/30 uppercase tracking-widest">New Password</label>
                    <input
                      type="password"
                      value={passwordData.newPassword}
                      onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-white/30 uppercase tracking-widest">Confirm New Password</label>
                    <input
                      type="password"
                      value={passwordData.confirmPassword}
                      onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 transition-all"
                    />
                  </div>
                </div>

                {passwordError && (
                  <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-500 text-xs font-bold flex items-center gap-2">
                    <AlertTriangle size={14} /> {passwordError}
                  </div>
                )}

                {passwordSuccess && (
                  <div className="p-3 rounded-lg bg-neon-orange/10 border border-neon-orange/20 text-neon-orange text-xs font-bold flex items-center gap-2">
                    <CheckCircle2 size={14} /> Password updated successfully!
                  </div>
                )}

                <div className="pt-2">
                  <NeonButton 
                    className="w-full" 
                    onClick={handlePasswordChange}
                    disabled={loading || passwordSuccess}
                  >
                    {loading ? 'Updating...' : passwordSuccess ? 'Success!' : 'Update Password'}
                  </NeonButton>
                </div>
              </GlassCard>
            </motion.div>
          </div>
        )}

        <GlassCard className="p-8">
          <h3 className="text-xl font-bold mb-8 flex items-center gap-2">
            <CreditCard size={20} className="text-cyan" /> Subscription
          </h3>
          <div className="p-6 rounded-2xl bg-neon-orange/10 border border-neon-orange/20 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <div className="inline-flex items-center gap-2 px-2 py-1 rounded bg-neon-orange text-black text-[10px] font-black uppercase mb-2">
                Active Plan
              </div>
              <h4 className="text-2xl font-black">{profile?.isPro ? 'Precent Pro' : 'Free Tier'}</h4>
              <p className="text-sm text-white/60">
                {profile?.isPro ? 'Your next billing date is May 3, 2026.' : 'Upgrade to unlock premium features.'}
              </p>
            </div>
            <NeonButton 
              variant={profile?.isPro ? "outline" : "primary"}
              onClick={handleUpgrade}
              disabled={loading || profile?.isPro}
            >
              {profile?.isPro ? 'Manage Billing' : 'Upgrade Now'}
            </NeonButton>
          </div>
        </GlassCard>

        <GlassCard className="p-8">
          <h3 className="text-xl font-bold mb-8 flex items-center gap-2">
            <MessageSquare size={20} className="text-neon-orange" /> Report Issue
          </h3>
          <div className="space-y-4">
            <input
              type="text"
              placeholder="Reason"
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 transition-all"
            />
            <textarea
              placeholder="Details"
              value={reportDetails}
              onChange={(e) => setReportDetails(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 transition-all"
              rows={3}
            />
            <NeonButton onClick={handleReport} disabled={loading || !reportReason || !reportDetails}>
              {loading ? 'Sending...' : 'Submit Report'}
            </NeonButton>
          </div>
        </GlassCard>

        {/* Token Management - Hidden at bottom */}
        <GlassCard className="p-8 border-white/5">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2 text-white/40">
            <Key size={20} /> Login Token
          </h3>
          <p className="text-sm text-white/30 mb-6">
            Your login token allows you to access your account without a password. Keep it secure.
          </p>
          <div className="flex gap-4">
            <NeonButton
              variant="outline"
              onClick={async () => {
                try {
                  const { api } = await import('@/src/lib/api');
                  const result = await api.getToken(profile?.uid);
                  if (result.token) {
                    await navigator.clipboard.writeText(result.token);
                    alert('Token copied to clipboard!');
                  } else {
                    alert('No token found. Please reset to generate one.');
                  }
                } catch (e: any) {
                  alert(e.message || 'Failed to copy token');
                }
              }}
            >
              Copy Token
            </NeonButton>
            <NeonButton
              variant="outline"
              onClick={async () => {
                if (!confirm('Reset your login token? Your old token will stop working.')) return;
                try {
                  const { api } = await import('@/src/lib/api');
                  const result = await api.resetToken(profile?.uid);
                  if (result.token) {
                    await navigator.clipboard.writeText(result.token);
                    alert('Token reset and copied to clipboard!');
                  }
                } catch (e: any) {
                  alert(e.message || 'Failed to reset token');
                }
              }}
            >
              Reset Token
            </NeonButton>
          </div>
        </GlassCard>

        <GlassCard className="p-8 border-red-500/20">
          <h3 className="text-xl font-bold mb-4 text-red-500 flex items-center gap-2">
            <Trash2 size={20} /> Danger Zone
          </h3>
          <p className="text-sm text-white/40 mb-8">
            Once you delete your account, there is no going back. Please be certain.
          </p>
          
          {!showDeleteConfirm ? (
            <button 
              onClick={() => setShowDeleteConfirm(true)}
              className="px-6 py-3 rounded-xl bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500 hover:text-white transition-all duration-300 font-bold"
            >
              Delete Account
            </button>
          ) : (
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-2 text-red-500 text-sm font-bold">
                <AlertTriangle size={16} /> Are you absolutely sure?
              </div>
              <div className="flex gap-4">
                <NeonButton variant="outline" className="flex-1" onClick={() => setShowDeleteConfirm(false)}>Cancel</NeonButton>
                <button className="flex-1 px-6 py-3 rounded-xl bg-red-600 text-white font-bold hover:bg-red-700 transition-all">
                  Yes, Delete Everything
                </button>
              </div>
            </div>
          )}
        </GlassCard>
      </div>
    </div>
  );
}
