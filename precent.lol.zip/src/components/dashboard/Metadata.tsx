import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { FileText, Clock, Globe, Monitor, ShieldCheck, Calendar, Hash, User } from 'lucide-react';
import { useSupabase } from '../SupabaseProvider';
import { cn } from '@/src/lib/utils';

export function Metadata() {
  const { profile, user } = useSupabase();

  const metadataItems = [
    { 
      label: 'User ID', 
      value: profile?.uid || 'N/A', 
      icon: <Hash size={18} />,
      color: 'text-neon-orange'
    },
    { 
      label: 'Account Created', 
      value: profile?.createdat ? new Date(profile.createdat).toLocaleDateString() : 'N/A', 
      icon: <Calendar size={18} />,
      color: 'text-cyan'
    },
    { 
      label: 'Last Login', 
      value: profile?.metadata?.lastLogin ? new Date(profile.metadata.lastLogin).toLocaleString() : new Date().toLocaleString(), 
      icon: <Clock size={18} />,
      color: 'text-purple-500'
    },
    { 
      label: 'Email Address', 
      value: user?.email || 'N/A', 
      icon: <Globe size={18} />,
      color: 'text-amber-500'
    },
    { 
      label: 'Device Type', 
      value: profile?.metadata?.device || 'Desktop (Chrome/macOS)', 
      icon: <Monitor size={18} />,
      color: 'text-neon-orange'
    },
    { 
      label: 'Account Status', 
      value: profile?.isPro ? 'Premium (Pro)' : 'Standard (Free)', 
      icon: <ShieldCheck size={18} />,
      color: profile?.isPro ? 'text-neon-orange' : 'text-white/40'
    }
  ];

  return (
    <div className="space-y-8 max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500 relative">
      <div className="absolute top-0 right-0 hidden lg:block">
        <h2 className="text-[10px] font-black text-white/10 tracking-[0.4em] uppercase">System Information</h2>
      </div>

      <div className="text-center mb-12">
        <h2 className="text-4xl md:text-5xl font-black mb-4">
          Account <span className="text-neon-orange">Metadata</span>
        </h2>
        <p className="text-white/60 max-w-2xl mx-auto">
          System information and security logs for your account.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {metadataItems.map((item, index) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <GlassCard className="p-6 flex items-center gap-4 bg-white/5 border-white/5 hover:border-white/10 transition-all group">
              <div className={cn("w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center transition-transform group-hover:scale-110", item.color)}>
                {item.icon}
              </div>
              <div className="min-w-0">
                <p className="text-[10px] font-black text-white/30 uppercase tracking-widest mb-1">{item.label}</p>
                <p className="text-sm font-bold text-white truncate">{item.value}</p>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      <GlassCard className="p-8 space-y-6">
        <div className="flex items-center gap-3 mb-4">
          <ShieldCheck size={20} className="text-neon-orange" />
          <h3 className="text-xl font-bold">Security Log</h3>
        </div>
        
        <div className="space-y-4">
          {[
            { event: 'Profile Updated', time: '2 hours ago', status: 'Success' },
            { event: 'Password Changed', time: '1 day ago', status: 'Success' },
            { event: 'Login from New Device', time: '3 days ago', status: 'Verified' },
            { event: 'Account Created', time: '5 days ago', status: 'Success' },
          ].map((log, i) => (
            <div key={i} className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5 text-xs">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-neon-orange" />
                <span className="font-bold">{log.event}</span>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-white/20">{log.time}</span>
                <span className="text-neon-orange font-black uppercase tracking-widest text-[10px]">{log.status}</span>
              </div>
            </div>
          ))}
        </div>
      </GlassCard>

      <div className="text-center py-8">
        <p className="text-[10px] font-black text-white/10 uppercase tracking-[0.5em]">End of Metadata Report</p>
      </div>
    </div>
  );
}
