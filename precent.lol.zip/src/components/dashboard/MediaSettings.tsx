import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { NeonButton } from '../ui/NeonButton';
import { Upload, Image as ImageIcon, Video, File, Trash2, Plus, Loader2, Save, CheckCircle2, Crown } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import { useSupabase } from '../SupabaseProvider';
import { profileService } from '@/src/services/profileService';
import { MediaItem } from '@/src/types';
import { showToast } from '@/src/lib/toast';

export function MediaSettings() {
  const { profile, setProfile, refreshProfile } = useSupabase();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [uploading, setUploading] = useState(false);

  const media = profile?.media || [];

  const updateGlobalProfile = (newMedia: MediaItem[]) => {
    if (profile) {
      setProfile({
        ...profile,
        media: newMedia
      });
    }
  };

  const onDrop = async (acceptedFiles: File[]) => {
    if (!profile?.uid) {
      showToast('Please wait for profile to load', 'warning');
      return;
    }
    setUploading(true);
    try {
      const newItems: MediaItem[] = acceptedFiles.map(file => ({
        id: Math.random().toString(36).substr(2, 9),
        type: file.type.startsWith('video') ? 'video' : 'image',
        url: URL.createObjectURL(file),
        name: file.name
      }));

      const newMedia = [...media, ...newItems];
      await profileService.updateProfile(profile.uid, {
        media: newMedia
      });
      await refreshProfile();

      updateGlobalProfile(newMedia);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
      showToast('Media uploaded successfully!', 'success');
    } catch (err) {
      console.error(err);
      showToast('Failed to upload media', 'error');
    } finally {
      setUploading(false);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.png', '.gif'],
      'video/*': ['.mp4', '.webm']
    }
  } as any);

  const handleDeleteMedia = async (id: string) => {
    setLoading(true);
    try {
      const newMedia = media.filter(m => m.id !== id);
      await profileService.updateProfile(profile!.uid, {
        media: newMedia
      });
      await refreshProfile();
      updateGlobalProfile(newMedia);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-12 max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700 relative">
      {/* Background Accents */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-neon-orange/5 blur-[120px] rounded-full pointer-events-none" />
      
      <div className="text-center space-y-4 relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-neon-orange text-[10px] font-black uppercase tracking-[0.2em] backdrop-blur-md">
          <ImageIcon size={12} className="fill-neon-orange" />
          <span>Media Library</span>
        </div>
        <h2 className="text-5xl md:text-7xl font-black tracking-tighter leading-[0.9]">
          Media <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-orange via-white to-neon-orange bg-[length:200%_auto] animate-gradient-x">Library</span>
        </h2>
        <p className="text-white/40 max-w-2xl mx-auto font-medium">
          Upload and manage your images and videos.
        </p>
        <div className="flex justify-center h-6">
          {success && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-neon-orange text-[10px] font-black uppercase tracking-widest flex items-center gap-2"
            >
              <CheckCircle2 size={14} /> SETTINGS SAVED
            </motion.div>
          )}
        </div>
      </div>
      
      <GlassCard className="p-8">
        <div 
          {...getRootProps()} 
          className={`border-2 border-dashed rounded-3xl p-12 text-center transition-all duration-300 cursor-pointer
            ${isDragActive ? 'border-neon-orange bg-neon-orange/5' : 'border-white/10 hover:border-white/20 bg-white/5'}`}
        >
          <input {...getInputProps()} />
          <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mx-auto mb-6">
            {uploading ? (
              <Loader2 size={32} className="text-neon-orange animate-spin" />
            ) : (
              <Upload size={32} className={isDragActive ? 'text-neon-orange' : 'text-white/20'} />
            )}
          </div>
          <h3 className="text-xl font-bold mb-2">
            {uploading ? 'Uploading...' : (isDragActive ? 'Drop files here' : 'Upload Media')}
          </h3>
          <p className="text-white/40 mb-8 max-w-xs mx-auto">
            Drag and drop images or videos, or click to browse your files.
          </p>
          <NeonButton variant="outline" disabled={uploading}>Browse Files</NeonButton>
        </div>
      </GlassCard>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {media.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            className="aspect-square glass rounded-2xl overflow-hidden relative group"
          >
            {item.type === 'image' ? (
              <img 
                src={item.url} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  // Fallback for broken URLs
                  (e.target as HTMLImageElement).src = `https://picsum.photos/seed/${item.id}/400/400`;
                }}
              />
            ) : (
              <div className="w-full h-full bg-black/40 flex items-center justify-center">
                <Video size={32} className="text-white/20" />
              </div>
            )}
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
              <button 
                onClick={() => handleDeleteMedia(item.id)}
                className="p-2 rounded-lg bg-red-500/20 hover:bg-red-500 text-red-500 hover:text-white transition-all"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </motion.div>
        ))}

        {media.length === 0 && !uploading && (
          <div className="col-span-full py-20 text-center glass rounded-3xl border-dashed border-2 border-white/5">
            <ImageIcon size={48} className="text-white/10 mx-auto mb-4" />
            <p className="text-white/30 text-sm">Your media library is empty.</p>
          </div>
        )}
      </div>
    </div>
  );
}
