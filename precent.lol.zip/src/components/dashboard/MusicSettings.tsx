import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { NeonButton } from '../ui/NeonButton';
import { Music as MusicIcon, Play, Pause, SkipBack, SkipForward, Volume2, Plus, Trash2, Loader2, Music2, CheckCircle2, Crown, Upload, X } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { useSupabase } from '../SupabaseProvider';
import { profileService } from '@/src/services/profileService';
import { MusicTrack } from '@/src/types';
import { showToast } from '@/src/lib/toast';

export function MusicSettings() {
  const { profile, setProfile, refreshProfile } = useSupabase();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [newTrack, setNewTrack] = useState({ title: '', artist: '', file: null as File | null });
  const [showAddModal, setShowAddModal] = useState(false);
  const [playingTrack, setPlayingTrack] = useState<string | null>(null);
  const [audioProgress, setAudioProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const tracks = profile?.music || [];

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
      }
    };
  }, []);

  const playTrack = (track: MusicTrack) => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    if (track.url) {
      const audio = new Audio(track.url);
      audioRef.current = audio;
      audio.play().catch(() => showToast('Cannot play this audio file', 'error'));
      setPlayingTrack(track.id);
      audio.addEventListener('timeupdate', () => {
        if (audio.duration) {
          setAudioProgress((audio.currentTime / audio.duration) * 100);
        }
      });
      audio.addEventListener('ended', () => {
        setPlayingTrack(null);
        setAudioProgress(0);
      });
    }
  };

  const pauseTrack = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setPlayingTrack(null);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    if (file) {
      const title = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
      setNewTrack({ title: title.charAt(0).toUpperCase() + title.slice(1), artist: '', file });
    }
  };

  const handleAddTrack = async () => {
    if (!newTrack.file) {
      showToast('Please select an audio file', 'warning');
      return;
    }
    if (!profile?.uid) {
      showToast('Please wait for profile to load', 'warning');
      return;
    }
    setLoading(true);
    try {
      const uid = profile.uid;
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = e.target?.result as string;
        const track: MusicTrack = {
          id: Math.random().toString(36).substr(2, 9),
          title: newTrack.title || 'Unknown Track',
          artist: newTrack.artist || 'Unknown Artist',
          url: base64,
          active: tracks.length === 0
        };
        const newMusic = [...tracks, track];
        await profileService.updateProfile(uid, { music: newMusic });
        await refreshProfile();
        setNewTrack({ title: '', artist: '', file: null });
        setShowAddModal(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
        showToast('Track added successfully!', 'success');
      };
      reader.readAsDataURL(newTrack.file);
    } catch (err) {
      console.error(err);
      showToast('Failed to add track', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteTrack = async (id: string) => {
    const newMusic = tracks.filter(t => t.id !== id);
    await profileService.updateProfile(profile!.uid, { music: newMusic });
    await refreshProfile();
    if (playingTrack === id) {
      pauseTrack();
    }
    showToast('Track removed', 'success');
  };

  const handleSetActive = async (id: string) => {
    const newMusic = tracks.map(t => ({ ...t, active: t.id === id }));
    await profileService.updateProfile(profile!.uid, { music: newMusic });
    await refreshProfile();
    showToast('Active track updated', 'success');
  };

  return (
    <div className="space-y-12 max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700 relative">
      <div className="text-center space-y-4 relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-neon-orange text-[10px] font-black uppercase tracking-[0.2em] backdrop-blur-md">
          <MusicIcon size={12} className="fill-neon-orange" />
          <span>Music Settings</span>
        </div>
        <h2 className="text-5xl md:text-7xl font-black tracking-tighter leading-[0.9]">
          Music <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-orange via-white to-neon-orange bg-[length:200%_auto] animate-gradient-x">Player</span>
        </h2>
        <p className="text-white/40 max-w-2xl mx-auto font-medium">Add music tracks to your profile for visitors to enjoy.</p>
      </div>

      <GlassCard className="p-8">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold flex items-center gap-2"><Music2 size={20} className="text-neon-orange" /> Your Tracks ({tracks.length})</h3>
          <NeonButton size="sm" onClick={() => setShowAddModal(true)}><Plus size={14} className="mr-2" />Add Track</NeonButton>
        </div>

        {tracks.length === 0 ? (
          <div className="text-center py-16">
            <MusicIcon size={48} className="text-white/10 mx-auto mb-4" />
            <p className="text-white/30 font-bold mb-2">No tracks yet</p>
            <p className="text-white/20 text-sm">Add your first track to get started</p>
          </div>
        ) : (
          <div className="space-y-3">
            {tracks.map(track => (
              <div key={track.id} className={cn("flex items-center gap-4 p-4 rounded-xl border transition-all", track.active ? "bg-neon-orange/10 border-neon-orange/30" : "bg-white/5 border-white/10")}>
                <button onClick={() => playingTrack === track.id ? pauseTrack() : playTrack(track)} className="w-10 h-10 rounded-full bg-neon-orange flex items-center justify-center text-black hover:scale-110 transition-transform shrink-0">
                  {playingTrack === track.id ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" className="ml-0.5" />}
                </button>
                <div className="flex-1 min-w-0">
                  <p className="font-bold truncate">{track.title}</p>
                  <p className="text-xs text-white/40">{track.artist}</p>
                </div>
                {track.active && <span className="px-2 py-0.5 rounded bg-neon-orange/20 text-neon-orange text-[9px] font-black uppercase">Active</span>}
                <div className="flex items-center gap-2">
                  <button onClick={() => handleSetActive(track.id)} className="p-2 text-white/30 hover:text-neon-orange transition-colors"><Music2 size={14} /></button>
                  <button onClick={() => handleDeleteTrack(track.id)} className="p-2 text-white/30 hover:text-red-400 transition-colors"><Trash2 size={14} /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </GlassCard>

      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/80 backdrop-blur-md">
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="w-full max-w-md">
              <GlassCard className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold">Add New Track</h3>
                  <button onClick={() => setShowAddModal(false)} className="text-white/40 hover:text-white"><X size={20} /></button>
                </div>
                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-bold text-white/30 uppercase mb-1 block">Audio File (MP3/WAV)</label>
                    <div className="relative">
                      <input ref={fileInputRef} type="file" accept="audio/*" onChange={handleFileSelect} className="hidden" />
                      <button onClick={() => fileInputRef.current?.click()} className="w-full p-4 rounded-xl border border-white/10 bg-white/5 text-sm font-bold hover:bg-white/10 transition-all flex items-center justify-center gap-2">
                        <Upload size={16} />
                        {newTrack.file ? newTrack.file.name : 'Choose File'}
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-white/30 uppercase mb-1 block">Track Title</label>
                    <input type="text" value={newTrack.title} onChange={(e) => setNewTrack({ ...newTrack, title: e.target.value })} placeholder="Track name" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-neon-orange/50" />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-white/30 uppercase mb-1 block">Artist</label>
                    <input type="text" value={newTrack.artist} onChange={(e) => setNewTrack({ ...newTrack, artist: e.target.value })} placeholder="Artist name" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-neon-orange/50" />
                  </div>
                </div>
                <NeonButton onClick={handleAddTrack} disabled={loading || !newTrack.file} className="w-full">
                  {loading ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} className="mr-2" />}
                  {loading ? 'Adding...' : 'Add Track'}
                </NeonButton>
              </GlassCard>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
