import { Feedback } from './Feedback';
import { X } from 'lucide-react';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function FeedbackModal({ isOpen, onClose }: FeedbackModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-base/95 backdrop-blur-xl">
      <div className="w-full h-full max-w-6xl mx-auto overflow-y-auto relative p-6 md:p-12 custom-scrollbar">
        <button onClick={onClose} className="absolute top-6 right-6 text-white/40 hover:text-white z-10 bg-white/5 p-2 rounded-full hover:bg-white/10 transition-colors">
          <X size={24} />
        </button>
        <Feedback />
      </div>
    </div>
  );
}
