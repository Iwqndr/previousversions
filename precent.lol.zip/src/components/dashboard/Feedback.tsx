import React, { useState } from 'react';
import { motion } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { NeonButton } from '../ui/NeonButton';
import { MessageSquare, Bug, Sparkles, Send, CheckCircle2, AlertCircle } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { useSupabase } from '../SupabaseProvider';
import { feedbackService } from '@/src/services/feedbackService';

const categories = [
  { id: 'bug', label: 'Bug Report', icon: <Bug size={18} />, color: 'text-red-500' },
  { id: 'feature', label: 'Feature Request', icon: <Sparkles size={18} />, color: 'text-neon-orange' },
  { id: 'general', label: 'General Feedback', icon: <MessageSquare size={18} />, color: 'text-neon-orange' },
];

export function Feedback() {
  const { profile, user } = useSupabase();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [category, setCategory] = useState<'bug' | 'feature' | 'general'>('general');
  const [message, setMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    setLoading(true);
    setError(null);

    try {
      await feedbackService.submitFeedback({
        uid: profile?.uid || user?.uid || 'anonymous',
        username: profile?.username || 'anonymous',
        email: profile?.email || user?.email || 'anonymous',
        category,
        message: message.trim(),
      });
      setSuccess(true);
      setMessage('');
      setTimeout(() => setSuccess(false), 5000);
    } catch (err) {
      console.error('Failed to submit feedback:', err);
      setError('Failed to submit feedback. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500 relative">
      <div className="absolute top-0 right-0 hidden lg:block">
        <h2 className="text-[10px] font-black text-white/10 tracking-[0.4em] uppercase">Feedback</h2>
      </div>

      <div className="text-center mb-12">
        <h2 className="text-4xl md:text-5xl font-black mb-4">
          Help Us <span className="text-neon-orange">Improve</span>
        </h2>
        <p className="text-white/60 max-w-2xl mx-auto">
          Your feedback helps us build a better platform for everyone.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <GlassCard className="p-8">
            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="space-y-4">
                <label className="text-xs font-black text-white/30 uppercase tracking-widest">Select Category</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setCategory(cat.id as any)}
                      className={cn(
                        "flex items-center gap-3 p-4 rounded-xl border transition-all duration-300",
                        category === cat.id
                          ? "bg-white/10 border-neon-orange/30 text-neon-orange"
                          : "bg-white/5 border-white/10 text-white/40 hover:text-white hover:bg-white/10"
                      )}
                    >
                      <span className={cn(category === cat.id ? "text-neon-orange" : cat.color)}>
                        {cat.icon}
                      </span>
                      <span className="text-xs font-bold">{cat.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-xs font-black text-white/30 uppercase tracking-widest">Your Message</label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tell us what's on your mind..."
                  className="w-full h-48 bg-white/5 border border-white/10 rounded-2xl p-6 text-sm focus:outline-none focus:border-neon-orange/50 transition-all resize-none"
                  required
                />
              </div>

              <div className="flex items-center justify-between gap-4">
                {error && (
                  <div className="flex items-center gap-2 text-red-500 text-xs font-bold">
                    <AlertCircle size={14} />
                    {error}
                  </div>
                )}
                {success && (
                  <div className="flex items-center gap-2 text-neon-orange text-xs font-bold animate-in fade-in slide-in-from-left-2">
                    <CheckCircle2 size={14} />
                    Feedback submitted successfully!
                  </div>
                )}
                <div className="flex-1" />
                <NeonButton 
                  type="submit" 
                  disabled={loading || !message.trim()}
                  className="px-8"
                >
                  {loading ? 'Sending...' : (
                    <span className="flex items-center gap-2">
                      <Send size={16} /> Send Feedback
                    </span>
                  )}
                </NeonButton>
              </div>
            </form>
          </GlassCard>
        </div>

        <div className="space-y-6">
          <GlassCard className="p-6 border-neon-orange/20">
            <h3 className="font-black text-sm mb-4 uppercase tracking-widest text-neon-orange">Why Feedback?</h3>
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center shrink-0">
                  <Bug size={16} className="text-red-500" />
                </div>
                <div>
                  <h4 className="text-xs font-bold mb-1">Squash Bugs</h4>
                  <p className="text-[10px] text-white/40 leading-relaxed">Found something broken? Let us know so we can fix it immediately.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center shrink-0">
                  <Sparkles size={16} className="text-neon-orange" />
                </div>
                <div>
                  <h4 className="text-xs font-bold mb-1">Request Features</h4>
                  <p className="text-[10px] text-white/40 leading-relaxed">Have a cool idea? We're always looking for new features to add.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center shrink-0">
                  <MessageSquare size={16} className="text-neon-orange" />
                </div>
                <div>
                  <h4 className="text-xs font-bold mb-1">General Thoughts</h4>
                  <p className="text-[10px] text-white/40 leading-relaxed">Just want to say hi or give us some general feedback? We're all ears.</p>
                </div>
              </div>
            </div>
          </GlassCard>

          <GlassCard className="p-6 bg-neon-orange/5 border-neon-orange/10">
            <h3 className="font-black text-xs mb-2 uppercase tracking-widest">Join the Community</h3>
            <p className="text-[10px] text-white/50 mb-4">Connect with other creators and get help in real-time.</p>
            <NeonButton variant="outline" size="sm" className="w-full text-[10px]">
              Join Discord
            </NeonButton>
          </GlassCard>
        </div>
      </div>
    </div>
  );
}
