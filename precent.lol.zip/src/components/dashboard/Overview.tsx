import { useState } from 'react';
import { motion } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Eye, TrendingUp, Zap, ExternalLink, Trophy, Music, ImageIcon, Users, Link as LinkIcon, ArrowUpRight, User, Palette } from 'lucide-react';
import { useSupabase } from '../SupabaseProvider';
import { cn } from '@/src/lib/utils';

interface OverviewProps {
  setActiveTab: (tab: string) => void;
}

const chartData = [
  { name: 'Mar 5', views: 0 },
  { name: 'Mar 10', views: 0 },
  { name: 'Mar 15', views: 0 },
  { name: 'Mar 20', views: 0 },
  { name: 'Mar 25', views: 0 },
  { name: 'Mar 30', views: 1 },
  { name: 'Apr 3', views: 0 },
];

export function Overview({ setActiveTab }: OverviewProps) {
  const { profile } = useSupabase();

  return (
    <div className="space-y-12 animate-in fade-in duration-700 relative">
      {/* Background Accents */}
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-neon-orange/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute top-1/2 -right-24 w-96 h-96 bg-cyan/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 relative z-10">
        <div className="space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-neon-orange text-[10px] font-black uppercase tracking-[0.2em] backdrop-blur-md">
            <Zap size={12} className="fill-neon-orange" />
            <span>Creator Dashboard</span>
          </div>
          <h2 className="text-5xl md:text-7xl font-black tracking-tighter leading-[0.9]">
            Welcome back, <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-orange via-white to-neon-orange bg-[length:200%_auto] animate-gradient-x">
              {profile?.displayName || profile?.username || 'Creator'}
            </span>
          </h2>
          <p className="text-white/40 max-w-md font-medium">
            Your profile is growing. Here's how your page is performing across the platform.
          </p>
        </div>
        <button
          onClick={() => window.open(`/${profile?.username}`, '_blank')}
          className="group relative flex items-center gap-3 px-8 py-4 rounded-2xl bg-white text-black font-black text-xs uppercase tracking-widest hover:bg-neon-orange transition-all shadow-[0_0_30px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(255,136,0,0.3)] overflow-hidden"
        >
          <span className="relative z-10 flex items-center gap-2">
            <ExternalLink size={16} /> View Live Profile
          </span>
          <div className="absolute inset-0 bg-neon-orange translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
        </button>
      </div>

      {/* Pro Upgrade Banner */}
      {!profile?.isPro && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-[2.5rem] p-1 bg-gradient-to-r from-neon-orange/20 via-white/5 to-cyan/20 group"
        >
          <div className="relative bg-[#050505] rounded-[2.4rem] p-8 md:p-10 flex flex-col md:flex-row md:items-center justify-between gap-8 overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(255,136,0,0.08),transparent_70%)]" />
            <div className="relative z-10 flex items-center gap-8">
              <div className="w-20 h-20 rounded-3xl bg-neon-orange flex items-center justify-center text-black shadow-[0_0_40px_rgba(255,136,0,0.3)] group-hover:scale-110 transition-transform duration-500">
                <Zap size={40} fill="currentColor" />
              </div>
              <div>
                <h3 className="text-3xl font-black text-white tracking-tight">Upgrade to <span className="text-neon-orange">Pro Plan</span></h3>
                <p className="text-white/40 font-bold mt-2 max-w-md leading-relaxed">
                  Unlock animated backgrounds, custom domains, and advanced analytics to grow your audience.
                </p>
              </div>
            </div>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('open-pro-modal'))}
              className="relative z-10 px-10 py-5 rounded-2xl bg-neon-orange text-black font-black text-xs uppercase tracking-[0.2em] hover:scale-105 transition-all shadow-[0_0_30px_rgba(255,136,0,0.2)]"
            >
              Upgrade to Pro
            </button>
          </div>
        </motion.div>
      )}

      {/* Top Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          { label: 'Total Views', value: profile?.analytics?.views || 0, icon: Eye, color: 'text-neon-orange', bg: 'bg-neon-orange/10' },
          { label: 'Click Rate', value: '0%', icon: TrendingUp, color: 'text-cyan', bg: 'bg-cyan/10' },
          { label: 'Total Links', value: profile?.links?.length || 0, icon: LinkIcon, color: 'text-white', bg: 'bg-white/10' },
        ].map((stat, i) => (
          <GlassCard key={i} className="p-8 bg-surface/50 border-white/5 flex items-center justify-between group hover:border-white/10 transition-all">
            <div>
              <p className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em] mb-2">{stat.label}</p>
              <h3 className="text-4xl font-black tracking-tighter group-hover:text-neon-orange transition-colors">{stat.value}</h3>
            </div>
            <div className={cn("w-16 h-16 rounded-2xl flex items-center justify-center transition-all duration-500 group-hover:scale-110", stat.bg, stat.color)}>
              <stat.icon size={32} />
            </div>
          </GlassCard>
        ))}
      </div>

      {/* Main Chart Section */}
      <GlassCard className="p-10 bg-surface/50 border-white/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-neon-orange/5 blur-[100px] rounded-full pointer-events-none" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12 relative z-10">
          <div>
            <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-white/20 mb-2">Profile Traffic</h3>
            <h4 className="text-2xl font-black">Performance Trends</h4>
          </div>
          <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/5">
            {['1D', '1W', '1M', '1Y'].map((range) => (
              <button 
                key={range}
                className={cn(
                  "px-6 py-2 rounded-lg text-[10px] font-black uppercase transition-all",
                  range === '1M' ? "bg-neon-orange text-black shadow-[0_0_15px_rgba(255,136,0,0.3)]" : "text-white/30 hover:text-white hover:bg-white/5"
                )}
              >
                {range}
              </button>
            ))}
          </div>
        </div>

        <div className="h-[350px] w-full relative z-10" style={{ width: '100%', height: '350px' }}>
          {typeof window !== 'undefined' && window.innerWidth > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ff8800" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#ff8800" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff03" vertical={false} />
                <XAxis
                  dataKey="name"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#ffffff15', fontSize: 10, fontWeight: 'black' }}
                  dy={15}
                />
                <YAxis hide />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0a0a0a',
                    border: '1px solid rgba(255,255,255,0.05)',
                    borderRadius: '20px',
                    padding: '12px 16px',
                    boxShadow: '0 10px 30px rgba(0,0,0,0.5)'
                  }}
                  itemStyle={{ color: '#ff8800', fontSize: '12px', fontWeight: 'black' }}
                  cursor={{ stroke: '#ff8800', strokeWidth: 1, strokeDasharray: '4 4' }}
                />
                <Area
                  type="monotone"
                  dataKey="views"
                  stroke="#ff8800"
                  strokeWidth={4}
                  fillOpacity={1}
                  fill="url(#colorViews)"
                  animationDuration={2500}
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="w-full h-full flex items-center justify-center text-white/20">
              Loading chart...
            </div>
          )}
        </div>
      </GlassCard>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'User Profile', icon: User, tab: 'profile', desc: 'Edit profile' },
          { label: 'Appearance', icon: Palette, tab: 'appearance', desc: 'Theme settings' },
          { label: 'Link Settings', icon: LinkIcon, tab: 'links', desc: 'Manage links' },
          { label: 'Media Library', icon: ImageIcon, tab: 'media', desc: 'Manage assets' },
        ].map((action, i) => (
          <button 
            key={i}
            onClick={() => setActiveTab(action.tab)}
            className="p-8 rounded-3xl bg-surface/50 border border-white/5 hover:border-neon-orange/30 transition-all flex flex-col items-start gap-4 group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
              <ArrowUpRight size={20} className="text-neon-orange" />
            </div>
            <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-white/40 group-hover:text-neon-orange group-hover:bg-neon-orange/10 transition-all duration-500">
              <action.icon size={24} />
            </div>
            <div className="text-left">
              <span className="block text-[10px] font-black uppercase tracking-[0.2em] text-white/20 mb-1">{action.desc}</span>
              <span className="text-sm font-black uppercase tracking-widest text-white/60 group-hover:text-white transition-colors">{action.label}</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
