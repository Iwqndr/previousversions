import { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { Users, MessageSquare, Heart, Share2, ExternalLink, Search, Image as ImageIcon, Send, X } from 'lucide-react';
import { NeonButton } from '../ui/NeonButton';
import { useSupabase } from '../SupabaseProvider';
import { communityService } from '@/src/services/communityService';
import { CommunityPost } from '@/src/types';
import { showToast } from '@/src/lib/toast';

export function Community() {
  const { profile, user } = useSupabase();
  const [newPost, setNewPost] = useState('');
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadPosts = async () => {
      try {
        const fetchedPosts = await communityService.fetchPosts();
        // Filter out bot messages (e.g., messages containing "bot" or "spam")
        const filteredPosts = fetchedPosts.filter(post =>
          !post.content.toLowerCase().includes('bot') &&
          !post.content.toLowerCase().includes('spam')
        );
        setPosts(filteredPosts);
      } catch (error) {
        console.error('Error fetching posts:', error);
        showToast('Failed to load community posts', 'error');
      }
    };
    loadPosts();
  }, []);

  const handlePost = async () => {
    if (!newPost.trim() || !profile) {
      showToast('Please enter a message to post', 'warning');
      return;
    }
    setLoading(true);
    try {
      await communityService.createPost({
        uid: profile.uid,
        username: profile.username,
        avatar: profile.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile.username}`,
        content: newPost.trim(),
      });
      setNewPost('');
      showToast('Post created successfully!', 'success');
      // Refresh posts
      const fetchedPosts = await communityService.fetchPosts();
      setPosts(fetchedPosts.filter(post =>
        !post.content.toLowerCase().includes('bot') &&
        !post.content.toLowerCase().includes('spam')
      ));
    } catch (error) {
      console.error('Error creating post:', error);
      showToast('Failed to create post. Please try again.', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500 relative">
      <div className="absolute top-0 right-0 hidden lg:block">
        <h2 className="text-[10px] font-black text-white/10 tracking-[0.4em] uppercase">Community</h2>
      </div>

      <div className="text-center mb-12">
        <h2 className="text-4xl md:text-5xl font-black mb-4">
          Community <span className="text-neon-orange">Feed</span>
        </h2>
        <p className="text-white/60 max-w-2xl mx-auto mb-6">
          Connect with other creators and see what's trending.
        </p>
        <div className="flex justify-center">
          <div className="relative group w-full max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-neon-orange transition-colors" size={18} />
            <input
              type="text"
              placeholder="Search creators..."
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-neon-orange/50 transition-all"
            />
          </div>
        </div>
      </div>

      {/* Create Post Section */}
      <GlassCard className="p-6 border-neon-orange/30 relative overflow-hidden group mb-8">
        <div className="absolute inset-0 bg-gradient-to-r from-neon-orange/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        <div className="relative z-10 flex gap-4">
          <div className="w-12 h-12 rounded-full border-2 border-neon-orange/30 p-0.5 shrink-0">
            <img src={profile?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile?.username || 'Guest'}`} alt="Avatar" className="w-full h-full rounded-full object-cover bg-white/5" />
          </div>
          <div className="flex-1">
            <textarea
              value={newPost}
              onChange={(e) => setNewPost(e.target.value)}
              placeholder="What's on your mind? Share an update or ask for feedback..."
              className="w-full bg-transparent border-none text-white placeholder:text-white/30 focus:outline-none resize-none h-20"
            />
            <div className="flex items-center justify-between pt-4 border-t border-white/10 mt-2">
              <button
                onClick={() => showToast('Sorry, image uploader is still a WIP!', 'info')}
                className="p-2 rounded-lg text-white/40 hover:text-neon-orange hover:bg-neon-orange/10 transition-all cursor-pointer"
              >
                <ImageIcon size={18} />
              </button>
              <NeonButton size="sm" disabled={!newPost.trim() || loading} onClick={handlePost}>
                <Send size={14} className="mr-2" /> {loading ? 'Posting...' : 'Post'}
              </NeonButton>
            </div>
          </div>
        </div>
      </GlassCard>

      <div className="grid grid-cols-1 gap-6">
        {posts.map((post, index) => (
          <motion.div
            key={post.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <GlassCard className="p-6 hover:border-white/20 transition-all">
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-full border-2 border-neon-orange/30 p-0.5 shrink-0">
                  <img src={post.avatar} alt={post.username} className="w-full h-full rounded-full object-cover bg-white/5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h3 className="font-bold text-white hover:text-neon-orange cursor-pointer transition-colors">{post.username}</h3>
                      <p className="text-[10px] text-white/30 font-bold uppercase tracking-widest">{new Date(post.createdat || post.createdAt || Date.now()).toLocaleDateString()}</p>
                    </div>
                    <NeonButton variant="ghost" size="sm">
                      <ExternalLink size={14} />
                    </NeonButton>
                  </div>
                  <p className="text-white/70 mb-6 leading-relaxed">{post.content}</p>
                  {post.mediaUrl && (
                    <div className="mb-6 rounded-xl overflow-hidden border border-white/10">
                      {post.mediaType === 'image' ? (
                        <img src={post.mediaUrl} alt="Post media" className="w-full h-auto" />
                      ) : (
                        <video src={post.mediaUrl} controls className="w-full h-auto" />
                      )}
                    </div>
                  )}
                  <div className="flex items-center gap-6">
                    <button className="flex items-center gap-2 text-white/40 hover:text-pink-500 transition-colors group">
                      <Heart size={18} className="group-hover:fill-pink-500" />
                      <span className="text-xs font-bold">{post.likes}</span>
                    </button>
                    <button className="flex items-center gap-2 text-white/40 hover:text-cyan transition-colors">
                      <MessageSquare size={18} />
                      <span className="text-xs font-bold">{post.comments}</span>
                    </button>
                    <button className="flex items-center gap-2 text-white/40 hover:text-neon-orange transition-colors ml-auto">
                      <Share2 size={18} />
                    </button>
                  </div>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      <div className="pt-8 text-center">
        <p className="text-white/20 text-sm mb-4 italic">You've reached the end of the feed.</p>
        <NeonButton variant="outline" size="sm">Load More</NeonButton>
      </div>
    </div>
  );
}
