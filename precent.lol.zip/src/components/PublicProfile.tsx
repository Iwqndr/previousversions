import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { BioLink, AppearanceSettings as AppearanceType, UserProfile } from '../types';
import { api } from '../lib/api';
import { profileService } from '../services/profileService';
import { CustomCursor } from './ui/CustomCursor';
import { BackgroundSystem } from './ui/BackgroundSystem';
import { ExternalLink, Music, Share2, Heart, Flag, Eye, Pause, Volume2 } from 'lucide-react';
import { cn } from '../lib/utils';
import { useSupabase } from './SupabaseProvider';
import { useGoogleFont } from '../hooks/useGoogleFonts';
import { ReportModal } from './ui/ReportModal';
import { showToast } from '../lib/toast';

interface PublicProfileProps {
  username: string;
}

export function PublicProfile({ username }: PublicProfileProps) {
  const { user: currentUser } = useSupabase();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [hasLiked, setHasLiked] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);

  // Load Google Font if specified
  useGoogleFont(profile?.appearance?.fontFamily || 'inter');

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const data = await api.getProfileByUsername(username);
        if (!data) {
          setError('Profile not found');
          setLoading(false);
          return;
        }

        const normalized = profileService.normalizeProfile(data);
        if (!normalized) {
          setError('Profile not found');
          setLoading(false);
          return;
        }

        setProfile(normalized);
        // Increment views only if viewer is not the profile owner
        const viewerUid = currentUser?.id;
        if (viewerUid !== normalized.uid) {
          await profileService.incrementViews(normalized.uid);
        }
        setLoading(false);
      } catch (err) {
        console.error('Error fetching profile:', err);
        setError('Profile not found');
        setLoading(false);
      }
    };

    fetchProfile();
  }, [username]);

  const handleLike = async () => {
    if (hasLiked || !profile) return;

    if (currentUser?.id === profile.uid) {
      showToast("You can't like your own profile!", 'warning');
      return;
    }

    try {
      await profileService.incrementLikes(profile.uid);
      setHasLiked(true);
      setProfile({ ...profile, likes: (profile.likes || 0) + 1 });
      showToast('Profile liked!', 'success');
    } catch (err) {
      console.error('Failed to like profile', err);
      showToast('Failed to like profile. Please try again.', 'error');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-base flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-neon-orange border-t-transparent rounded-full animate-spin neon-glow-orange" />
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen bg-base text-white flex flex-col items-center justify-center">
        <h1 className="text-4xl font-black mb-4">404</h1>
        <p className="text-white/40">Profile not found</p>
        <a href="/" className="mt-8 text-neon-orange hover:underline">Go Home</a>
      </div>
    );
  }

  const appearance: AppearanceType = profile.appearance || {
    backgroundType: 'gradient',
    backgroundColor: '#ff8800',
    accentColor: '#ff8800',
    fontFamily: 'inter',
    glassmorphism: true,
  };

  const links: BioLink[] = profile.links || [];

  // Helper function to fix URLs
  const fixUrl = (url: string) => {
    if (!url) return '#';
    // If URL doesn't have a protocol, add https://
    if (!url.startsWith('http://') && !url.startsWith('https://') && !url.startsWith('mailto:')) {
      return `https://${url}`;
    }
    return url;
  };

  // Get font family string
  const getFontFamily = () => {
    const fontMap: Record<string, string> = {
      'inter': '"Inter", sans-serif',
      'mono': '"JetBrains Mono", monospace',
      'outfit': '"Outfit", sans-serif',
      'space': '"Space Grotesk", sans-serif',
      'roboto': '"Roboto", sans-serif',
      'lato': '"Lato", sans-serif',
      'playfair': '"Playfair Display", serif',
      'rubik': '"Rubik", sans-serif',
      'syne': '"Syne", sans-serif',
      'bricolage': '"Bricolage Grotesque", sans-serif',
      'clash': '"Clash Display", sans-serif',
      'chillax': '"Chillax", sans-serif',
    };
    return fontMap[appearance.fontFamily || 'inter'] || '"Inter", sans-serif';
  };

  // Get text transform
  const getTextTransform = () => {
    switch (appearance.textTransform) {
      case 'uppercase': return 'uppercase';
      case 'lowercase': return 'lowercase';
      default: return 'none';
    }
  };

  // Get font weight
  const getFontWeight = () => {
    switch (appearance.fontWeight) {
      case 'light': return '300';
      case 'normal': return '400';
      case 'bold': return '700';
      case 'black': return '900';
      default: return '400';
    }
  };

  // Get avatar shape
  const getAvatarShape = () => {
    switch (appearance.avatarShape) {
      case 'circle': return 'rounded-full';
      case 'square': return 'rounded-none';
      case 'rounded': return 'rounded-2xl';
      case 'squircle': return 'rounded-[2rem]';
      case 'hexagon': return 'clip-hexagon';
      default: return 'rounded-full';
    }
  };

  // Get layout class
  const getLayoutClass = () => {
    switch (appearance.layout) {
      case 'center': return 'items-center';
      case 'left': return 'items-start';
      case 'right': return 'items-end';
      default: return 'items-center';
    }
  };

  // Get background style
  const getBackgroundStyle = () => {
    switch (appearance.backgroundType) {
      case 'solid':
        return { backgroundColor: appearance.backgroundColor };
      case 'gradient':
        return { background: `linear-gradient(135deg, ${appearance.backgroundColor}, #0a0a0a)` };
      case 'image':
        return { 
          backgroundImage: appearance.backgroundImage ? `url(${appearance.backgroundImage})` : 'none',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        };
      default:
        return { backgroundColor: '#0a0a0a' };
    }
  };

  return (
    <div 
      className="min-h-screen text-white relative overflow-x-hidden selection:bg-neon-orange/30 selection:text-neon-orange"
      style={{
        fontFamily: getFontFamily(),
        textTransform: getTextTransform(),
        fontWeight: getFontWeight(),
        ...getBackgroundStyle()
      }}
    >
      <CustomCursor />

      {/* Background overlay for image backgrounds */}
      {appearance.backgroundType === 'image' && appearance.backgroundImage && (
        <div className="fixed inset-0 z-[-1] bg-black/50 backdrop-blur-sm" />
      )}

      <div className={`container mx-auto px-4 py-20 flex flex-col ${getLayoutClass()} justify-center min-h-screen relative z-10`}>
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className={cn(
            "w-full max-w-md p-8 rounded-3xl relative",
            appearance.glassmorphism 
              ? "glass border border-white/10" 
              : "bg-[#1a1a1a] border border-white/5"
          )}
          style={{
            boxShadow: appearance.glassmorphism ? `0 0 40px ${appearance.accentColor}20` : 'none',
          }}
        >
          {/* Avatar with Progress Ring */}
          <div className="relative w-24 h-24 mx-auto mb-6">
            {/* Progress ring background */}
            <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke="#2a2a2a"
                strokeWidth="6"
              />
              <circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke={appearance.accentColor || '#3b82f6'}
                strokeWidth="6"
                strokeDasharray="283"
                strokeDashoffset="70"
                strokeLinecap="round"
                className="animate-spin-slow"
              />
            </svg>
            
            {/* Avatar image */}
            <div className={cn(
              "w-full h-full rounded-full overflow-hidden relative z-10 bg-[#1a1a1a] border-4",
              appearance.accentColor ? `border-[${appearance.accentColor}]` : "border-[#3b82f6]"
            )} style={{ borderColor: appearance.accentColor || '#3b82f6' }}>
              {profile.avatarUrl ? (
                <img src={profile.avatarUrl} alt={profile.displayName} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-3xl font-black" style={{ color: appearance.accentColor || '#3b82f6' }}>
                  {profile.displayName?.charAt(0) || profile.username?.charAt(0) || '?'}
                </div>
              )}
            </div>
            
            {/* Status indicator */}
            <div 
              className="absolute bottom-1 right-1 w-5 h-5 rounded-full border-4 border-[#0a0a0a] z-20"
              style={{ backgroundColor: appearance.accentColor || '#3b82f6' }}
            />
          </div>

          {/* Info */}
          <div className="text-center mb-6">
            <h1 
              className="text-2xl font-black mb-1"
              style={{ color: appearance.accentColor || '#3b82f6' }}
            >
              {profile.displayName || profile.username}
            </h1>
            <p className="text-white/40 text-sm">@{profile.username}</p>
            {profile.bio && (
              <p className="text-white/60 text-sm mt-2">{profile.bio}</p>
            )}
          </div>

          {/* Stats Row */}
          <div className="flex items-center justify-center gap-4 mb-8">
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10">
              <Eye size={14} style={{ color: appearance.accentColor || '#3b82f6' }} />
              <span className="text-xs font-bold">{profile.analytics?.views || 0}</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10">
              <Heart size={14} style={{ color: appearance.accentColor || '#3b82f6' }} />
              <span className="text-xs font-bold">{profile.likes || 0}</span>
            </div>
          </div>

          {/* Links */}
          <div className="space-y-3 mb-6">
            {links.filter(l => l.active).map((link, index) => (
              <motion.a
                key={link.id}
                href={fixUrl(link.url)}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={cn(
                  "block w-full p-4 rounded-xl font-bold transition-all relative overflow-hidden group/link",
                  "bg-[#1a1a1a] border border-white/10 hover:border-white/20"
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="text-white">{link.title}</span>
                  <ExternalLink size={14} className="text-white/40 group-hover/link:text-white/60 transition-colors" />
                </div>
              </motion.a>
            ))}
          </div>

          {/* Music Player Card - Only show if music is added */}
          {activeTrack && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 p-4 rounded-2xl bg-[#1a1a1a] border border-white/10"
            >
              <div className="flex items-start gap-4 mb-4">
                {/* Music icon */}
                <div 
                  className="w-14 h-14 rounded-xl flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `${appearance.accentColor || '#3b82f6'}15` }}
                >
                  <Music size={24} style={{ color: appearance.accentColor || '#3b82f6' }} />
                </div>
                
                {/* Track info */}
                <div className="flex-1 min-w-0">
                  <p className="text-white font-bold truncate">{activeTrack.title || 'Unknown Track'}</p>
                  <p className="text-white/40 text-sm">{activeTrack.artist || 'No Artist'}</p>
                </div>

                {/* Equalizer animation */}
                <div className="flex gap-0.5 items-end h-6">
                  {[1, 2, 3, 4].map(i => (
                    <div 
                      key={i}
                      className="w-1 rounded-full animate-music-bar"
                      style={{ 
                        height: `${Math.random() * 15 + 5}px`, 
                        backgroundColor: appearance.accentColor || '#3b82f6',
                        animationDelay: `${i * 0.1}s`
                      }}
                    />
                  ))}
                </div>
              </div>

              {/* Progress bar */}
              <div className="space-y-2 mb-4">
                <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                  <div 
                    className="h-full rounded-full w-1/3 transition-all"
                    style={{ backgroundColor: appearance.accentColor || '#3b82f6' }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-white/30 font-mono">
                  <span>0:00</span>
                  <span>2:33</span>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-between">
                <button 
                  className="w-10 h-10 rounded-full flex items-center justify-center transition-transform hover:scale-110"
                  style={{ backgroundColor: appearance.accentColor || '#3b82f6', color: '#fff' }}
                >
                  <Pause size={18} fill="currentColor" />
                </button>
                
                <div className="flex items-center gap-2">
                  <button className="text-white/40 hover:text-white transition-colors">
                    <Volume2 size={18} />
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* Socials / Footer */}
          <div className="mt-8 pt-6 border-t border-white/10 flex items-center justify-center gap-6">
            <button
              onClick={handleLike}
              className={cn(
                "flex items-center gap-2 transition-colors",
                hasLiked ? "text-pink-500" : "text-white/40 hover:text-pink-500"
              )}
            >
              <Heart size={18} className={cn(hasLiked && "fill-pink-500")} />
              <span className="text-sm font-bold">{profile.likes || 0}</span>
            </button>
            <button
              onClick={() => {
                navigator.clipboard.writeText(window.location.href);
                showToast('Link copied to clipboard!', 'success');
              }}
              className="text-white/40 hover:text-white transition-colors"
            >
              <Share2 size={18} />
            </button>
            <button
              onClick={() => setShowReportModal(true)}
              className="text-white/40 hover:text-red-500 transition-colors"
            >
              <Flag size={18} />
            </button>
          </div>
        </motion.div>

        <div className="mt-12 text-center">
          <a href="/" className="text-xs font-bold text-white/20 hover:text-white transition-colors tracking-widest uppercase">
            Powered by precent.lol
          </a>
        </div>
      </div>

      {/* Report Modal */}
      <ReportModal
        isOpen={showReportModal}
        onClose={() => setShowReportModal(false)}
        reportedUsername={profile.displayName || profile.username}
        reportedUid={profile.uid}
      />
    </div>
  );
}
