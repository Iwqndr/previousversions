import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GlassCard } from '../ui/GlassCard';
import { NeonButton } from '../ui/NeonButton';
import { AtSign, Lock, User, Mail, ArrowRight, ShieldCheck, Key } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { supabase } from '@/src/lib/supabase';
import { profileService } from '@/src/services/profileService';
import { localStorageService } from '@/src/services/localStorageService';
import { api } from '@/src/lib/api';

export function AuthCard() {
  const [mode, setMode] = useState<'login' | 'signup' | 'token'>('signup');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tokenInput, setTokenInput] = useState('');

  // Form state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');

  const handleDemoLogin = async () => {
    setLoading(true);
    try {
      const localProfile = localStorageService.getProfile();
      if (!localProfile) {
        // Create a default demo profile
        const demoProfile = {
          uid: 'demo-user',
          username: 'demo',
          displayName: 'Demo User',
          email: 'demo@example.com',
          avatarUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=demo',
          bio: 'This is a demo profile stored in your browser.',
          location: 'Local Storage',
          links: [],
          appearance: {
            backgroundType: 'gradient',
            backgroundColor: '#050505',
            accentColor: '#ff8800',
            fontFamily: 'Inter',
            glassmorphism: true,
            buttonStyle: 'rounded',
            cardStyle: 'glass',
            theme: 'dark'
          },
          analytics: { views: 0, clicks: 0, history: [] },
          badges: ['Early Adopter'],
          likes: 0,
          createdat: Date.now()
        };
        localStorageService.saveProfile(demoProfile as any);
      }
      window.location.reload(); // Reload to trigger Demo Mode in Provider
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleTokenLogin = async () => {
    if (!tokenInput.trim()) {
      setError('Please enter your login token');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const result = await api.loginWithToken(tokenInput.trim());
      if (result.success && result.user) {
        // Store the user data in local storage and reload
        localStorageService.saveProfile(result.user);
        localStorage.setItem('sb-auth-token', result.token || '');
        window.location.reload();
      }
    } catch (err: any) {
      setError(err.message || 'Invalid token');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin,
        },
      });
      if (error) throw error;
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (mode === 'signup') {
        if (!username || !displayName || !email || !password) {
          throw new Error('Please fill in all fields');
        }

        // Check blacklist
        const { data: blacklistData } = await supabase
          .from('blacklist')
          .select('*')
          .or(`value.eq.${email},value.eq.${username}`);

        if (blacklistData && blacklistData.length > 0) {
          throw new Error('This email or username is blacklisted.');
        }

        const isAvailable = await profileService.isUsernameAvailable(username);
        if (!isAvailable) {
          throw new Error('Username already taken');
        }

        const { data, error } = await supabase.auth.signUp({
          email,
          password,
        });
        if (error) throw error;
        if (!data.user) throw new Error('Sign up failed');

        await profileService.createProfile(data.user.id, {
          email,
          username: username.toLowerCase(),
          displayName,
          avatarUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
        });
        // Redirect to dashboard after signup
        window.location.href = '/';
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        // Redirect to dashboard after login
        window.location.href = '/';
      }
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  const renderError = (err: string | null) => {
    if (!err) return null;
    return (
      <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-500 text-sm">
        {err}
      </div>
    );
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 relative overflow-hidden bg-base">
      <div className="absolute inset-0 grid-bg opacity-20" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-neon-orange/5 blur-[100px] rounded-full pointer-events-none" />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="w-full max-w-md relative z-10"
      >
        <GlassCard className="p-8 border-neon-orange/20 card-shadow">
          <div className="text-center mb-10">
            <div className="w-16 h-16 rounded-2xl bg-neon-orange/10 border border-neon-orange/30 flex items-center justify-center mx-auto mb-6 neon-glow-orange">
              <ShieldCheck size={32} className="text-neon-orange" />
            </div>
            <h2 className="text-3xl font-black mb-2 text-transparent bg-clip-text bg-gradient-to-r from-white to-white/60">
              {mode === 'login' ? 'Welcome Back' : 'Join the Future'}
            </h2>
            <p className="text-white/50 text-sm">
              {mode === 'login' ? 'Enter your credentials to access your dashboard.' : 'Create your account and start building your bio.'}
            </p>
          </div>

          {renderError(error)}

          <div className="space-y-6">
            <NeonButton 
              className="w-full" 
              variant="outline" 
              onClick={handleGoogleLogin}
              disabled={loading}
            >
              <img src="https://www.google.com/favicon.ico" className="w-4 h-4" alt="Google" />
              Continue with Google
            </NeonButton>

            <NeonButton 
              className="w-full" 
              variant="outline" 
              onClick={handleDemoLogin}
              disabled={loading}
            >
              <ShieldCheck size={18} className="text-cyan" />
              Continue in Demo Mode (Local)
            </NeonButton>

            <div className="relative flex items-center justify-center">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/10"></div></div>
              <span className="relative px-4 bg-surface text-[10px] text-white/30 uppercase font-black tracking-widest">Or continue with</span>
            </div>

            <form className="space-y-4" onSubmit={handleSubmit}>
              <AnimatePresence mode="wait">
                {mode === 'signup' && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-4 overflow-hidden"
                  >
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-white/50 flex items-center gap-2 uppercase tracking-wider">
                        <User size={14} /> Full Name
                      </label>
                      <input 
                        type="text" 
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        placeholder="Alex Doe"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 focus:bg-white/10 transition-all text-sm"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-white/50 flex items-center gap-2 uppercase tracking-wider">
                        <AtSign size={14} /> Username
                      </label>
                      <input 
                        type="text" 
                        value={username}
                        onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/\s/g, ''))}
                        placeholder="alexdoe"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 focus:bg-white/10 transition-all text-sm"
                      />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="space-y-2">
                <label className="text-xs font-bold text-white/50 flex items-center gap-2 uppercase tracking-wider">
                  <Mail size={14} /> Email
                </label>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="alex@example.com"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 focus:bg-white/10 transition-all text-sm"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-white/50 flex items-center gap-2 uppercase tracking-wider">
                  <Lock size={14} /> Password
                </label>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 focus:bg-white/10 transition-all text-sm"
                />
              </div>

              <NeonButton className="w-full mt-6" size="lg" disabled={loading} type="submit">
                {loading ? 'Processing...' : (mode === 'login' ? 'Login' : 'Create Account')}
                <ArrowRight size={20} />
              </NeonButton>
            </form>
          </div>

          <div className="mt-8 text-center">
            <button
              onClick={() => setMode(mode === 'login' ? 'signup' : mode === 'signup' ? 'token' : 'login')}
              className="text-xs font-bold text-white/40 hover:text-neon-orange transition-colors"
            >
              {mode === 'login' 
                ? "Don't have an account? Sign up" 
                : mode === 'signup' 
                ? "Have a login token? Use it instead"
                : "Back to email login"}
            </button>
          </div>

          {/* Token Login Section */}
          {mode === 'token' && (
            <div className="mt-6 p-6 rounded-xl bg-white/5 border border-white/10">
              <div className="flex items-center gap-3 mb-4">
                <Key size={20} className="text-neon-orange" />
                <h3 className="text-sm font-bold text-white">Login with Token</h3>
              </div>
              <p className="text-xs text-white/40 mb-4">Enter your 12-character login token to instantly access your account without a password.</p>
              <div className="flex gap-3">
                <input
                  type="text"
                  value={tokenInput}
                  onChange={(e) => setTokenInput(e.target.value)}
                  placeholder="Enter your login token"
                  className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-neon-orange/50 focus:bg-white/10 transition-all text-sm font-mono"
                  maxLength={12}
                />
                <NeonButton
                  size="sm"
                  onClick={handleTokenLogin}
                  disabled={loading || tokenInput.length !== 12}
                >
                  {loading ? '...' : 'Login'}
                </NeonButton>
              </div>
            </div>
          )}
        </GlassCard>
      </motion.div>
    </div>
  );
}
