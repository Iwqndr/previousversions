export interface ThemeConfig {
  id: string;
  name: string;
  colors: {
    base: string;
    surface: string;
    surfaceLight: string;
    neon: string;
    neonGlow: string;
    glassBg: string;
    glassBorder: string;
    text: string;
    textMuted: string;
  };
}

export const themes: ThemeConfig[] = [
  {
    id: 'dark',
    name: 'Dark Mode',
    colors: {
      base: '#030303',
      surface: '#0a0a0a',
      surfaceLight: '#121212',
      neon: '#ff8800',
      neonGlow: 'rgba(255, 136, 0, 0.15)',
      glassBg: 'rgba(255, 255, 255, 0.02)',
      glassBorder: 'rgba(255, 255, 255, 0.05)',
      text: '#ffffff',
      textMuted: 'rgba(255, 255, 255, 0.4)',
    },
  },
  {
    id: 'light',
    name: 'Light Mode',
    colors: {
      base: '#f8fafc',
      surface: '#ffffff',
      surfaceLight: '#f1f5f9',
      neon: '#0ea5e9',
      neonGlow: 'rgba(14, 165, 233, 0.15)',
      glassBg: 'rgba(0, 0, 0, 0.02)',
      glassBorder: 'rgba(0, 0, 0, 0.05)',
      text: '#0f172a',
      textMuted: 'rgba(15, 23, 42, 0.4)',
    },
  },
  {
    id: 'cyber',
    name: 'Cyberpunk',
    colors: {
      base: '#0b0e14',
      surface: '#151921',
      surfaceLight: '#1c232e',
      neon: '#f0db4f',
      neonGlow: 'rgba(240, 219, 79, 0.15)',
      glassBg: 'rgba(240, 219, 79, 0.02)',
      glassBorder: 'rgba(240, 219, 79, 0.1)',
      text: '#ffffff',
      textMuted: 'rgba(255, 255, 255, 0.5)',
    },
  },
  {
    id: 'neon',
    name: 'Neon Nights',
    colors: {
      base: '#05010a',
      surface: '#0d0218',
      surfaceLight: '#150426',
      neon: '#ff00ff',
      neonGlow: 'rgba(255, 0, 255, 0.2)',
      glassBg: 'rgba(255, 0, 255, 0.05)',
      glassBorder: 'rgba(255, 0, 255, 0.1)',
      text: '#ffffff',
      textMuted: 'rgba(255, 255, 255, 0.4)',
    },
  },
  {
    id: 'minimal',
    name: 'Minimalist',
    colors: {
      base: '#ffffff',
      surface: '#fafafa',
      surfaceLight: '#f5f5f5',
      neon: '#000000',
      neonGlow: 'rgba(0, 0, 0, 0.05)',
      glassBg: 'rgba(0, 0, 0, 0.01)',
      glassBorder: 'rgba(0, 0, 0, 0.05)',
      text: '#000000',
      textMuted: 'rgba(0, 0, 0, 0.4)',
    },
  },
  {
    id: 'hacker',
    name: 'Hacker Terminal',
    colors: {
      base: '#000000',
      surface: '#050505',
      surfaceLight: '#0a0a0a',
      neon: '#ff8800',
      neonGlow: 'rgba(255, 136, 0, 0.15)',
      glassBg: 'rgba(255, 136, 0, 0.02)',
      glassBorder: 'rgba(255, 136, 0, 0.1)',
      text: '#ff8800',
      textMuted: 'rgba(255, 136, 0, 0.4)',
    },
  },
  {
    id: 'vaporwave',
    name: 'Vaporwave',
    colors: {
      base: '#2d1b4e',
      surface: '#3d2569',
      surfaceLight: '#4d2f84',
      neon: '#ff71ce',
      neonGlow: 'rgba(255, 113, 206, 0.2)',
      glassBg: 'rgba(1, 205, 254, 0.1)',
      glassBorder: 'rgba(255, 113, 206, 0.2)',
      text: '#ffffff',
      textMuted: 'rgba(255, 255, 255, 0.6)',
    },
  },
  {
    id: 'monochrome',
    name: 'Monochrome',
    colors: {
      base: '#111111',
      surface: '#1a1a1a',
      surfaceLight: '#222222',
      neon: '#ffffff',
      neonGlow: 'rgba(255, 255, 255, 0.1)',
      glassBg: 'rgba(255, 255, 255, 0.02)',
      glassBorder: 'rgba(255, 255, 255, 0.1)',
      text: '#ffffff',
      textMuted: 'rgba(255, 255, 255, 0.4)',
    },
  },
];
