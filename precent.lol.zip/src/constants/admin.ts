// Admin email addresses
export const ADMIN_EMAILS = [
  'defwar155@gmail.com',
  'yumdelirious1@gmail.com',
  'iwqndr@gmail.com',
];

export function isAdmin(email: string | undefined): boolean {
  return !!email && ADMIN_EMAILS.includes(email);
}
