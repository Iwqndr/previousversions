-- Migration: Drop appearance check constraint to allow additional customization fields
-- The application uses extended appearance settings (buttonStyle, cardStyle, theme, etc.)
-- that were not present in the original schema. This constraint prevents the app
-- from creating or updating profiles with these fields, causing 400 errors.
--
-- To run this migration, execute it in the Supabase SQL editor or via CLI.

ALTER TABLE users DROP CONSTRAINT IF EXISTS users_appearance_check;
