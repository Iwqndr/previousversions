-- Migration: Create usernames table for username uniqueness
-- This table maps usernames to user UIDs to ensure uniqueness and fast lookups.
-- It is used for checking username availability and for updating usernames.

CREATE TABLE IF NOT EXISTS usernames (
  username TEXT PRIMARY KEY,
  uid TEXT NOT NULL
);

-- Enable Row Level Security (RLS)
ALTER TABLE usernames ENABLE ROW LEVEL SECURITY;

-- Policy: Allow anyone to read usernames (usernames are public anyway)
CREATE POLICY "Public usernames are viewable" ON usernames
  FOR SELECT USING (true);

-- Policy: Allow authenticated users to insert their own username mapping
CREATE POLICY "Users can insert own username" ON usernames
  FOR INSERT WITH CHECK (auth.uid() = uid);

-- Policy: Allow authenticated users to delete their own username mapping
CREATE POLICY "Users can delete own username" ON usernames
  FOR DELETE USING (auth.uid() = uid);

-- Optional: Index on uid for faster queries (though not needed if we only query by username)
-- CREATE INDEX IF NOT EXISTS idx_usernames_uid ON usernames(uid);
