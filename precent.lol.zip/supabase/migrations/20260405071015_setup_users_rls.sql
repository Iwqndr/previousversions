-- Migration: Set up Row Level Security (RLS) policies for the users table
-- This allows authenticated users to manage their own profiles.

-- Enable RLS on users table (if not already enabled)
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Policy: Allow users to select their own profile
CREATE POLICY "Users can view own profile" ON users
  FOR SELECT USING (auth.uid() = uid);

-- Policy: Allow users to insert their own profile
CREATE POLICY "Users can insert own profile" ON users
  FOR INSERT WITH CHECK (auth.uid() = uid);

-- Policy: Allow users to update their own profile
CREATE POLICY "Users can update own profile" ON users
  FOR UPDATE USING (auth.uid() = uid);

-- Policy: Allow public read access to all profiles (for public profile pages)
-- This is needed for the PublicProfile component to fetch profiles by username
CREATE POLICY "Public profiles are viewable" ON users
  FOR SELECT USING (true);
