-- =============================================================================
-- PRECENT.LOL - COMPLETE DATABASE SCHEMA
-- =============================================================================
-- Run this ENTIRE script in your Supabase SQL Editor to set up the database.
-- This combines all migrations into one file for a clean, complete setup.
-- =============================================================================

-- =============================================================================
-- SECTION 0: FIX EXISTING COLUMN NAMES (Run FIRST)
-- =============================================================================
-- Rename "createdAt" columns to createdat on existing tables before we try to create them

DO $$
BEGIN
    -- Fix users table
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='createdAt') 
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='createdat') THEN
        ALTER TABLE users RENAME COLUMN "createdAt" TO createdat;
    END IF;

    -- Fix blacklist table
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='blacklist' AND column_name='createdAt') 
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='blacklist' AND column_name='createdat') THEN
        ALTER TABLE blacklist RENAME COLUMN "createdAt" TO createdat;
    END IF;

    -- Fix reports table
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='reports' AND column_name='createdAt') 
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='reports' AND column_name='createdat') THEN
        ALTER TABLE reports RENAME COLUMN "createdAt" TO createdat;
    END IF;

    -- Fix credits table
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='credits' AND column_name='createdAt') 
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='credits' AND column_name='createdat') THEN
        ALTER TABLE credits RENAME COLUMN "createdAt" TO createdat;
    END IF;

    -- Fix posts table
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='posts' AND column_name='createdAt') 
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='posts' AND column_name='createdat') THEN
        ALTER TABLE posts RENAME COLUMN "createdAt" TO createdat;
    END IF;
END $$;

-- =============================================================================
-- SECTION 1: DROP OLD CONSTRAINTS (Safe to run multiple times)
-- =============================================================================

-- Drop appearance check constraint that prevents extended customization fields
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_appearance_check;

-- =============================================================================
-- SECTION 2: CREATE USERS TABLE (if not exists)
-- =============================================================================
-- Note: Supabase auth.users is separate. This is the public profiles table.

CREATE TABLE IF NOT EXISTS users (
  uid TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  "displayName" TEXT,
  avatarUrl TEXT,
  bannerUrl TEXT,
  bio TEXT DEFAULT 'Welcome to my profile!',
  location TEXT DEFAULT '',
  links JSONB DEFAULT '[]'::jsonb,
  appearance JSONB DEFAULT '{
    "backgroundType": "gradient",
    "backgroundColor": "#050505",
    "accentColor": "#ff8800",
    "fontFamily": "inter",
    "glassmorphism": true,
    "buttonStyle": "rounded",
    "cardStyle": "glass",
    "theme": "dark",
    "avatarShape": "circle",
    "layout": "center",
    "cursorTrail": "none",
    "pageTransition": "fade",
    "crtEffect": false,
    "glitchEffect": false,
    "bloomIntensity": 50,
    "borderWeight": 1,
    "fontWeight": "normal",
    "textTransform": "none"
  }'::jsonb,
  analytics JSONB DEFAULT '{"views": 0, "clicks": 0, "history": []}'::jsonb,
  badges TEXT[] DEFAULT ARRAY['Early Access', 'OG'],
  likes INTEGER DEFAULT 0,
  music JSONB DEFAULT '[]'::jsonb,
  media JSONB DEFAULT '[]'::jsonb,
  discord JSONB,
  metadata JSONB,
  "isSuspended" BOOLEAN DEFAULT false,
  role TEXT DEFAULT 'user',
  "isPro" BOOLEAN DEFAULT false,
  plan TEXT DEFAULT 'free',
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

-- =============================================================================
-- SECTION 3: CREATE USERNAMES TABLE (for uniqueness checks)
-- =============================================================================

CREATE TABLE IF NOT EXISTS usernames (
  username TEXT PRIMARY KEY,
  uid TEXT NOT NULL -- Removed FK to avoid type mismatch with auth.users
);

-- Index for faster username lookups
CREATE INDEX IF NOT EXISTS usernames_uid_idx ON usernames(uid);

-- =============================================================================
-- SECTION 4: CREATE BLACKLIST TABLE
-- =============================================================================

CREATE TABLE IF NOT EXISTS blacklist (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL,
  value TEXT NOT NULL,
  reason TEXT,
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

-- =============================================================================
-- SECTION 5: CREATE REPORTS TABLE (for user reports)
-- =============================================================================

CREATE TABLE IF NOT EXISTS reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_uid TEXT,
  reported_uid TEXT NOT NULL,
  reason TEXT NOT NULL,
  status TEXT DEFAULT 'pending',
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

-- =============================================================================
-- SECTION 6: CREATE MODERATION_LOGS TABLE
-- =============================================================================

CREATE TABLE IF NOT EXISTS moderation_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  moderator TEXT NOT NULL,
  action TEXT NOT NULL,
  reason TEXT,
  target TEXT,
  "timestamp" BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

-- Index for ordering moderation logs
CREATE INDEX IF NOT EXISTS moderation_logs_timestamp_idx ON moderation_logs("timestamp" DESC);

-- =============================================================================
-- SECTION 7: CREATE CREDITS TABLE
-- =============================================================================

CREATE TABLE IF NOT EXISTS credits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  "roleType" TEXT DEFAULT 'team',
  quote TEXT,
  avatar TEXT,
  link TEXT,
  highlighted BOOLEAN DEFAULT false,
  "order" INTEGER DEFAULT 0,
  active BOOLEAN DEFAULT true,
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

-- Index for ordering credits
CREATE INDEX IF NOT EXISTS credits_order_idx ON credits("order" ASC);

-- =============================================================================
-- SECTION 8: CREATE COMMUNITY POSTS TABLE
-- =============================================================================

CREATE TABLE IF NOT EXISTS posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  uid TEXT NOT NULL,
  username TEXT NOT NULL,
  avatar TEXT,
  content TEXT NOT NULL,
  "mediaUrl" TEXT,
  "mediaType" TEXT,
  likes INTEGER DEFAULT 0,
  comments INTEGER DEFAULT 0,
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

-- Index for ordering posts
CREATE INDEX IF NOT EXISTS posts_createdat_idx ON posts(createdat DESC);

-- =============================================================================
-- SECTION 9: ENSURE ALL COLUMNS EXIST (Safe to run multiple times)
-- =============================================================================

DO $$
BEGIN
    -- Add displayName if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='displayName') THEN
        ALTER TABLE users ADD COLUMN "displayName" text;
    END IF;

    -- Add appearance if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='appearance') THEN
        ALTER TABLE users ADD COLUMN appearance jsonb DEFAULT '{
            "backgroundType": "gradient",
            "backgroundColor": "#050505",
            "accentColor": "#ff8800",
            "fontFamily": "inter",
            "glassmorphism": true,
            "buttonStyle": "rounded",
            "cardStyle": "glass",
            "theme": "dark",
            "avatarShape": "circle",
            "layout": "center",
            "cursorTrail": "none",
            "pageTransition": "fade",
            "crtEffect": false,
            "glitchEffect": false,
            "bloomIntensity": 50,
            "borderWeight": 1,
            "fontWeight": "normal",
            "textTransform": "none"
        }'::jsonb;
    END IF;

    -- Add role if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='role') THEN
        ALTER TABLE users ADD COLUMN role text DEFAULT 'user';
    END IF;

    -- Add isSuspended if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='isSuspended') THEN
        ALTER TABLE users ADD COLUMN "isSuspended" boolean DEFAULT false;
    END IF;

    -- Add music if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='music') THEN
        ALTER TABLE users ADD COLUMN music jsonb DEFAULT '[]'::jsonb;
    END IF;

    -- Add media if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='media') THEN
        ALTER TABLE users ADD COLUMN media jsonb DEFAULT '[]'::jsonb;
    END IF;

    -- Add discord if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='discord') THEN
        ALTER TABLE users ADD COLUMN discord jsonb;
    END IF;

    -- Add metadata if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='metadata') THEN
        ALTER TABLE users ADD COLUMN metadata jsonb;
    END IF;

    -- Add isPro if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='isPro') THEN
        ALTER TABLE users ADD COLUMN "isPro" boolean DEFAULT false;
    END IF;

    -- Add plan if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='plan') THEN
        ALTER TABLE users ADD COLUMN plan text DEFAULT 'free';
    END IF;

    -- Add bannerUrl if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='bannerUrl') THEN
        ALTER TABLE users ADD COLUMN "bannerUrl" text;
    END IF;

    -- Add likes if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='likes') THEN
        ALTER TABLE users ADD COLUMN likes integer DEFAULT 0;
    END IF;
END $$;

-- =============================================================================
-- SECTION 10: CREATE INDEXES (for performance)
-- =============================================================================

-- Username lookup index (case-insensitive)
CREATE INDEX IF NOT EXISTS users_username_lower_idx ON users (lower(username));

-- =============================================================================
-- SECTION 11: ENABLE ROW LEVEL SECURITY (RLS)
-- =============================================================================

-- First, disable RLS on all tables to clean up any existing policies
ALTER TABLE users DISABLE ROW LEVEL SECURITY;
ALTER TABLE usernames DISABLE ROW LEVEL SECURITY;
ALTER TABLE blacklist DISABLE ROW LEVEL SECURITY;
ALTER TABLE reports DISABLE ROW LEVEL SECURITY;
ALTER TABLE moderation_logs DISABLE ROW LEVEL SECURITY;
ALTER TABLE credits DISABLE ROW LEVEL SECURITY;
ALTER TABLE posts DISABLE ROW LEVEL SECURITY;

-- Now drop ALL existing policies (safe even if they don't exist)
DROP POLICY IF EXISTS "Users can view own profile" ON users;
DROP POLICY IF EXISTS "Users can insert own profile" ON users;
DROP POLICY IF EXISTS "Users can update own profile" ON users;
DROP POLICY IF EXISTS "Public profiles are viewable" ON users;
DROP POLICY IF EXISTS "users_public_read" ON users;
DROP POLICY IF EXISTS "users_insert_own" ON users;
DROP POLICY IF EXISTS "users_update_own" ON users;
DROP POLICY IF EXISTS "Public usernames are viewable" ON usernames;
DROP POLICY IF EXISTS "Users can insert own username" ON usernames;
DROP POLICY IF EXISTS "Users can delete own username" ON usernames;
DROP POLICY IF EXISTS "usernames_public_read" ON usernames;
DROP POLICY IF EXISTS "usernames_insert_own" ON usernames;
DROP POLICY IF EXISTS "usernames_delete_own" ON usernames;
DROP POLICY IF EXISTS "Blacklist is viewable by authenticated" ON blacklist;
DROP POLICY IF EXISTS "blacklist_read" ON blacklist;
DROP POLICY IF EXISTS "Users can create reports" ON reports;
DROP POLICY IF EXISTS "Admins can view all reports" ON reports;
DROP POLICY IF EXISTS "reports_insert" ON reports;
DROP POLICY IF EXISTS "reports_read" ON reports;
DROP POLICY IF EXISTS "Admins can view moderation logs" ON moderation_logs;
DROP POLICY IF EXISTS "Admins can insert moderation logs" ON moderation_logs;
DROP POLICY IF EXISTS "moderation_logs_read" ON moderation_logs;
DROP POLICY IF EXISTS "moderation_logs_insert" ON moderation_logs;
DROP POLICY IF EXISTS "Credits are viewable" ON credits;
DROP POLICY IF EXISTS "Admins can manage credits" ON credits;
DROP POLICY IF EXISTS "credits_public_read" ON credits;
DROP POLICY IF EXISTS "credits_all_authenticated" ON credits;
DROP POLICY IF EXISTS "Posts are viewable" ON posts;
DROP POLICY IF EXISTS "Users can create posts" ON posts;
DROP POLICY IF EXISTS "Users can update own posts" ON posts;
DROP POLICY IF EXISTS "Users can delete own posts" ON posts;
DROP POLICY IF EXISTS "posts_public_read" ON posts;
DROP POLICY IF EXISTS "posts_insert_own" ON posts;
DROP POLICY IF EXISTS "posts_update_own" ON posts;
DROP POLICY IF EXISTS "posts_delete_own" ON posts;

-- Re-enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE usernames ENABLE ROW LEVEL SECURITY;
ALTER TABLE blacklist ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE moderation_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE credits ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;

-- =============================================================================
-- SECTION 12: RLS POLICIES - USERS TABLE
-- =============================================================================

-- Allow public read access for all user profiles (simplified - no auth.uid needed)
CREATE POLICY "users_public_read" ON users
  FOR SELECT
  USING (true);

-- Users can insert their own profile
CREATE POLICY "users_insert_own" ON users
  FOR INSERT
  WITH CHECK (auth.uid()::text = uid);

-- Users can update their own profile
CREATE POLICY "users_update_own" ON users
  FOR UPDATE
  USING (auth.uid()::text = uid)
  WITH CHECK (auth.uid()::text = uid);

-- =============================================================================
-- SECTION 13: RLS POLICIES - USERNAMES TABLE
-- =============================================================================

-- Public usernames are viewable
CREATE POLICY "usernames_public_read" ON usernames
  FOR SELECT
  USING (true);

-- Users can insert own username mapping
CREATE POLICY "usernames_insert_own" ON usernames
  FOR INSERT
  WITH CHECK (auth.uid()::text = uid);

-- Users can delete own username mapping
CREATE POLICY "usernames_delete_own" ON usernames
  FOR DELETE
  USING (auth.uid()::text = uid);

-- =============================================================================
-- SECTION 14: RLS POLICIES - BLACKLIST TABLE
-- =============================================================================

-- Blacklist is viewable by authenticated users
CREATE POLICY "blacklist_read" ON blacklist
  FOR SELECT
  USING (auth.uid() IS NOT NULL);

-- =============================================================================
-- SECTION 15: RLS POLICIES - REPORTS TABLE
-- =============================================================================

-- Users can insert reports
CREATE POLICY "reports_insert" ON reports
  FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

-- Authenticated users can view reports (simplified - admin check done in app)
CREATE POLICY "reports_read" ON reports
  FOR SELECT
  USING (auth.uid() IS NOT NULL);

-- =============================================================================
-- SECTION 16: RLS POLICIES - MODERATION_LOGS TABLE
-- =============================================================================

-- Authenticated users can view moderation logs (admin check done in app)
CREATE POLICY "moderation_logs_read" ON moderation_logs
  FOR SELECT
  USING (auth.uid() IS NOT NULL);

-- Authenticated users can insert moderation logs (admin check done in app)
CREATE POLICY "moderation_logs_insert" ON moderation_logs
  FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

-- =============================================================================
-- SECTION 17: RLS POLICIES - CREDITS TABLE
-- =============================================================================

-- Credits are viewable by everyone
CREATE POLICY "credits_public_read" ON credits
  FOR SELECT
  USING (true);

-- Authenticated users can manage credits (admin check done in app)
CREATE POLICY "credits_all_authenticated" ON credits
  FOR ALL
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

-- =============================================================================
-- SECTION 18: RLS POLICIES - POSTS TABLE
-- =============================================================================

-- Posts are viewable by everyone
CREATE POLICY "posts_public_read" ON posts
  FOR SELECT
  USING (true);

-- Users can insert their own posts
CREATE POLICY "posts_insert_own" ON posts
  FOR INSERT
  WITH CHECK (auth.uid()::text = uid);

-- Users can update their own posts
CREATE POLICY "posts_update_own" ON posts
  FOR UPDATE
  USING (auth.uid()::text = uid)
  WITH CHECK (auth.uid()::text = uid);

-- Users can delete their own posts
CREATE POLICY "posts_delete_own" ON posts
  FOR DELETE
  USING (auth.uid()::text = uid);

-- =============================================================================
-- SECTION 19: INSERT DEFAULT BLACKLIST ENTRIES (Optional)
-- =============================================================================

INSERT INTO blacklist (type, value, reason, createdat)
SELECT 'email', 'blocked@example.com', 'Spam', EXTRACT(EPOCH FROM NOW())::BIGINT
WHERE NOT EXISTS (SELECT 1 FROM blacklist WHERE value = 'blocked@example.com');

-- =============================================================================
-- MIGRATION COMPLETE
-- =============================================================================
-- Your database is now fully set up! All tables, columns, indexes, and RLS
-- policies are in place. You can now use the app normally.
-- =============================================================================
