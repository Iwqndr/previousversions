-- =============================================================================
-- Complete Schema Fix for precent.lol
-- Combines all necessary migrations into one file
-- =============================================================================
-- Run this entire script in Supabase SQL Editor to fix all database issues
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1) Drop appearance check constraint (fixes 400 errors on extended fields)
-- ---------------------------------------------------------------------------
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_appearance_check;

-- ---------------------------------------------------------------------------
-- 2) Create usernames table for uniqueness checks
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usernames (
  username TEXT PRIMARY KEY,
  uid TEXT NOT NULL
);

-- Enable Row Level Security
ALTER TABLE usernames ENABLE ROW LEVEL SECURITY;

-- Policies for usernames table
CREATE POLICY IF NOT EXISTS "Public usernames are viewable" ON usernames
  FOR SELECT USING (true);

CREATE POLICY IF NOT EXISTS "Users can insert own username" ON usernames
  FOR INSERT WITH CHECK (auth.uid() = uid);

CREATE POLICY IF NOT EXISTS "Users can delete own username" ON usernames
  FOR DELETE USING (auth.uid() = uid);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS usernames_uid_idx ON usernames(uid);

-- ---------------------------------------------------------------------------
-- 3) Setup RLS policies on users table
-- ---------------------------------------------------------------------------
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Allow users to view their own profile
CREATE POLICY IF NOT EXISTS "Users can view own profile" ON users
  FOR SELECT USING (auth.uid() = uid);

-- Allow users to insert their own profile
CREATE POLICY IF NOT EXISTS "Users can insert own profile" ON users
  FOR INSERT WITH CHECK (auth.uid() = uid);

-- Allow users to update their own profile
CREATE POLICY IF NOT EXISTS "Users can update own profile" ON users
  FOR UPDATE USING (auth.uid() = uid);

-- Allow public read access for public profile pages
CREATE POLICY IF NOT EXISTS "Public profiles are viewable" ON users
  FOR SELECT USING (true);

-- ---------------------------------------------------------------------------
-- 4) Ensure all required columns exist (add missing columns)
-- ---------------------------------------------------------------------------
DO $$ 
BEGIN
    -- Add displayName if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='displayName') THEN
        ALTER TABLE users ADD COLUMN "displayName" text;
    END IF;

    -- Add appearance if missing (with full schema including all customization fields)
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='appearance') THEN
        ALTER TABLE users ADD COLUMN appearance jsonb DEFAULT '{
            "backgroundType": "gradient",
            "backgroundColor": "#050505",
            "accentColor": "#ff8800",
            "fontFamily": "inter",
            "glassmorphism": true,
            "buttonStyle": "rounded",
            "cardStyle": "glass",
            "theme": "dark",
            "avatarShape": "circle",
            "layout": "center",
            "cursorTrail": "none",
            "pageTransition": "fade",
            "crtEffect": false,
            "glitchEffect": false,
            "bloomIntensity": 50,
            "borderWeight": 1,
            "fontWeight": "normal",
            "textTransform": "none"
        }'::jsonb;
    END IF;

    -- Add role if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='role') THEN
        ALTER TABLE users ADD COLUMN role text DEFAULT 'user';
    END IF;

    -- Add isSuspended if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='isSuspended') THEN
        ALTER TABLE users ADD COLUMN "isSuspended" boolean DEFAULT false;
    END IF;

    -- Add music if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='music') THEN
        ALTER TABLE users ADD COLUMN music jsonb DEFAULT '[]'::jsonb;
    END IF;

    -- Add media if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='media') THEN
        ALTER TABLE users ADD COLUMN media jsonb DEFAULT '[]'::jsonb;
    END IF;

    -- Add discord if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='discord') THEN
        ALTER TABLE users ADD COLUMN discord jsonb;
    END IF;

    -- Add metadata if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='metadata') THEN
        ALTER TABLE users ADD COLUMN metadata jsonb;
    END IF;
END $$;

-- ---------------------------------------------------------------------------
-- 5) Ensure blacklist table exists
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS blacklist (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    type text NOT NULL, -- 'email', 'ip', 'username'
    value text NOT NULL,
    "createdAt" bigint NOT NULL
);

ALTER TABLE blacklist ENABLE ROW LEVEL SECURITY;

-- Allow public read for blacklist (optional, for checking)
CREATE POLICY IF NOT EXISTS "Blacklist is viewable by authenticated" ON blacklist
  FOR SELECT USING (auth.uid() IS NOT NULL);

-- ---------------------------------------------------------------------------
-- 6) Create index on username for faster lookups
-- ---------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS users_username_lower_idx ON users (lower(username));

-- =============================================================================
-- END OF MIGRATION
-- =============================================================================
-- After running this, restart your app and all issues should be resolved:
-- - Admin panel (V key) will work
-- - Sidebar will show actual username
-- - View profile link will work
-- - Customization tabs will update correctly
-- - No more 406/400 errors
-- =============================================================================
