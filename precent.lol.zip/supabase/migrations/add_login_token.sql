-- Add login token column to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS logintoken TEXT;
CREATE INDEX IF NOT EXISTS users_logintoken_idx ON users(logintoken);

-- Add shadow ban column
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_shadow_banned BOOLEAN DEFAULT false;

-- Add IP/Location tracking to metadata (stored in JSONB metadata column)
-- Add last_login_ip, last_login_location to metadata

-- Add site settings table for maintenance mode and global messages
CREATE TABLE IF NOT EXISTS site_settings (
  id TEXT PRIMARY KEY DEFAULT 'global',
  maintenance_mode BOOLEAN DEFAULT false,
  maintenance_message TEXT DEFAULT 'We''ll be right back!',
  global_message TEXT DEFAULT '',
  global_message_active BOOLEAN DEFAULT false,
  mod_key_hash TEXT,
  mod_key_generated_at BIGINT,
  mod_key_discord_message_id TEXT,
  updatedat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

-- Create mod sessions table for one-time key exchange
CREATE TABLE IF NOT EXISTS mod_sessions (
  session_token TEXT PRIMARY KEY,
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT,
  expiresat BIGINT NOT NULL
);

-- Cleanup old sessions (run periodically or add a cron job)
-- DELETE FROM mod_sessions WHERE expiresat < EXTRACT(EPOCH FROM NOW())::BIGINT;

-- Insert default settings
INSERT INTO site_settings (id, maintenance_mode, maintenance_message, global_message, global_message_active) 
VALUES ('global', false, 'We''ll be right back!', '', false) 
ON CONFLICT (id) DO NOTHING;

-- Add change_history table for detailed admin action logging
CREATE TABLE IF NOT EXISTS change_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_email TEXT NOT NULL,
  action TEXT NOT NULL,
  target_uid TEXT,
  target_username TEXT,
  old_value TEXT,
  new_value TEXT,
  details TEXT,
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

CREATE INDEX IF NOT EXISTS change_history_createdat_idx ON change_history(createdat DESC);
CREATE INDEX IF NOT EXISTS change_history_target_idx ON change_history(target_uid);
