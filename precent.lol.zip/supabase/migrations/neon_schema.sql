-- =============================================================================
-- NEON DATABASE SCHEMA - PRECENT.LOL
-- =============================================================================
-- Run this in your Neon SQL console.
-- ALL column names are strictly lowercase.
-- =============================================================================

CREATE TABLE IF NOT EXISTS users (
  uid TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  displayname TEXT,
  avatarurl TEXT,
  bannerurl TEXT,
  bio TEXT DEFAULT 'Welcome to my profile!',
  location TEXT DEFAULT '',
  links JSONB DEFAULT '[]'::jsonb,
  appearance JSONB DEFAULT '{"backgroundType":"gradient","backgroundColor":"#050505","accentColor":"#ff8800","fontFamily":"inter","glassmorphism":true,"buttonStyle":"rounded","cardStyle":"glass","theme":"dark","avatarShape":"circle","layout":"center","cursorTrail":"none","pageTransition":"fade","crtEffect":false,"glitchEffect":false,"bloomIntensity":50,"borderWeight":1,"fontWeight":"normal","textTransform":"none"}'::jsonb,
  analytics JSONB DEFAULT '{"views":0,"clicks":0,"history":[]}'::jsonb,
  badges TEXT[] DEFAULT ARRAY['Early Access','OG'],
  likes INTEGER DEFAULT 0,
  music JSONB DEFAULT '[]'::jsonb,
  media JSONB DEFAULT '[]'::jsonb,
  discord JSONB,
  metadata JSONB,
  issuspended BOOLEAN DEFAULT false,
  isshadowbanned BOOLEAN DEFAULT false,
  role TEXT DEFAULT 'user',
  ispro BOOLEAN DEFAULT false,
  plan TEXT DEFAULT 'free',
  logintoken TEXT,
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

CREATE TABLE IF NOT EXISTS usernames (
  username TEXT PRIMARY KEY,
  uid TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS usernames_uid_idx ON usernames(uid);

CREATE TABLE IF NOT EXISTS blacklist (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL,
  value TEXT NOT NULL,
  reason TEXT,
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

CREATE TABLE IF NOT EXISTS reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_uid TEXT,
  reported_uid TEXT NOT NULL,
  reason TEXT NOT NULL,
  status TEXT DEFAULT 'pending',
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

CREATE TABLE IF NOT EXISTS moderation_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  moderator TEXT NOT NULL,
  action TEXT NOT NULL,
  reason TEXT,
  target TEXT,
  tstamp BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

CREATE INDEX IF NOT EXISTS moderation_logs_tstamp_idx ON moderation_logs(tstamp DESC);

CREATE TABLE IF NOT EXISTS credits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  roletype TEXT DEFAULT 'team',
  quote TEXT,
  avatar TEXT,
  link TEXT,
  highlighted BOOLEAN DEFAULT false,
  sortorder INTEGER DEFAULT 0,
  active BOOLEAN DEFAULT true,
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

CREATE INDEX IF NOT EXISTS credits_order_idx ON credits(sortorder ASC);

CREATE TABLE IF NOT EXISTS posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  uid TEXT NOT NULL,
  username TEXT NOT NULL,
  avatar TEXT,
  content TEXT NOT NULL,
  mediaurl TEXT,
  mediatype TEXT,
  likes INTEGER DEFAULT 0,
  comments INTEGER DEFAULT 0,
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

CREATE TABLE IF NOT EXISTS site_settings (
  id TEXT PRIMARY KEY DEFAULT 'global',
  maintenance_mode BOOLEAN DEFAULT false,
  maintenance_message TEXT DEFAULT 'We''ll be right back!',
  global_message TEXT DEFAULT '',
  global_message_active BOOLEAN DEFAULT false,
  mod_key_hash TEXT,
  mod_key_generated_at BIGINT,
  mod_key_discord_message_id TEXT,
  updatedat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

CREATE TABLE IF NOT EXISTS mod_sessions (
  session_token TEXT PRIMARY KEY,
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT,
  expiresat BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS change_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_email TEXT NOT NULL,
  action TEXT NOT NULL,
  target_uid TEXT,
  target_username TEXT,
  old_value TEXT,
  new_value TEXT,
  details TEXT,
  createdat BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

CREATE INDEX IF NOT EXISTS posts_createdat_idx ON posts(createdat DESC);
CREATE INDEX IF NOT EXISTS users_username_lower_idx ON users(LOWER(username));
CREATE INDEX IF NOT EXISTS change_history_createdat_idx ON change_history(createdat DESC);
