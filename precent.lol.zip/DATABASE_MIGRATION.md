# Database Migration Guide

## Overview
This guide will help you apply the updated database schema to your Supabase instance.

## What's Changed

### New Tables Added:
1. **moderation_logs** - Tracks all admin/moderator actions
2. **credits** - Manages team credits/special thanks entries

### Fixed Issues:
- ✅ Removed the `createdAt` column issue (column now properly exists with correct default)
- ✅ Added proper RLS policies for all new tables
- ✅ Added indexes for better query performance

## Migration Steps

### Important: If You Have an Existing Database

**Before running the migration, you should:**

1. **Backup your database** (Supabase Dashboard → Database → Backups)
2. **Run this cleanup SQL first** if you've had RLS policy errors:

```sql
-- Disable and re-enable RLS to clear stuck policies
ALTER TABLE users DISABLE ROW LEVEL SECURITY;
ALTER TABLE usernames DISABLE ROW LEVEL SECURITY;
ALTER TABLE blacklist DISABLE ROW LEVEL SECURITY;
ALTER TABLE reports DISABLE ROW LEVEL SECURITY;
ALTER TABLE posts DISABLE ROW LEVEL SECURITY;

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE usernames ENABLE ROW LEVEL SECURITY;
ALTER TABLE blacklist ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
```

### Option 1: Fresh Database Setup (Recommended for New Installs)

If you're setting up the database for the first time or can reset it:

1. Go to your Supabase Dashboard → SQL Editor
2. Copy the **ENTIRE** contents of `supabase/migrations/000_complete_schema.sql`
3. Paste it into the SQL Editor
4. Click "Run" to execute the migration
5. Verify all tables were created successfully

### Option 2: Existing Database (Add New Tables Only)

If you already have a running database and just need the new tables:

1. Go to your Supabase Dashboard → SQL Editor
2. Run the following SQL:

```sql
-- Create moderation_logs table
CREATE TABLE IF NOT EXISTS moderation_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  moderator TEXT NOT NULL,
  action TEXT NOT NULL,
  reason TEXT,
  target TEXT,
  "timestamp" BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

CREATE INDEX IF NOT EXISTS moderation_logs_timestamp_idx ON moderation_logs("timestamp" DESC);

ALTER TABLE moderation_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY IF NOT EXISTS "Admins can view moderation logs" ON moderation_logs
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM users WHERE uid = auth.uid() AND (role = 'admin' OR role = 'moderator')
    )
  );

CREATE POLICY IF NOT EXISTS "Admins can insert moderation logs" ON moderation_logs
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM users WHERE uid = auth.uid() AND (role = 'admin' OR role = 'moderator')
    )
  );

-- Create credits table
CREATE TABLE IF NOT EXISTS credits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  "roleType" TEXT DEFAULT 'team',
  quote TEXT,
  avatar TEXT,
  link TEXT,
  highlighted BOOLEAN DEFAULT false,
  "order" INTEGER DEFAULT 0,
  active BOOLEAN DEFAULT true,
  "createdAt" BIGINT DEFAULT EXTRACT(EPOCH FROM NOW())::BIGINT
);

CREATE INDEX IF NOT EXISTS credits_order_idx ON credits("order" ASC);

ALTER TABLE credits ENABLE ROW LEVEL SECURITY;

CREATE POLICY IF NOT EXISTS "Credits are viewable" ON credits
  FOR SELECT USING (true);

CREATE POLICY IF NOT EXISTS "Admins can manage credits" ON credits
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM users WHERE uid = auth.uid() AND role = 'admin'
    )
  );
```

3. Click "Run" to execute
4. Verify the tables were created

## Verification

After running the migration, verify the tables exist:

```sql
-- Check if tables exist
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN ('moderation_logs', 'credits')
ORDER BY table_name;
```

You should see both tables listed.

## What Each Table Does

### moderation_logs
- Tracks all administrative actions (bans, suspensions, badge grants, etc.)
- Records who performed the action, what action, why, and on whom
- Only visible to admins and moderators

### credits
- Stores team member information for the Credits page
- Includes: name, role, quote, avatar, link, highlight status
- Can be managed directly from the Admin Panel
- Publicly viewable (for the credits page)

## Using the New Features

### Admin Panel Changes:
1. **Unified Users Tab** - All user management in one place with infinite scroll
2. **Click on any user** to open their profile modal with:
   - Overview of their account
   - Badge management
   - View reports they've made
   - Actions (ban, suspend, blacklist, etc.)
3. **Reports Tab** - See all user reports
4. **Credits Tab** - Add/edit/remove team members and special thanks
5. **Analytics Tab** - View platform statistics

### User Search:
You can now search by:
- UUID (exact match)
- Username (partial match)
- Email (partial match)
- Display name (partial match)

### User Ban System:
When you ban a user:
- Their username changes to `Temp-{random string}`
- They are suspended
- Their role is set to 'banned'

## Troubleshooting

### "Table doesn't exist" errors
- Make sure you ran the complete migration SQL
- Check the SQL Editor output for any errors

### RLS Policy errors
- Ensure RLS is enabled on all tables
- Verify the policies were created correctly

### Missing columns
- The schema includes checks to add missing columns if they don't exist
- Re-run the migration if needed

## Need Help?

If you encounter issues:
1. Check the Supabase logs for error messages
2. Verify your database schema matches the migration
3. Ensure all RLS policies are in place

---

**Important**: Always backup your database before running migrations!
