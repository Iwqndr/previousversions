# Quick Fix Guide - Database RLS Issues

## Problem
You're getting 500 errors when fetching user profiles or 409 errors when creating profiles.

## Solution

### Step 1: Go to Supabase SQL Editor
1. Open your Supabase Dashboard
2. Click "SQL Editor" in the left sidebar
3. Create a new query

### Step 2: Run the Complete Migration

Copy and paste the **ENTIRE** contents of `supabase/migrations/000_complete_schema.sql` into the SQL Editor and click "Run".

**This script is safe to run multiple times** - it will:
- Clean up old/broken RLS policies
- Create missing tables (moderation_logs, credits)
- Fix all RLS policies to work correctly
- Add all necessary columns if they don't exist

### Step 3: Verify

Run this SQL to check if everything was created:

```sql
-- Check tables exist
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
ORDER BY table_name;

-- Check RLS policies on users table
SELECT policyname, cmd FROM pg_policies 
WHERE tablename = 'users';
```

You should see:
- Tables: `users`, `usernames`, `blacklist`, `reports`, `moderation_logs`, `credits`, `posts`
- Users policies: `users_public_read`, `users_insert_own`, `users_update_own`

### Step 4: Test the App

Refresh your app and try:
1. Signing in/signing up
2. Viewing a profile
3. Opening the admin panel (press "V" 3 times)

## Common Issues

### "Policy already exists"
This is fine! The script uses `DROP POLICY IF EXISTS` before creating, so this shouldn't happen. If it does, the script will still complete successfully.

### "Table already exists"
Also fine! The script uses `CREATE TABLE IF NOT EXISTS` so it won't error on existing tables.

### Still getting 500 errors after migration
1. Check the browser console for the exact error
2. In Supabase, go to Database → Logs → Postgres Logs
3. Look for errors and check which table/policy is causing the issue
4. Try running the migration script again

## What Changed

The RLS policies were simplified to avoid circular references:
- **Users table**: Public read access (anyone can view profiles)
- **Reports/Moderation logs**: Authenticated users only (admin checks done in app code)
- **Credits**: Public read, authenticated users can manage
- All policies now use `auth.uid()::text` cast to avoid UUID/TEXT type mismatch errors

## Need More Help?

If you're still having issues after running the migration:
1. Clear your browser cache
2. Sign out and sign back in
3. Check that your `.env` file has the correct Supabase URL and anon key
